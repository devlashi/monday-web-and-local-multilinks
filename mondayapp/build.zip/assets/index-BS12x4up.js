(function(){const i=document.createElement("link").relList;if(i&&i.supports&&i.supports("modulepreload"))return;for(const c of document.querySelectorAll('link[rel="modulepreload"]'))l(c);new MutationObserver(c=>{for(const d of c)if(d.type==="childList")for(const p of d.addedNodes)p.tagName==="LINK"&&p.rel==="modulepreload"&&l(p)}).observe(document,{childList:!0,subtree:!0});function o(c){const d={};return c.integrity&&(d.integrity=c.integrity),c.referrerPolicy&&(d.referrerPolicy=c.referrerPolicy),c.crossOrigin==="use-credentials"?d.credentials="include":c.crossOrigin==="anonymous"?d.credentials="omit":d.credentials="same-origin",d}function l(c){if(c.ep)return;c.ep=!0;const d=o(c);fetch(c.href,d)}})();var wp=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function lo(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var Zs={exports:{}},Jo={},Js={exports:{}},xe={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Cp;function _0(){if(Cp)return xe;Cp=1;var t=Symbol.for("react.element"),i=Symbol.for("react.portal"),o=Symbol.for("react.fragment"),l=Symbol.for("react.strict_mode"),c=Symbol.for("react.profiler"),d=Symbol.for("react.provider"),p=Symbol.for("react.context"),f=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),y=Symbol.iterator;function b(x){return x===null||typeof x!="object"?null:(x=y&&x[y]||x["@@iterator"],typeof x=="function"?x:null)}var w={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},N=Object.assign,L={};function O(x,P,G){this.props=x,this.context=P,this.refs=L,this.updater=G||w}O.prototype.isReactComponent={},O.prototype.setState=function(x,P){if(typeof x!="object"&&typeof x!="function"&&x!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,x,P,"setState")},O.prototype.forceUpdate=function(x){this.updater.enqueueForceUpdate(this,x,"forceUpdate")};function R(){}R.prototype=O.prototype;function M(x,P,G){this.props=x,this.context=P,this.refs=L,this.updater=G||w}var z=M.prototype=new R;z.constructor=M,N(z,O.prototype),z.isPureReactComponent=!0;var I=Array.isArray,B=Object.prototype.hasOwnProperty,j={current:null},X={key:!0,ref:!0,__self:!0,__source:!0};function K(x,P,G){var te,ie={},ye=null,_e=null;if(P!=null)for(te in P.ref!==void 0&&(_e=P.ref),P.key!==void 0&&(ye=""+P.key),P)B.call(P,te)&&!X.hasOwnProperty(te)&&(ie[te]=P[te]);var be=arguments.length-2;if(be===1)ie.children=G;else if(1<be){for(var Y=Array(be),Se=0;Se<be;Se++)Y[Se]=arguments[Se+2];ie.children=Y}if(x&&x.defaultProps)for(te in be=x.defaultProps,be)ie[te]===void 0&&(ie[te]=be[te]);return{$$typeof:t,type:x,key:ye,ref:_e,props:ie,_owner:j.current}}function ce(x,P){return{$$typeof:t,type:x.type,key:P,ref:x.ref,props:x.props,_owner:x._owner}}function Q(x){return typeof x=="object"&&x!==null&&x.$$typeof===t}function Z(x){var P={"=":"=0",":":"=2"};return"$"+x.replace(/[=:]/g,function(G){return P[G]})}var le=/\/+/g;function de(x,P){return typeof x=="object"&&x!==null&&x.key!=null?Z(""+x.key):P.toString(36)}function oe(x,P,G,te,ie){var ye=typeof x;(ye==="undefined"||ye==="boolean")&&(x=null);var _e=!1;if(x===null)_e=!0;else switch(ye){case"string":case"number":_e=!0;break;case"object":switch(x.$$typeof){case t:case i:_e=!0}}if(_e)return _e=x,ie=ie(_e),x=te===""?"."+de(_e,0):te,I(ie)?(G="",x!=null&&(G=x.replace(le,"$&/")+"/"),oe(ie,P,G,"",function(Se){return Se})):ie!=null&&(Q(ie)&&(ie=ce(ie,G+(!ie.key||_e&&_e.key===ie.key?"":(""+ie.key).replace(le,"$&/")+"/")+x)),P.push(ie)),1;if(_e=0,te=te===""?".":te+":",I(x))for(var be=0;be<x.length;be++){ye=x[be];var Y=te+de(ye,be);_e+=oe(ye,P,G,Y,ie)}else if(Y=b(x),typeof Y=="function")for(x=Y.call(x),be=0;!(ye=x.next()).done;)ye=ye.value,Y=te+de(ye,be++),_e+=oe(ye,P,G,Y,ie);else if(ye==="object")throw P=String(x),Error("Objects are not valid as a React child (found: "+(P==="[object Object]"?"object with keys {"+Object.keys(x).join(", ")+"}":P)+"). If you meant to render a collection of children, use an array instead.");return _e}function ve(x,P,G){if(x==null)return x;var te=[],ie=0;return oe(x,te,"","",function(ye){return P.call(G,ye,ie++)}),te}function re(x){if(x._status===-1){var P=x._result;P=P(),P.then(function(G){(x._status===0||x._status===-1)&&(x._status=1,x._result=G)},function(G){(x._status===0||x._status===-1)&&(x._status=2,x._result=G)}),x._status===-1&&(x._status=0,x._result=P)}if(x._status===1)return x._result.default;throw x._result}var fe={current:null},H={transition:null},V={ReactCurrentDispatcher:fe,ReactCurrentBatchConfig:H,ReactCurrentOwner:j};return xe.Children={map:ve,forEach:function(x,P,G){ve(x,function(){P.apply(this,arguments)},G)},count:function(x){var P=0;return ve(x,function(){P++}),P},toArray:function(x){return ve(x,function(P){return P})||[]},only:function(x){if(!Q(x))throw Error("React.Children.only expected to receive a single React element child.");return x}},xe.Component=O,xe.Fragment=o,xe.Profiler=c,xe.PureComponent=M,xe.StrictMode=l,xe.Suspense=m,xe.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=V,xe.cloneElement=function(x,P,G){if(x==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+x+".");var te=N({},x.props),ie=x.key,ye=x.ref,_e=x._owner;if(P!=null){if(P.ref!==void 0&&(ye=P.ref,_e=j.current),P.key!==void 0&&(ie=""+P.key),x.type&&x.type.defaultProps)var be=x.type.defaultProps;for(Y in P)B.call(P,Y)&&!X.hasOwnProperty(Y)&&(te[Y]=P[Y]===void 0&&be!==void 0?be[Y]:P[Y])}var Y=arguments.length-2;if(Y===1)te.children=G;else if(1<Y){be=Array(Y);for(var Se=0;Se<Y;Se++)be[Se]=arguments[Se+2];te.children=be}return{$$typeof:t,type:x.type,key:ie,ref:ye,props:te,_owner:_e}},xe.createContext=function(x){return x={$$typeof:p,_currentValue:x,_currentValue2:x,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},x.Provider={$$typeof:d,_context:x},x.Consumer=x},xe.createElement=K,xe.createFactory=function(x){var P=K.bind(null,x);return P.type=x,P},xe.createRef=function(){return{current:null}},xe.forwardRef=function(x){return{$$typeof:f,render:x}},xe.isValidElement=Q,xe.lazy=function(x){return{$$typeof:g,_payload:{_status:-1,_result:x},_init:re}},xe.memo=function(x,P){return{$$typeof:h,type:x,compare:P===void 0?null:P}},xe.startTransition=function(x){var P=H.transition;H.transition={};try{x()}finally{H.transition=P}},xe.unstable_act=function(){throw Error("act(...) is not supported in production builds of React.")},xe.useCallback=function(x,P){return fe.current.useCallback(x,P)},xe.useContext=function(x){return fe.current.useContext(x)},xe.useDebugValue=function(){},xe.useDeferredValue=function(x){return fe.current.useDeferredValue(x)},xe.useEffect=function(x,P){return fe.current.useEffect(x,P)},xe.useId=function(){return fe.current.useId()},xe.useImperativeHandle=function(x,P,G){return fe.current.useImperativeHandle(x,P,G)},xe.useInsertionEffect=function(x,P){return fe.current.useInsertionEffect(x,P)},xe.useLayoutEffect=function(x,P){return fe.current.useLayoutEffect(x,P)},xe.useMemo=function(x,P){return fe.current.useMemo(x,P)},xe.useReducer=function(x,P,G){return fe.current.useReducer(x,P,G)},xe.useRef=function(x){return fe.current.useRef(x)},xe.useState=function(x){return fe.current.useState(x)},xe.useSyncExternalStore=function(x,P,G){return fe.current.useSyncExternalStore(x,P,G)},xe.useTransition=function(){return fe.current.useTransition()},xe.version="18.2.0",xe}var Tp;function ku(){return Tp||(Tp=1,Js.exports=_0()),Js.exports}/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Op;function b0(){if(Op)return Jo;Op=1;var t=ku(),i=Symbol.for("react.element"),o=Symbol.for("react.fragment"),l=Object.prototype.hasOwnProperty,c=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,d={key:!0,ref:!0,__self:!0,__source:!0};function p(f,m,h){var g,y={},b=null,w=null;h!==void 0&&(b=""+h),m.key!==void 0&&(b=""+m.key),m.ref!==void 0&&(w=m.ref);for(g in m)l.call(m,g)&&!d.hasOwnProperty(g)&&(y[g]=m[g]);if(f&&f.defaultProps)for(g in m=f.defaultProps,m)y[g]===void 0&&(y[g]=m[g]);return{$$typeof:i,type:f,key:b,ref:w,props:y,_owner:c.current}}return Jo.Fragment=o,Jo.jsx=p,Jo.jsxs=p,Jo}var Ap;function x0(){return Ap||(Ap=1,Zs.exports=b0()),Zs.exports}var he=x0();window.global||(window.global=window);var k=ku();const D=lo(k);var Ta={},ec={exports:{}},ft={},tc={exports:{}},nc={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Np;function k0(){return Np||(Np=1,function(t){function i(H,V){var x=H.length;H.push(V);e:for(;0<x;){var P=x-1>>>1,G=H[P];if(0<c(G,V))H[P]=V,H[x]=G,x=P;else break e}}function o(H){return H.length===0?null:H[0]}function l(H){if(H.length===0)return null;var V=H[0],x=H.pop();if(x!==V){H[0]=x;e:for(var P=0,G=H.length,te=G>>>1;P<te;){var ie=2*(P+1)-1,ye=H[ie],_e=ie+1,be=H[_e];if(0>c(ye,x))_e<G&&0>c(be,ye)?(H[P]=be,H[_e]=x,P=_e):(H[P]=ye,H[ie]=x,P=ie);else if(_e<G&&0>c(be,x))H[P]=be,H[_e]=x,P=_e;else break e}}return V}function c(H,V){var x=H.sortIndex-V.sortIndex;return x!==0?x:H.id-V.id}if(typeof performance=="object"&&typeof performance.now=="function"){var d=performance;t.unstable_now=function(){return d.now()}}else{var p=Date,f=p.now();t.unstable_now=function(){return p.now()-f}}var m=[],h=[],g=1,y=null,b=3,w=!1,N=!1,L=!1,O=typeof setTimeout=="function"?setTimeout:null,R=typeof clearTimeout=="function"?clearTimeout:null,M=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function z(H){for(var V=o(h);V!==null;){if(V.callback===null)l(h);else if(V.startTime<=H)l(h),V.sortIndex=V.expirationTime,i(m,V);else break;V=o(h)}}function I(H){if(L=!1,z(H),!N)if(o(m)!==null)N=!0,re(B);else{var V=o(h);V!==null&&fe(I,V.startTime-H)}}function B(H,V){N=!1,L&&(L=!1,R(K),K=-1),w=!0;var x=b;try{for(z(V),y=o(m);y!==null&&(!(y.expirationTime>V)||H&&!Z());){var P=y.callback;if(typeof P=="function"){y.callback=null,b=y.priorityLevel;var G=P(y.expirationTime<=V);V=t.unstable_now(),typeof G=="function"?y.callback=G:y===o(m)&&l(m),z(V)}else l(m);y=o(m)}if(y!==null)var te=!0;else{var ie=o(h);ie!==null&&fe(I,ie.startTime-V),te=!1}return te}finally{y=null,b=x,w=!1}}var j=!1,X=null,K=-1,ce=5,Q=-1;function Z(){return!(t.unstable_now()-Q<ce)}function le(){if(X!==null){var H=t.unstable_now();Q=H;var V=!0;try{V=X(!0,H)}finally{V?de():(j=!1,X=null)}}else j=!1}var de;if(typeof M=="function")de=function(){M(le)};else if(typeof MessageChannel<"u"){var oe=new MessageChannel,ve=oe.port2;oe.port1.onmessage=le,de=function(){ve.postMessage(null)}}else de=function(){O(le,0)};function re(H){X=H,j||(j=!0,de())}function fe(H,V){K=O(function(){H(t.unstable_now())},V)}t.unstable_IdlePriority=5,t.unstable_ImmediatePriority=1,t.unstable_LowPriority=4,t.unstable_NormalPriority=3,t.unstable_Profiling=null,t.unstable_UserBlockingPriority=2,t.unstable_cancelCallback=function(H){H.callback=null},t.unstable_continueExecution=function(){N||w||(N=!0,re(B))},t.unstable_forceFrameRate=function(H){0>H||125<H?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):ce=0<H?Math.floor(1e3/H):5},t.unstable_getCurrentPriorityLevel=function(){return b},t.unstable_getFirstCallbackNode=function(){return o(m)},t.unstable_next=function(H){switch(b){case 1:case 2:case 3:var V=3;break;default:V=b}var x=b;b=V;try{return H()}finally{b=x}},t.unstable_pauseExecution=function(){},t.unstable_requestPaint=function(){},t.unstable_runWithPriority=function(H,V){switch(H){case 1:case 2:case 3:case 4:case 5:break;default:H=3}var x=b;b=H;try{return V()}finally{b=x}},t.unstable_scheduleCallback=function(H,V,x){var P=t.unstable_now();switch(typeof x=="object"&&x!==null?(x=x.delay,x=typeof x=="number"&&0<x?P+x:P):x=P,H){case 1:var G=-1;break;case 2:G=250;break;case 5:G=1073741823;break;case 4:G=1e4;break;default:G=5e3}return G=x+G,H={id:g++,callback:V,priorityLevel:H,startTime:x,expirationTime:G,sortIndex:-1},x>P?(H.sortIndex=x,i(h,H),o(m)===null&&H===o(h)&&(L?(R(K),K=-1):L=!0,fe(I,x-P))):(H.sortIndex=G,i(m,H),N||w||(N=!0,re(B))),H},t.unstable_shouldYield=Z,t.unstable_wrapCallback=function(H){var V=b;return function(){var x=b;b=V;try{return H.apply(this,arguments)}finally{b=x}}}}(nc)),nc}var Lp;function E0(){return Lp||(Lp=1,tc.exports=k0()),tc.exports}/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Rp;function S0(){if(Rp)return ft;Rp=1;var t=ku(),i=E0();function o(e){for(var n="https://reactjs.org/docs/error-decoder.html?invariant="+e,r=1;r<arguments.length;r++)n+="&args[]="+encodeURIComponent(arguments[r]);return"Minified React error #"+e+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var l=new Set,c={};function d(e,n){p(e,n),p(e+"Capture",n)}function p(e,n){for(c[e]=n,e=0;e<n.length;e++)l.add(n[e])}var f=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),m=Object.prototype.hasOwnProperty,h=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,g={},y={};function b(e){return m.call(y,e)?!0:m.call(g,e)?!1:h.test(e)?y[e]=!0:(g[e]=!0,!1)}function w(e,n,r,a){if(r!==null&&r.type===0)return!1;switch(typeof n){case"function":case"symbol":return!0;case"boolean":return a?!1:r!==null?!r.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function N(e,n,r,a){if(n===null||typeof n>"u"||w(e,n,r,a))return!0;if(a)return!1;if(r!==null)switch(r.type){case 3:return!n;case 4:return n===!1;case 5:return isNaN(n);case 6:return isNaN(n)||1>n}return!1}function L(e,n,r,a,s,u,v){this.acceptsBooleans=n===2||n===3||n===4,this.attributeName=a,this.attributeNamespace=s,this.mustUseProperty=r,this.propertyName=e,this.type=n,this.sanitizeURL=u,this.removeEmptyString=v}var O={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){O[e]=new L(e,0,!1,e,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var n=e[0];O[n]=new L(n,1,!1,e[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(e){O[e]=new L(e,2,!1,e.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){O[e]=new L(e,2,!1,e,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){O[e]=new L(e,3,!1,e.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(e){O[e]=new L(e,3,!0,e,null,!1,!1)}),["capture","download"].forEach(function(e){O[e]=new L(e,4,!1,e,null,!1,!1)}),["cols","rows","size","span"].forEach(function(e){O[e]=new L(e,6,!1,e,null,!1,!1)}),["rowSpan","start"].forEach(function(e){O[e]=new L(e,5,!1,e.toLowerCase(),null,!1,!1)});var R=/[\-:]([a-z])/g;function M(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var n=e.replace(R,M);O[n]=new L(n,1,!1,e,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var n=e.replace(R,M);O[n]=new L(n,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(e){var n=e.replace(R,M);O[n]=new L(n,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(e){O[e]=new L(e,1,!1,e.toLowerCase(),null,!1,!1)}),O.xlinkHref=new L("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(e){O[e]=new L(e,1,!1,e.toLowerCase(),null,!0,!0)});function z(e,n,r,a){var s=O.hasOwnProperty(n)?O[n]:null;(s!==null?s.type!==0:a||!(2<n.length)||n[0]!=="o"&&n[0]!=="O"||n[1]!=="n"&&n[1]!=="N")&&(N(n,r,s,a)&&(r=null),a||s===null?b(n)&&(r===null?e.removeAttribute(n):e.setAttribute(n,""+r)):s.mustUseProperty?e[s.propertyName]=r===null?s.type===3?!1:"":r:(n=s.attributeName,a=s.attributeNamespace,r===null?e.removeAttribute(n):(s=s.type,r=s===3||s===4&&r===!0?"":""+r,a?e.setAttributeNS(a,n,r):e.setAttribute(n,r))))}var I=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,B=Symbol.for("react.element"),j=Symbol.for("react.portal"),X=Symbol.for("react.fragment"),K=Symbol.for("react.strict_mode"),ce=Symbol.for("react.profiler"),Q=Symbol.for("react.provider"),Z=Symbol.for("react.context"),le=Symbol.for("react.forward_ref"),de=Symbol.for("react.suspense"),oe=Symbol.for("react.suspense_list"),ve=Symbol.for("react.memo"),re=Symbol.for("react.lazy"),fe=Symbol.for("react.offscreen"),H=Symbol.iterator;function V(e){return e===null||typeof e!="object"?null:(e=H&&e[H]||e["@@iterator"],typeof e=="function"?e:null)}var x=Object.assign,P;function G(e){if(P===void 0)try{throw Error()}catch(r){var n=r.stack.trim().match(/\n( *(at )?)/);P=n&&n[1]||""}return`
`+P+e}var te=!1;function ie(e,n){if(!e||te)return"";te=!0;var r=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(n)if(n=function(){throw Error()},Object.defineProperty(n.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(n,[])}catch(A){var a=A}Reflect.construct(e,[],n)}else{try{n.call()}catch(A){a=A}e.call(n.prototype)}else{try{throw Error()}catch(A){a=A}e()}}catch(A){if(A&&a&&typeof A.stack=="string"){for(var s=A.stack.split(`
`),u=a.stack.split(`
`),v=s.length-1,_=u.length-1;1<=v&&0<=_&&s[v]!==u[_];)_--;for(;1<=v&&0<=_;v--,_--)if(s[v]!==u[_]){if(v!==1||_!==1)do if(v--,_--,0>_||s[v]!==u[_]){var E=`
`+s[v].replace(" at new "," at ");return e.displayName&&E.includes("<anonymous>")&&(E=E.replace("<anonymous>",e.displayName)),E}while(1<=v&&0<=_);break}}}finally{te=!1,Error.prepareStackTrace=r}return(e=e?e.displayName||e.name:"")?G(e):""}function ye(e){switch(e.tag){case 5:return G(e.type);case 16:return G("Lazy");case 13:return G("Suspense");case 19:return G("SuspenseList");case 0:case 2:case 15:return e=ie(e.type,!1),e;case 11:return e=ie(e.type.render,!1),e;case 1:return e=ie(e.type,!0),e;default:return""}}function _e(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case X:return"Fragment";case j:return"Portal";case ce:return"Profiler";case K:return"StrictMode";case de:return"Suspense";case oe:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case Z:return(e.displayName||"Context")+".Consumer";case Q:return(e._context.displayName||"Context")+".Provider";case le:var n=e.render;return e=e.displayName,e||(e=n.displayName||n.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case ve:return n=e.displayName||null,n!==null?n:_e(e.type)||"Memo";case re:n=e._payload,e=e._init;try{return _e(e(n))}catch{}}return null}function be(e){var n=e.type;switch(e.tag){case 24:return"Cache";case 9:return(n.displayName||"Context")+".Consumer";case 10:return(n._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=n.render,e=e.displayName||e.name||"",n.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return n;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return _e(n);case 8:return n===K?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n}return null}function Y(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Se(e){var n=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function Ne(e){var n=Se(e)?"checked":"value",r=Object.getOwnPropertyDescriptor(e.constructor.prototype,n),a=""+e[n];if(!e.hasOwnProperty(n)&&typeof r<"u"&&typeof r.get=="function"&&typeof r.set=="function"){var s=r.get,u=r.set;return Object.defineProperty(e,n,{configurable:!0,get:function(){return s.call(this)},set:function(v){a=""+v,u.call(this,v)}}),Object.defineProperty(e,n,{enumerable:r.enumerable}),{getValue:function(){return a},setValue:function(v){a=""+v},stopTracking:function(){e._valueTracker=null,delete e[n]}}}}function Ue(e){e._valueTracker||(e._valueTracker=Ne(e))}function Ft(e){if(!e)return!1;var n=e._valueTracker;if(!n)return!0;var r=n.getValue(),a="";return e&&(a=Se(e)?e.checked?"true":"false":e.value),e=a,e!==r?(n.setValue(e),!0):!1}function vt(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function hn(e,n){var r=n.checked;return x({},n,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:r??e._wrapperState.initialChecked})}function gn(e,n){var r=n.defaultValue==null?"":n.defaultValue,a=n.checked!=null?n.checked:n.defaultChecked;r=Y(n.value!=null?n.value:r),e._wrapperState={initialChecked:a,initialValue:r,controlled:n.type==="checkbox"||n.type==="radio"?n.checked!=null:n.value!=null}}function Xt(e,n){n=n.checked,n!=null&&z(e,"checked",n,!1)}function Ut(e,n){Xt(e,n);var r=Y(n.value),a=n.type;if(r!=null)a==="number"?(r===0&&e.value===""||e.value!=r)&&(e.value=""+r):e.value!==""+r&&(e.value=""+r);else if(a==="submit"||a==="reset"){e.removeAttribute("value");return}n.hasOwnProperty("value")?Ie(e,n.type,r):n.hasOwnProperty("defaultValue")&&Ie(e,n.type,Y(n.defaultValue)),n.checked==null&&n.defaultChecked!=null&&(e.defaultChecked=!!n.defaultChecked)}function yn(e,n,r){if(n.hasOwnProperty("value")||n.hasOwnProperty("defaultValue")){var a=n.type;if(!(a!=="submit"&&a!=="reset"||n.value!==void 0&&n.value!==null))return;n=""+e._wrapperState.initialValue,r||n===e.value||(e.value=n),e.defaultValue=n}r=e.name,r!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,r!==""&&(e.name=r)}function Ie(e,n,r){(n!=="number"||vt(e.ownerDocument)!==e)&&(r==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+r&&(e.defaultValue=""+r))}var Je=Array.isArray;function Lt(e,n,r,a){if(e=e.options,n){n={};for(var s=0;s<r.length;s++)n["$"+r[s]]=!0;for(r=0;r<e.length;r++)s=n.hasOwnProperty("$"+e[r].value),e[r].selected!==s&&(e[r].selected=s),s&&a&&(e[r].defaultSelected=!0)}else{for(r=""+Y(r),n=null,s=0;s<e.length;s++){if(e[s].value===r){e[s].selected=!0,a&&(e[s].defaultSelected=!0);return}n!==null||e[s].disabled||(n=e[s])}n!==null&&(n.selected=!0)}}function yr(e,n){if(n.dangerouslySetInnerHTML!=null)throw Error(o(91));return x({},n,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function fo(e,n){var r=n.value;if(r==null){if(r=n.children,n=n.defaultValue,r!=null){if(n!=null)throw Error(o(92));if(Je(r)){if(1<r.length)throw Error(o(93));r=r[0]}n=r}n==null&&(n=""),r=n}e._wrapperState={initialValue:Y(r)}}function _r(e,n){var r=Y(n.value),a=Y(n.defaultValue);r!=null&&(r=""+r,r!==e.value&&(e.value=r),n.defaultValue==null&&e.defaultValue!==r&&(e.defaultValue=r)),a!=null&&(e.defaultValue=""+a)}function po(e){var n=e.textContent;n===e._wrapperState.initialValue&&n!==""&&n!==null&&(e.value=n)}function mo(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function br(e,n){return e==null||e==="http://www.w3.org/1999/xhtml"?mo(n):e==="http://www.w3.org/2000/svg"&&n==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var Hn,Bu=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(n,r,a,s){MSApp.execUnsafeLocalFunction(function(){return e(n,r,a,s)})}:e}(function(e,n){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=n;else{for(Hn=Hn||document.createElement("div"),Hn.innerHTML="<svg>"+n.valueOf().toString()+"</svg>",n=Hn.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;n.firstChild;)e.appendChild(n.firstChild)}});function vo(e,n){if(n){var r=e.firstChild;if(r&&r===e.lastChild&&r.nodeType===3){r.nodeValue=n;return}}e.textContent=n}var ho={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Eh=["Webkit","ms","Moz","O"];Object.keys(ho).forEach(function(e){Eh.forEach(function(n){n=n+e.charAt(0).toUpperCase()+e.substring(1),ho[n]=ho[e]})});function ju(e,n,r){return n==null||typeof n=="boolean"||n===""?"":r||typeof n!="number"||n===0||ho.hasOwnProperty(e)&&ho[e]?(""+n).trim():n+"px"}function $u(e,n){e=e.style;for(var r in n)if(n.hasOwnProperty(r)){var a=r.indexOf("--")===0,s=ju(r,n[r],a);r==="float"&&(r="cssFloat"),a?e.setProperty(r,s):e[r]=s}}var Sh=x({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function ul(e,n){if(n){if(Sh[e]&&(n.children!=null||n.dangerouslySetInnerHTML!=null))throw Error(o(137,e));if(n.dangerouslySetInnerHTML!=null){if(n.children!=null)throw Error(o(60));if(typeof n.dangerouslySetInnerHTML!="object"||!("__html"in n.dangerouslySetInnerHTML))throw Error(o(61))}if(n.style!=null&&typeof n.style!="object")throw Error(o(62))}}function dl(e,n){if(e.indexOf("-")===-1)return typeof n.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var fl=null;function pl(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var ml=null,xr=null,kr=null;function zu(e){if(e=jo(e)){if(typeof ml!="function")throw Error(o(280));var n=e.stateNode;n&&(n=Xi(n),ml(e.stateNode,e.type,n))}}function Fu(e){xr?kr?kr.push(e):kr=[e]:xr=e}function Xu(){if(xr){var e=xr,n=kr;if(kr=xr=null,zu(e),n)for(e=0;e<n.length;e++)zu(n[e])}}function Uu(e,n){return e(n)}function Hu(){}var vl=!1;function Wu(e,n,r){if(vl)return e(n,r);vl=!0;try{return Uu(e,n,r)}finally{vl=!1,(xr!==null||kr!==null)&&(Hu(),Xu())}}function go(e,n){var r=e.stateNode;if(r===null)return null;var a=Xi(r);if(a===null)return null;r=a[n];e:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(a=!a.disabled)||(e=e.type,a=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!a;break e;default:e=!1}if(e)return null;if(r&&typeof r!="function")throw Error(o(231,n,typeof r));return r}var hl=!1;if(f)try{var yo={};Object.defineProperty(yo,"passive",{get:function(){hl=!0}}),window.addEventListener("test",yo,yo),window.removeEventListener("test",yo,yo)}catch{hl=!1}function wh(e,n,r,a,s,u,v,_,E){var A=Array.prototype.slice.call(arguments,3);try{n.apply(r,A)}catch(F){this.onError(F)}}var _o=!1,bi=null,xi=!1,gl=null,Ch={onError:function(e){_o=!0,bi=e}};function Th(e,n,r,a,s,u,v,_,E){_o=!1,bi=null,wh.apply(Ch,arguments)}function Oh(e,n,r,a,s,u,v,_,E){if(Th.apply(this,arguments),_o){if(_o){var A=bi;_o=!1,bi=null}else throw Error(o(198));xi||(xi=!0,gl=A)}}function Wn(e){var n=e,r=e;if(e.alternate)for(;n.return;)n=n.return;else{e=n;do n=e,(n.flags&4098)!==0&&(r=n.return),e=n.return;while(e)}return n.tag===3?r:null}function Vu(e){if(e.tag===13){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function Gu(e){if(Wn(e)!==e)throw Error(o(188))}function Ah(e){var n=e.alternate;if(!n){if(n=Wn(e),n===null)throw Error(o(188));return n!==e?null:e}for(var r=e,a=n;;){var s=r.return;if(s===null)break;var u=s.alternate;if(u===null){if(a=s.return,a!==null){r=a;continue}break}if(s.child===u.child){for(u=s.child;u;){if(u===r)return Gu(s),e;if(u===a)return Gu(s),n;u=u.sibling}throw Error(o(188))}if(r.return!==a.return)r=s,a=u;else{for(var v=!1,_=s.child;_;){if(_===r){v=!0,r=s,a=u;break}if(_===a){v=!0,a=s,r=u;break}_=_.sibling}if(!v){for(_=u.child;_;){if(_===r){v=!0,r=u,a=s;break}if(_===a){v=!0,a=u,r=s;break}_=_.sibling}if(!v)throw Error(o(189))}}if(r.alternate!==a)throw Error(o(190))}if(r.tag!==3)throw Error(o(188));return r.stateNode.current===r?e:n}function Ku(e){return e=Ah(e),e!==null?Yu(e):null}function Yu(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var n=Yu(e);if(n!==null)return n;e=e.sibling}return null}var qu=i.unstable_scheduleCallback,Qu=i.unstable_cancelCallback,Nh=i.unstable_shouldYield,Lh=i.unstable_requestPaint,je=i.unstable_now,Rh=i.unstable_getCurrentPriorityLevel,yl=i.unstable_ImmediatePriority,Zu=i.unstable_UserBlockingPriority,ki=i.unstable_NormalPriority,Ph=i.unstable_LowPriority,Ju=i.unstable_IdlePriority,Ei=null,Ht=null;function Dh(e){if(Ht&&typeof Ht.onCommitFiberRoot=="function")try{Ht.onCommitFiberRoot(Ei,e,void 0,(e.current.flags&128)===128)}catch{}}var Rt=Math.clz32?Math.clz32:Bh,Ih=Math.log,Mh=Math.LN2;function Bh(e){return e>>>=0,e===0?32:31-(Ih(e)/Mh|0)|0}var Si=64,wi=4194304;function bo(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Ci(e,n){var r=e.pendingLanes;if(r===0)return 0;var a=0,s=e.suspendedLanes,u=e.pingedLanes,v=r&268435455;if(v!==0){var _=v&~s;_!==0?a=bo(_):(u&=v,u!==0&&(a=bo(u)))}else v=r&~s,v!==0?a=bo(v):u!==0&&(a=bo(u));if(a===0)return 0;if(n!==0&&n!==a&&(n&s)===0&&(s=a&-a,u=n&-n,s>=u||s===16&&(u&4194240)!==0))return n;if((a&4)!==0&&(a|=r&16),n=e.entangledLanes,n!==0)for(e=e.entanglements,n&=a;0<n;)r=31-Rt(n),s=1<<r,a|=e[r],n&=~s;return a}function jh(e,n){switch(e){case 1:case 2:case 4:return n+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function $h(e,n){for(var r=e.suspendedLanes,a=e.pingedLanes,s=e.expirationTimes,u=e.pendingLanes;0<u;){var v=31-Rt(u),_=1<<v,E=s[v];E===-1?((_&r)===0||(_&a)!==0)&&(s[v]=jh(_,n)):E<=n&&(e.expiredLanes|=_),u&=~_}}function _l(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function ed(){var e=Si;return Si<<=1,(Si&4194240)===0&&(Si=64),e}function bl(e){for(var n=[],r=0;31>r;r++)n.push(e);return n}function xo(e,n,r){e.pendingLanes|=n,n!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,n=31-Rt(n),e[n]=r}function zh(e,n){var r=e.pendingLanes&~n;e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=n,e.mutableReadLanes&=n,e.entangledLanes&=n,n=e.entanglements;var a=e.eventTimes;for(e=e.expirationTimes;0<r;){var s=31-Rt(r),u=1<<s;n[s]=0,a[s]=-1,e[s]=-1,r&=~u}}function xl(e,n){var r=e.entangledLanes|=n;for(e=e.entanglements;r;){var a=31-Rt(r),s=1<<a;s&n|e[a]&n&&(e[a]|=n),r&=~s}}var we=0;function td(e){return e&=-e,1<e?4<e?(e&268435455)!==0?16:536870912:4:1}var nd,kl,rd,od,id,El=!1,Ti=[],_n=null,bn=null,xn=null,ko=new Map,Eo=new Map,kn=[],Fh="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function ad(e,n){switch(e){case"focusin":case"focusout":_n=null;break;case"dragenter":case"dragleave":bn=null;break;case"mouseover":case"mouseout":xn=null;break;case"pointerover":case"pointerout":ko.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Eo.delete(n.pointerId)}}function So(e,n,r,a,s,u){return e===null||e.nativeEvent!==u?(e={blockedOn:n,domEventName:r,eventSystemFlags:a,nativeEvent:u,targetContainers:[s]},n!==null&&(n=jo(n),n!==null&&kl(n)),e):(e.eventSystemFlags|=a,n=e.targetContainers,s!==null&&n.indexOf(s)===-1&&n.push(s),e)}function Xh(e,n,r,a,s){switch(n){case"focusin":return _n=So(_n,e,n,r,a,s),!0;case"dragenter":return bn=So(bn,e,n,r,a,s),!0;case"mouseover":return xn=So(xn,e,n,r,a,s),!0;case"pointerover":var u=s.pointerId;return ko.set(u,So(ko.get(u)||null,e,n,r,a,s)),!0;case"gotpointercapture":return u=s.pointerId,Eo.set(u,So(Eo.get(u)||null,e,n,r,a,s)),!0}return!1}function ld(e){var n=Vn(e.target);if(n!==null){var r=Wn(n);if(r!==null){if(n=r.tag,n===13){if(n=Vu(r),n!==null){e.blockedOn=n,id(e.priority,function(){rd(r)});return}}else if(n===3&&r.stateNode.current.memoizedState.isDehydrated){e.blockedOn=r.tag===3?r.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Oi(e){if(e.blockedOn!==null)return!1;for(var n=e.targetContainers;0<n.length;){var r=wl(e.domEventName,e.eventSystemFlags,n[0],e.nativeEvent);if(r===null){r=e.nativeEvent;var a=new r.constructor(r.type,r);fl=a,r.target.dispatchEvent(a),fl=null}else return n=jo(r),n!==null&&kl(n),e.blockedOn=r,!1;n.shift()}return!0}function sd(e,n,r){Oi(e)&&r.delete(n)}function Uh(){El=!1,_n!==null&&Oi(_n)&&(_n=null),bn!==null&&Oi(bn)&&(bn=null),xn!==null&&Oi(xn)&&(xn=null),ko.forEach(sd),Eo.forEach(sd)}function wo(e,n){e.blockedOn===n&&(e.blockedOn=null,El||(El=!0,i.unstable_scheduleCallback(i.unstable_NormalPriority,Uh)))}function Co(e){function n(s){return wo(s,e)}if(0<Ti.length){wo(Ti[0],e);for(var r=1;r<Ti.length;r++){var a=Ti[r];a.blockedOn===e&&(a.blockedOn=null)}}for(_n!==null&&wo(_n,e),bn!==null&&wo(bn,e),xn!==null&&wo(xn,e),ko.forEach(n),Eo.forEach(n),r=0;r<kn.length;r++)a=kn[r],a.blockedOn===e&&(a.blockedOn=null);for(;0<kn.length&&(r=kn[0],r.blockedOn===null);)ld(r),r.blockedOn===null&&kn.shift()}var Er=I.ReactCurrentBatchConfig,Ai=!0;function Hh(e,n,r,a){var s=we,u=Er.transition;Er.transition=null;try{we=1,Sl(e,n,r,a)}finally{we=s,Er.transition=u}}function Wh(e,n,r,a){var s=we,u=Er.transition;Er.transition=null;try{we=4,Sl(e,n,r,a)}finally{we=s,Er.transition=u}}function Sl(e,n,r,a){if(Ai){var s=wl(e,n,r,a);if(s===null)Xl(e,n,a,Ni,r),ad(e,a);else if(Xh(s,e,n,r,a))a.stopPropagation();else if(ad(e,a),n&4&&-1<Fh.indexOf(e)){for(;s!==null;){var u=jo(s);if(u!==null&&nd(u),u=wl(e,n,r,a),u===null&&Xl(e,n,a,Ni,r),u===s)break;s=u}s!==null&&a.stopPropagation()}else Xl(e,n,a,null,r)}}var Ni=null;function wl(e,n,r,a){if(Ni=null,e=pl(a),e=Vn(e),e!==null)if(n=Wn(e),n===null)e=null;else if(r=n.tag,r===13){if(e=Vu(n),e!==null)return e;e=null}else if(r===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;e=null}else n!==e&&(e=null);return Ni=e,null}function cd(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Rh()){case yl:return 1;case Zu:return 4;case ki:case Ph:return 16;case Ju:return 536870912;default:return 16}default:return 16}}var En=null,Cl=null,Li=null;function ud(){if(Li)return Li;var e,n=Cl,r=n.length,a,s="value"in En?En.value:En.textContent,u=s.length;for(e=0;e<r&&n[e]===s[e];e++);var v=r-e;for(a=1;a<=v&&n[r-a]===s[u-a];a++);return Li=s.slice(e,1<a?1-a:void 0)}function Ri(e){var n=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&n===13&&(e=13)):e=n,e===10&&(e=13),32<=e||e===13?e:0}function Pi(){return!0}function dd(){return!1}function ht(e){function n(r,a,s,u,v){this._reactName=r,this._targetInst=s,this.type=a,this.nativeEvent=u,this.target=v,this.currentTarget=null;for(var _ in e)e.hasOwnProperty(_)&&(r=e[_],this[_]=r?r(u):u[_]);return this.isDefaultPrevented=(u.defaultPrevented!=null?u.defaultPrevented:u.returnValue===!1)?Pi:dd,this.isPropagationStopped=dd,this}return x(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var r=this.nativeEvent;r&&(r.preventDefault?r.preventDefault():typeof r.returnValue!="unknown"&&(r.returnValue=!1),this.isDefaultPrevented=Pi)},stopPropagation:function(){var r=this.nativeEvent;r&&(r.stopPropagation?r.stopPropagation():typeof r.cancelBubble!="unknown"&&(r.cancelBubble=!0),this.isPropagationStopped=Pi)},persist:function(){},isPersistent:Pi}),n}var Sr={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Tl=ht(Sr),To=x({},Sr,{view:0,detail:0}),Vh=ht(To),Ol,Al,Oo,Di=x({},To,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Ll,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Oo&&(Oo&&e.type==="mousemove"?(Ol=e.screenX-Oo.screenX,Al=e.screenY-Oo.screenY):Al=Ol=0,Oo=e),Ol)},movementY:function(e){return"movementY"in e?e.movementY:Al}}),fd=ht(Di),Gh=x({},Di,{dataTransfer:0}),Kh=ht(Gh),Yh=x({},To,{relatedTarget:0}),Nl=ht(Yh),qh=x({},Sr,{animationName:0,elapsedTime:0,pseudoElement:0}),Qh=ht(qh),Zh=x({},Sr,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Jh=ht(Zh),eg=x({},Sr,{data:0}),pd=ht(eg),tg={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ng={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},rg={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function og(e){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(e):(e=rg[e])?!!n[e]:!1}function Ll(){return og}var ig=x({},To,{key:function(e){if(e.key){var n=tg[e.key]||e.key;if(n!=="Unidentified")return n}return e.type==="keypress"?(e=Ri(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?ng[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Ll,charCode:function(e){return e.type==="keypress"?Ri(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Ri(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),ag=ht(ig),lg=x({},Di,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),md=ht(lg),sg=x({},To,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Ll}),cg=ht(sg),ug=x({},Sr,{propertyName:0,elapsedTime:0,pseudoElement:0}),dg=ht(ug),fg=x({},Di,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),pg=ht(fg),mg=[9,13,27,32],Rl=f&&"CompositionEvent"in window,Ao=null;f&&"documentMode"in document&&(Ao=document.documentMode);var vg=f&&"TextEvent"in window&&!Ao,vd=f&&(!Rl||Ao&&8<Ao&&11>=Ao),hd=" ",gd=!1;function yd(e,n){switch(e){case"keyup":return mg.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function _d(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var wr=!1;function hg(e,n){switch(e){case"compositionend":return _d(n);case"keypress":return n.which!==32?null:(gd=!0,hd);case"textInput":return e=n.data,e===hd&&gd?null:e;default:return null}}function gg(e,n){if(wr)return e==="compositionend"||!Rl&&yd(e,n)?(e=ud(),Li=Cl=En=null,wr=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return vd&&n.locale!=="ko"?null:n.data;default:return null}}var yg={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function bd(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n==="input"?!!yg[e.type]:n==="textarea"}function xd(e,n,r,a){Fu(a),n=$i(n,"onChange"),0<n.length&&(r=new Tl("onChange","change",null,r,a),e.push({event:r,listeners:n}))}var No=null,Lo=null;function _g(e){$d(e,0)}function Ii(e){var n=Nr(e);if(Ft(n))return e}function bg(e,n){if(e==="change")return n}var kd=!1;if(f){var Pl;if(f){var Dl="oninput"in document;if(!Dl){var Ed=document.createElement("div");Ed.setAttribute("oninput","return;"),Dl=typeof Ed.oninput=="function"}Pl=Dl}else Pl=!1;kd=Pl&&(!document.documentMode||9<document.documentMode)}function Sd(){No&&(No.detachEvent("onpropertychange",wd),Lo=No=null)}function wd(e){if(e.propertyName==="value"&&Ii(Lo)){var n=[];xd(n,Lo,e,pl(e)),Wu(_g,n)}}function xg(e,n,r){e==="focusin"?(Sd(),No=n,Lo=r,No.attachEvent("onpropertychange",wd)):e==="focusout"&&Sd()}function kg(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Ii(Lo)}function Eg(e,n){if(e==="click")return Ii(n)}function Sg(e,n){if(e==="input"||e==="change")return Ii(n)}function wg(e,n){return e===n&&(e!==0||1/e===1/n)||e!==e&&n!==n}var Pt=typeof Object.is=="function"?Object.is:wg;function Ro(e,n){if(Pt(e,n))return!0;if(typeof e!="object"||e===null||typeof n!="object"||n===null)return!1;var r=Object.keys(e),a=Object.keys(n);if(r.length!==a.length)return!1;for(a=0;a<r.length;a++){var s=r[a];if(!m.call(n,s)||!Pt(e[s],n[s]))return!1}return!0}function Cd(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Td(e,n){var r=Cd(e);e=0;for(var a;r;){if(r.nodeType===3){if(a=e+r.textContent.length,e<=n&&a>=n)return{node:r,offset:n-e};e=a}e:{for(;r;){if(r.nextSibling){r=r.nextSibling;break e}r=r.parentNode}r=void 0}r=Cd(r)}}function Od(e,n){return e&&n?e===n?!0:e&&e.nodeType===3?!1:n&&n.nodeType===3?Od(e,n.parentNode):"contains"in e?e.contains(n):e.compareDocumentPosition?!!(e.compareDocumentPosition(n)&16):!1:!1}function Ad(){for(var e=window,n=vt();n instanceof e.HTMLIFrameElement;){try{var r=typeof n.contentWindow.location.href=="string"}catch{r=!1}if(r)e=n.contentWindow;else break;n=vt(e.document)}return n}function Il(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n&&(n==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||n==="textarea"||e.contentEditable==="true")}function Cg(e){var n=Ad(),r=e.focusedElem,a=e.selectionRange;if(n!==r&&r&&r.ownerDocument&&Od(r.ownerDocument.documentElement,r)){if(a!==null&&Il(r)){if(n=a.start,e=a.end,e===void 0&&(e=n),"selectionStart"in r)r.selectionStart=n,r.selectionEnd=Math.min(e,r.value.length);else if(e=(n=r.ownerDocument||document)&&n.defaultView||window,e.getSelection){e=e.getSelection();var s=r.textContent.length,u=Math.min(a.start,s);a=a.end===void 0?u:Math.min(a.end,s),!e.extend&&u>a&&(s=a,a=u,u=s),s=Td(r,u);var v=Td(r,a);s&&v&&(e.rangeCount!==1||e.anchorNode!==s.node||e.anchorOffset!==s.offset||e.focusNode!==v.node||e.focusOffset!==v.offset)&&(n=n.createRange(),n.setStart(s.node,s.offset),e.removeAllRanges(),u>a?(e.addRange(n),e.extend(v.node,v.offset)):(n.setEnd(v.node,v.offset),e.addRange(n)))}}for(n=[],e=r;e=e.parentNode;)e.nodeType===1&&n.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof r.focus=="function"&&r.focus(),r=0;r<n.length;r++)e=n[r],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Tg=f&&"documentMode"in document&&11>=document.documentMode,Cr=null,Ml=null,Po=null,Bl=!1;function Nd(e,n,r){var a=r.window===r?r.document:r.nodeType===9?r:r.ownerDocument;Bl||Cr==null||Cr!==vt(a)||(a=Cr,"selectionStart"in a&&Il(a)?a={start:a.selectionStart,end:a.selectionEnd}:(a=(a.ownerDocument&&a.ownerDocument.defaultView||window).getSelection(),a={anchorNode:a.anchorNode,anchorOffset:a.anchorOffset,focusNode:a.focusNode,focusOffset:a.focusOffset}),Po&&Ro(Po,a)||(Po=a,a=$i(Ml,"onSelect"),0<a.length&&(n=new Tl("onSelect","select",null,n,r),e.push({event:n,listeners:a}),n.target=Cr)))}function Mi(e,n){var r={};return r[e.toLowerCase()]=n.toLowerCase(),r["Webkit"+e]="webkit"+n,r["Moz"+e]="moz"+n,r}var Tr={animationend:Mi("Animation","AnimationEnd"),animationiteration:Mi("Animation","AnimationIteration"),animationstart:Mi("Animation","AnimationStart"),transitionend:Mi("Transition","TransitionEnd")},jl={},Ld={};f&&(Ld=document.createElement("div").style,"AnimationEvent"in window||(delete Tr.animationend.animation,delete Tr.animationiteration.animation,delete Tr.animationstart.animation),"TransitionEvent"in window||delete Tr.transitionend.transition);function Bi(e){if(jl[e])return jl[e];if(!Tr[e])return e;var n=Tr[e],r;for(r in n)if(n.hasOwnProperty(r)&&r in Ld)return jl[e]=n[r];return e}var Rd=Bi("animationend"),Pd=Bi("animationiteration"),Dd=Bi("animationstart"),Id=Bi("transitionend"),Md=new Map,Bd="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function Sn(e,n){Md.set(e,n),d(n,[e])}for(var $l=0;$l<Bd.length;$l++){var zl=Bd[$l],Og=zl.toLowerCase(),Ag=zl[0].toUpperCase()+zl.slice(1);Sn(Og,"on"+Ag)}Sn(Rd,"onAnimationEnd"),Sn(Pd,"onAnimationIteration"),Sn(Dd,"onAnimationStart"),Sn("dblclick","onDoubleClick"),Sn("focusin","onFocus"),Sn("focusout","onBlur"),Sn(Id,"onTransitionEnd"),p("onMouseEnter",["mouseout","mouseover"]),p("onMouseLeave",["mouseout","mouseover"]),p("onPointerEnter",["pointerout","pointerover"]),p("onPointerLeave",["pointerout","pointerover"]),d("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),d("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),d("onBeforeInput",["compositionend","keypress","textInput","paste"]),d("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),d("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),d("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Do="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ng=new Set("cancel close invalid load scroll toggle".split(" ").concat(Do));function jd(e,n,r){var a=e.type||"unknown-event";e.currentTarget=r,Oh(a,n,void 0,e),e.currentTarget=null}function $d(e,n){n=(n&4)!==0;for(var r=0;r<e.length;r++){var a=e[r],s=a.event;a=a.listeners;e:{var u=void 0;if(n)for(var v=a.length-1;0<=v;v--){var _=a[v],E=_.instance,A=_.currentTarget;if(_=_.listener,E!==u&&s.isPropagationStopped())break e;jd(s,_,A),u=E}else for(v=0;v<a.length;v++){if(_=a[v],E=_.instance,A=_.currentTarget,_=_.listener,E!==u&&s.isPropagationStopped())break e;jd(s,_,A),u=E}}}if(xi)throw e=gl,xi=!1,gl=null,e}function Oe(e,n){var r=n[Kl];r===void 0&&(r=n[Kl]=new Set);var a=e+"__bubble";r.has(a)||(zd(n,e,2,!1),r.add(a))}function Fl(e,n,r){var a=0;n&&(a|=4),zd(r,e,a,n)}var ji="_reactListening"+Math.random().toString(36).slice(2);function Io(e){if(!e[ji]){e[ji]=!0,l.forEach(function(r){r!=="selectionchange"&&(Ng.has(r)||Fl(r,!1,e),Fl(r,!0,e))});var n=e.nodeType===9?e:e.ownerDocument;n===null||n[ji]||(n[ji]=!0,Fl("selectionchange",!1,n))}}function zd(e,n,r,a){switch(cd(n)){case 1:var s=Hh;break;case 4:s=Wh;break;default:s=Sl}r=s.bind(null,n,r,e),s=void 0,!hl||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(s=!0),a?s!==void 0?e.addEventListener(n,r,{capture:!0,passive:s}):e.addEventListener(n,r,!0):s!==void 0?e.addEventListener(n,r,{passive:s}):e.addEventListener(n,r,!1)}function Xl(e,n,r,a,s){var u=a;if((n&1)===0&&(n&2)===0&&a!==null)e:for(;;){if(a===null)return;var v=a.tag;if(v===3||v===4){var _=a.stateNode.containerInfo;if(_===s||_.nodeType===8&&_.parentNode===s)break;if(v===4)for(v=a.return;v!==null;){var E=v.tag;if((E===3||E===4)&&(E=v.stateNode.containerInfo,E===s||E.nodeType===8&&E.parentNode===s))return;v=v.return}for(;_!==null;){if(v=Vn(_),v===null)return;if(E=v.tag,E===5||E===6){a=u=v;continue e}_=_.parentNode}}a=a.return}Wu(function(){var A=u,F=pl(r),U=[];e:{var $=Md.get(e);if($!==void 0){var q=Tl,ee=e;switch(e){case"keypress":if(Ri(r)===0)break e;case"keydown":case"keyup":q=ag;break;case"focusin":ee="focus",q=Nl;break;case"focusout":ee="blur",q=Nl;break;case"beforeblur":case"afterblur":q=Nl;break;case"click":if(r.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":q=fd;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":q=Kh;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":q=cg;break;case Rd:case Pd:case Dd:q=Qh;break;case Id:q=dg;break;case"scroll":q=Vh;break;case"wheel":q=pg;break;case"copy":case"cut":case"paste":q=Jh;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":q=md}var ne=(n&4)!==0,$e=!ne&&e==="scroll",C=ne?$!==null?$+"Capture":null:$;ne=[];for(var S=A,T;S!==null;){T=S;var W=T.stateNode;if(T.tag===5&&W!==null&&(T=W,C!==null&&(W=go(S,C),W!=null&&ne.push(Mo(S,W,T)))),$e)break;S=S.return}0<ne.length&&($=new q($,ee,null,r,F),U.push({event:$,listeners:ne}))}}if((n&7)===0){e:{if($=e==="mouseover"||e==="pointerover",q=e==="mouseout"||e==="pointerout",$&&r!==fl&&(ee=r.relatedTarget||r.fromElement)&&(Vn(ee)||ee[en]))break e;if((q||$)&&($=F.window===F?F:($=F.ownerDocument)?$.defaultView||$.parentWindow:window,q?(ee=r.relatedTarget||r.toElement,q=A,ee=ee?Vn(ee):null,ee!==null&&($e=Wn(ee),ee!==$e||ee.tag!==5&&ee.tag!==6)&&(ee=null)):(q=null,ee=A),q!==ee)){if(ne=fd,W="onMouseLeave",C="onMouseEnter",S="mouse",(e==="pointerout"||e==="pointerover")&&(ne=md,W="onPointerLeave",C="onPointerEnter",S="pointer"),$e=q==null?$:Nr(q),T=ee==null?$:Nr(ee),$=new ne(W,S+"leave",q,r,F),$.target=$e,$.relatedTarget=T,W=null,Vn(F)===A&&(ne=new ne(C,S+"enter",ee,r,F),ne.target=T,ne.relatedTarget=$e,W=ne),$e=W,q&&ee)t:{for(ne=q,C=ee,S=0,T=ne;T;T=Or(T))S++;for(T=0,W=C;W;W=Or(W))T++;for(;0<S-T;)ne=Or(ne),S--;for(;0<T-S;)C=Or(C),T--;for(;S--;){if(ne===C||C!==null&&ne===C.alternate)break t;ne=Or(ne),C=Or(C)}ne=null}else ne=null;q!==null&&Fd(U,$,q,ne,!1),ee!==null&&$e!==null&&Fd(U,$e,ee,ne,!0)}}e:{if($=A?Nr(A):window,q=$.nodeName&&$.nodeName.toLowerCase(),q==="select"||q==="input"&&$.type==="file")var ae=bg;else if(bd($))if(kd)ae=Sg;else{ae=kg;var pe=xg}else(q=$.nodeName)&&q.toLowerCase()==="input"&&($.type==="checkbox"||$.type==="radio")&&(ae=Eg);if(ae&&(ae=ae(e,A))){xd(U,ae,r,F);break e}pe&&pe(e,$,A),e==="focusout"&&(pe=$._wrapperState)&&pe.controlled&&$.type==="number"&&Ie($,"number",$.value)}switch(pe=A?Nr(A):window,e){case"focusin":(bd(pe)||pe.contentEditable==="true")&&(Cr=pe,Ml=A,Po=null);break;case"focusout":Po=Ml=Cr=null;break;case"mousedown":Bl=!0;break;case"contextmenu":case"mouseup":case"dragend":Bl=!1,Nd(U,r,F);break;case"selectionchange":if(Tg)break;case"keydown":case"keyup":Nd(U,r,F)}var me;if(Rl)e:{switch(e){case"compositionstart":var ge="onCompositionStart";break e;case"compositionend":ge="onCompositionEnd";break e;case"compositionupdate":ge="onCompositionUpdate";break e}ge=void 0}else wr?yd(e,r)&&(ge="onCompositionEnd"):e==="keydown"&&r.keyCode===229&&(ge="onCompositionStart");ge&&(vd&&r.locale!=="ko"&&(wr||ge!=="onCompositionStart"?ge==="onCompositionEnd"&&wr&&(me=ud()):(En=F,Cl="value"in En?En.value:En.textContent,wr=!0)),pe=$i(A,ge),0<pe.length&&(ge=new pd(ge,e,null,r,F),U.push({event:ge,listeners:pe}),me?ge.data=me:(me=_d(r),me!==null&&(ge.data=me)))),(me=vg?hg(e,r):gg(e,r))&&(A=$i(A,"onBeforeInput"),0<A.length&&(F=new pd("onBeforeInput","beforeinput",null,r,F),U.push({event:F,listeners:A}),F.data=me))}$d(U,n)})}function Mo(e,n,r){return{instance:e,listener:n,currentTarget:r}}function $i(e,n){for(var r=n+"Capture",a=[];e!==null;){var s=e,u=s.stateNode;s.tag===5&&u!==null&&(s=u,u=go(e,r),u!=null&&a.unshift(Mo(e,u,s)),u=go(e,n),u!=null&&a.push(Mo(e,u,s))),e=e.return}return a}function Or(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function Fd(e,n,r,a,s){for(var u=n._reactName,v=[];r!==null&&r!==a;){var _=r,E=_.alternate,A=_.stateNode;if(E!==null&&E===a)break;_.tag===5&&A!==null&&(_=A,s?(E=go(r,u),E!=null&&v.unshift(Mo(r,E,_))):s||(E=go(r,u),E!=null&&v.push(Mo(r,E,_)))),r=r.return}v.length!==0&&e.push({event:n,listeners:v})}var Lg=/\r\n?/g,Rg=/\u0000|\uFFFD/g;function Xd(e){return(typeof e=="string"?e:""+e).replace(Lg,`
`).replace(Rg,"")}function zi(e,n,r){if(n=Xd(n),Xd(e)!==n&&r)throw Error(o(425))}function Fi(){}var Ul=null,Hl=null;function Wl(e,n){return e==="textarea"||e==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var Vl=typeof setTimeout=="function"?setTimeout:void 0,Pg=typeof clearTimeout=="function"?clearTimeout:void 0,Ud=typeof Promise=="function"?Promise:void 0,Dg=typeof queueMicrotask=="function"?queueMicrotask:typeof Ud<"u"?function(e){return Ud.resolve(null).then(e).catch(Ig)}:Vl;function Ig(e){setTimeout(function(){throw e})}function Gl(e,n){var r=n,a=0;do{var s=r.nextSibling;if(e.removeChild(r),s&&s.nodeType===8)if(r=s.data,r==="/$"){if(a===0){e.removeChild(s),Co(n);return}a--}else r!=="$"&&r!=="$?"&&r!=="$!"||a++;r=s}while(r);Co(n)}function wn(e){for(;e!=null;e=e.nextSibling){var n=e.nodeType;if(n===1||n===3)break;if(n===8){if(n=e.data,n==="$"||n==="$!"||n==="$?")break;if(n==="/$")return null}}return e}function Hd(e){e=e.previousSibling;for(var n=0;e;){if(e.nodeType===8){var r=e.data;if(r==="$"||r==="$!"||r==="$?"){if(n===0)return e;n--}else r==="/$"&&n++}e=e.previousSibling}return null}var Ar=Math.random().toString(36).slice(2),Wt="__reactFiber$"+Ar,Bo="__reactProps$"+Ar,en="__reactContainer$"+Ar,Kl="__reactEvents$"+Ar,Mg="__reactListeners$"+Ar,Bg="__reactHandles$"+Ar;function Vn(e){var n=e[Wt];if(n)return n;for(var r=e.parentNode;r;){if(n=r[en]||r[Wt]){if(r=n.alternate,n.child!==null||r!==null&&r.child!==null)for(e=Hd(e);e!==null;){if(r=e[Wt])return r;e=Hd(e)}return n}e=r,r=e.parentNode}return null}function jo(e){return e=e[Wt]||e[en],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function Nr(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(o(33))}function Xi(e){return e[Bo]||null}var Yl=[],Lr=-1;function Cn(e){return{current:e}}function Ae(e){0>Lr||(e.current=Yl[Lr],Yl[Lr]=null,Lr--)}function Te(e,n){Lr++,Yl[Lr]=e.current,e.current=n}var Tn={},et=Cn(Tn),lt=Cn(!1),Gn=Tn;function Rr(e,n){var r=e.type.contextTypes;if(!r)return Tn;var a=e.stateNode;if(a&&a.__reactInternalMemoizedUnmaskedChildContext===n)return a.__reactInternalMemoizedMaskedChildContext;var s={},u;for(u in r)s[u]=n[u];return a&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=n,e.__reactInternalMemoizedMaskedChildContext=s),s}function st(e){return e=e.childContextTypes,e!=null}function Ui(){Ae(lt),Ae(et)}function Wd(e,n,r){if(et.current!==Tn)throw Error(o(168));Te(et,n),Te(lt,r)}function Vd(e,n,r){var a=e.stateNode;if(n=n.childContextTypes,typeof a.getChildContext!="function")return r;a=a.getChildContext();for(var s in a)if(!(s in n))throw Error(o(108,be(e)||"Unknown",s));return x({},r,a)}function Hi(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||Tn,Gn=et.current,Te(et,e),Te(lt,lt.current),!0}function Gd(e,n,r){var a=e.stateNode;if(!a)throw Error(o(169));r?(e=Vd(e,n,Gn),a.__reactInternalMemoizedMergedChildContext=e,Ae(lt),Ae(et),Te(et,e)):Ae(lt),Te(lt,r)}var tn=null,Wi=!1,ql=!1;function Kd(e){tn===null?tn=[e]:tn.push(e)}function jg(e){Wi=!0,Kd(e)}function On(){if(!ql&&tn!==null){ql=!0;var e=0,n=we;try{var r=tn;for(we=1;e<r.length;e++){var a=r[e];do a=a(!0);while(a!==null)}tn=null,Wi=!1}catch(s){throw tn!==null&&(tn=tn.slice(e+1)),qu(yl,On),s}finally{we=n,ql=!1}}return null}var Pr=[],Dr=0,Vi=null,Gi=0,xt=[],kt=0,Kn=null,nn=1,rn="";function Yn(e,n){Pr[Dr++]=Gi,Pr[Dr++]=Vi,Vi=e,Gi=n}function Yd(e,n,r){xt[kt++]=nn,xt[kt++]=rn,xt[kt++]=Kn,Kn=e;var a=nn;e=rn;var s=32-Rt(a)-1;a&=~(1<<s),r+=1;var u=32-Rt(n)+s;if(30<u){var v=s-s%5;u=(a&(1<<v)-1).toString(32),a>>=v,s-=v,nn=1<<32-Rt(n)+s|r<<s|a,rn=u+e}else nn=1<<u|r<<s|a,rn=e}function Ql(e){e.return!==null&&(Yn(e,1),Yd(e,1,0))}function Zl(e){for(;e===Vi;)Vi=Pr[--Dr],Pr[Dr]=null,Gi=Pr[--Dr],Pr[Dr]=null;for(;e===Kn;)Kn=xt[--kt],xt[kt]=null,rn=xt[--kt],xt[kt]=null,nn=xt[--kt],xt[kt]=null}var gt=null,yt=null,Le=!1,Dt=null;function qd(e,n){var r=Ct(5,null,null,0);r.elementType="DELETED",r.stateNode=n,r.return=e,n=e.deletions,n===null?(e.deletions=[r],e.flags|=16):n.push(r)}function Qd(e,n){switch(e.tag){case 5:var r=e.type;return n=n.nodeType!==1||r.toLowerCase()!==n.nodeName.toLowerCase()?null:n,n!==null?(e.stateNode=n,gt=e,yt=wn(n.firstChild),!0):!1;case 6:return n=e.pendingProps===""||n.nodeType!==3?null:n,n!==null?(e.stateNode=n,gt=e,yt=null,!0):!1;case 13:return n=n.nodeType!==8?null:n,n!==null?(r=Kn!==null?{id:nn,overflow:rn}:null,e.memoizedState={dehydrated:n,treeContext:r,retryLane:1073741824},r=Ct(18,null,null,0),r.stateNode=n,r.return=e,e.child=r,gt=e,yt=null,!0):!1;default:return!1}}function Jl(e){return(e.mode&1)!==0&&(e.flags&128)===0}function es(e){if(Le){var n=yt;if(n){var r=n;if(!Qd(e,n)){if(Jl(e))throw Error(o(418));n=wn(r.nextSibling);var a=gt;n&&Qd(e,n)?qd(a,r):(e.flags=e.flags&-4097|2,Le=!1,gt=e)}}else{if(Jl(e))throw Error(o(418));e.flags=e.flags&-4097|2,Le=!1,gt=e}}}function Zd(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;gt=e}function Ki(e){if(e!==gt)return!1;if(!Le)return Zd(e),Le=!0,!1;var n;if((n=e.tag!==3)&&!(n=e.tag!==5)&&(n=e.type,n=n!=="head"&&n!=="body"&&!Wl(e.type,e.memoizedProps)),n&&(n=yt)){if(Jl(e))throw Jd(),Error(o(418));for(;n;)qd(e,n),n=wn(n.nextSibling)}if(Zd(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(o(317));e:{for(e=e.nextSibling,n=0;e;){if(e.nodeType===8){var r=e.data;if(r==="/$"){if(n===0){yt=wn(e.nextSibling);break e}n--}else r!=="$"&&r!=="$!"&&r!=="$?"||n++}e=e.nextSibling}yt=null}}else yt=gt?wn(e.stateNode.nextSibling):null;return!0}function Jd(){for(var e=yt;e;)e=wn(e.nextSibling)}function Ir(){yt=gt=null,Le=!1}function ts(e){Dt===null?Dt=[e]:Dt.push(e)}var $g=I.ReactCurrentBatchConfig;function It(e,n){if(e&&e.defaultProps){n=x({},n),e=e.defaultProps;for(var r in e)n[r]===void 0&&(n[r]=e[r]);return n}return n}var Yi=Cn(null),qi=null,Mr=null,ns=null;function rs(){ns=Mr=qi=null}function os(e){var n=Yi.current;Ae(Yi),e._currentValue=n}function is(e,n,r){for(;e!==null;){var a=e.alternate;if((e.childLanes&n)!==n?(e.childLanes|=n,a!==null&&(a.childLanes|=n)):a!==null&&(a.childLanes&n)!==n&&(a.childLanes|=n),e===r)break;e=e.return}}function Br(e,n){qi=e,ns=Mr=null,e=e.dependencies,e!==null&&e.firstContext!==null&&((e.lanes&n)!==0&&(ct=!0),e.firstContext=null)}function Et(e){var n=e._currentValue;if(ns!==e)if(e={context:e,memoizedValue:n,next:null},Mr===null){if(qi===null)throw Error(o(308));Mr=e,qi.dependencies={lanes:0,firstContext:e}}else Mr=Mr.next=e;return n}var qn=null;function as(e){qn===null?qn=[e]:qn.push(e)}function ef(e,n,r,a){var s=n.interleaved;return s===null?(r.next=r,as(n)):(r.next=s.next,s.next=r),n.interleaved=r,on(e,a)}function on(e,n){e.lanes|=n;var r=e.alternate;for(r!==null&&(r.lanes|=n),r=e,e=e.return;e!==null;)e.childLanes|=n,r=e.alternate,r!==null&&(r.childLanes|=n),r=e,e=e.return;return r.tag===3?r.stateNode:null}var An=!1;function ls(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function tf(e,n){e=e.updateQueue,n.updateQueue===e&&(n.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function an(e,n){return{eventTime:e,lane:n,tag:0,payload:null,callback:null,next:null}}function Nn(e,n,r){var a=e.updateQueue;if(a===null)return null;if(a=a.shared,(ke&2)!==0){var s=a.pending;return s===null?n.next=n:(n.next=s.next,s.next=n),a.pending=n,on(e,r)}return s=a.interleaved,s===null?(n.next=n,as(a)):(n.next=s.next,s.next=n),a.interleaved=n,on(e,r)}function Qi(e,n,r){if(n=n.updateQueue,n!==null&&(n=n.shared,(r&4194240)!==0)){var a=n.lanes;a&=e.pendingLanes,r|=a,n.lanes=r,xl(e,r)}}function nf(e,n){var r=e.updateQueue,a=e.alternate;if(a!==null&&(a=a.updateQueue,r===a)){var s=null,u=null;if(r=r.firstBaseUpdate,r!==null){do{var v={eventTime:r.eventTime,lane:r.lane,tag:r.tag,payload:r.payload,callback:r.callback,next:null};u===null?s=u=v:u=u.next=v,r=r.next}while(r!==null);u===null?s=u=n:u=u.next=n}else s=u=n;r={baseState:a.baseState,firstBaseUpdate:s,lastBaseUpdate:u,shared:a.shared,effects:a.effects},e.updateQueue=r;return}e=r.lastBaseUpdate,e===null?r.firstBaseUpdate=n:e.next=n,r.lastBaseUpdate=n}function Zi(e,n,r,a){var s=e.updateQueue;An=!1;var u=s.firstBaseUpdate,v=s.lastBaseUpdate,_=s.shared.pending;if(_!==null){s.shared.pending=null;var E=_,A=E.next;E.next=null,v===null?u=A:v.next=A,v=E;var F=e.alternate;F!==null&&(F=F.updateQueue,_=F.lastBaseUpdate,_!==v&&(_===null?F.firstBaseUpdate=A:_.next=A,F.lastBaseUpdate=E))}if(u!==null){var U=s.baseState;v=0,F=A=E=null,_=u;do{var $=_.lane,q=_.eventTime;if((a&$)===$){F!==null&&(F=F.next={eventTime:q,lane:0,tag:_.tag,payload:_.payload,callback:_.callback,next:null});e:{var ee=e,ne=_;switch($=n,q=r,ne.tag){case 1:if(ee=ne.payload,typeof ee=="function"){U=ee.call(q,U,$);break e}U=ee;break e;case 3:ee.flags=ee.flags&-65537|128;case 0:if(ee=ne.payload,$=typeof ee=="function"?ee.call(q,U,$):ee,$==null)break e;U=x({},U,$);break e;case 2:An=!0}}_.callback!==null&&_.lane!==0&&(e.flags|=64,$=s.effects,$===null?s.effects=[_]:$.push(_))}else q={eventTime:q,lane:$,tag:_.tag,payload:_.payload,callback:_.callback,next:null},F===null?(A=F=q,E=U):F=F.next=q,v|=$;if(_=_.next,_===null){if(_=s.shared.pending,_===null)break;$=_,_=$.next,$.next=null,s.lastBaseUpdate=$,s.shared.pending=null}}while(!0);if(F===null&&(E=U),s.baseState=E,s.firstBaseUpdate=A,s.lastBaseUpdate=F,n=s.shared.interleaved,n!==null){s=n;do v|=s.lane,s=s.next;while(s!==n)}else u===null&&(s.shared.lanes=0);Jn|=v,e.lanes=v,e.memoizedState=U}}function rf(e,n,r){if(e=n.effects,n.effects=null,e!==null)for(n=0;n<e.length;n++){var a=e[n],s=a.callback;if(s!==null){if(a.callback=null,a=r,typeof s!="function")throw Error(o(191,s));s.call(a)}}}var of=new t.Component().refs;function ss(e,n,r,a){n=e.memoizedState,r=r(a,n),r=r==null?n:x({},n,r),e.memoizedState=r,e.lanes===0&&(e.updateQueue.baseState=r)}var Ji={isMounted:function(e){return(e=e._reactInternals)?Wn(e)===e:!1},enqueueSetState:function(e,n,r){e=e._reactInternals;var a=it(),s=Dn(e),u=an(a,s);u.payload=n,r!=null&&(u.callback=r),n=Nn(e,u,s),n!==null&&(jt(n,e,s,a),Qi(n,e,s))},enqueueReplaceState:function(e,n,r){e=e._reactInternals;var a=it(),s=Dn(e),u=an(a,s);u.tag=1,u.payload=n,r!=null&&(u.callback=r),n=Nn(e,u,s),n!==null&&(jt(n,e,s,a),Qi(n,e,s))},enqueueForceUpdate:function(e,n){e=e._reactInternals;var r=it(),a=Dn(e),s=an(r,a);s.tag=2,n!=null&&(s.callback=n),n=Nn(e,s,a),n!==null&&(jt(n,e,a,r),Qi(n,e,a))}};function af(e,n,r,a,s,u,v){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(a,u,v):n.prototype&&n.prototype.isPureReactComponent?!Ro(r,a)||!Ro(s,u):!0}function lf(e,n,r){var a=!1,s=Tn,u=n.contextType;return typeof u=="object"&&u!==null?u=Et(u):(s=st(n)?Gn:et.current,a=n.contextTypes,u=(a=a!=null)?Rr(e,s):Tn),n=new n(r,u),e.memoizedState=n.state!==null&&n.state!==void 0?n.state:null,n.updater=Ji,e.stateNode=n,n._reactInternals=e,a&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=s,e.__reactInternalMemoizedMaskedChildContext=u),n}function sf(e,n,r,a){e=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(r,a),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(r,a),n.state!==e&&Ji.enqueueReplaceState(n,n.state,null)}function cs(e,n,r,a){var s=e.stateNode;s.props=r,s.state=e.memoizedState,s.refs=of,ls(e);var u=n.contextType;typeof u=="object"&&u!==null?s.context=Et(u):(u=st(n)?Gn:et.current,s.context=Rr(e,u)),s.state=e.memoizedState,u=n.getDerivedStateFromProps,typeof u=="function"&&(ss(e,n,u,r),s.state=e.memoizedState),typeof n.getDerivedStateFromProps=="function"||typeof s.getSnapshotBeforeUpdate=="function"||typeof s.UNSAFE_componentWillMount!="function"&&typeof s.componentWillMount!="function"||(n=s.state,typeof s.componentWillMount=="function"&&s.componentWillMount(),typeof s.UNSAFE_componentWillMount=="function"&&s.UNSAFE_componentWillMount(),n!==s.state&&Ji.enqueueReplaceState(s,s.state,null),Zi(e,r,s,a),s.state=e.memoizedState),typeof s.componentDidMount=="function"&&(e.flags|=4194308)}function $o(e,n,r){if(e=r.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(r._owner){if(r=r._owner,r){if(r.tag!==1)throw Error(o(309));var a=r.stateNode}if(!a)throw Error(o(147,e));var s=a,u=""+e;return n!==null&&n.ref!==null&&typeof n.ref=="function"&&n.ref._stringRef===u?n.ref:(n=function(v){var _=s.refs;_===of&&(_=s.refs={}),v===null?delete _[u]:_[u]=v},n._stringRef=u,n)}if(typeof e!="string")throw Error(o(284));if(!r._owner)throw Error(o(290,e))}return e}function ea(e,n){throw e=Object.prototype.toString.call(n),Error(o(31,e==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":e))}function cf(e){var n=e._init;return n(e._payload)}function uf(e){function n(C,S){if(e){var T=C.deletions;T===null?(C.deletions=[S],C.flags|=16):T.push(S)}}function r(C,S){if(!e)return null;for(;S!==null;)n(C,S),S=S.sibling;return null}function a(C,S){for(C=new Map;S!==null;)S.key!==null?C.set(S.key,S):C.set(S.index,S),S=S.sibling;return C}function s(C,S){return C=Mn(C,S),C.index=0,C.sibling=null,C}function u(C,S,T){return C.index=T,e?(T=C.alternate,T!==null?(T=T.index,T<S?(C.flags|=2,S):T):(C.flags|=2,S)):(C.flags|=1048576,S)}function v(C){return e&&C.alternate===null&&(C.flags|=2),C}function _(C,S,T,W){return S===null||S.tag!==6?(S=Vs(T,C.mode,W),S.return=C,S):(S=s(S,T),S.return=C,S)}function E(C,S,T,W){var ae=T.type;return ae===X?F(C,S,T.props.children,W,T.key):S!==null&&(S.elementType===ae||typeof ae=="object"&&ae!==null&&ae.$$typeof===re&&cf(ae)===S.type)?(W=s(S,T.props),W.ref=$o(C,S,T),W.return=C,W):(W=_a(T.type,T.key,T.props,null,C.mode,W),W.ref=$o(C,S,T),W.return=C,W)}function A(C,S,T,W){return S===null||S.tag!==4||S.stateNode.containerInfo!==T.containerInfo||S.stateNode.implementation!==T.implementation?(S=Gs(T,C.mode,W),S.return=C,S):(S=s(S,T.children||[]),S.return=C,S)}function F(C,S,T,W,ae){return S===null||S.tag!==7?(S=rr(T,C.mode,W,ae),S.return=C,S):(S=s(S,T),S.return=C,S)}function U(C,S,T){if(typeof S=="string"&&S!==""||typeof S=="number")return S=Vs(""+S,C.mode,T),S.return=C,S;if(typeof S=="object"&&S!==null){switch(S.$$typeof){case B:return T=_a(S.type,S.key,S.props,null,C.mode,T),T.ref=$o(C,null,S),T.return=C,T;case j:return S=Gs(S,C.mode,T),S.return=C,S;case re:var W=S._init;return U(C,W(S._payload),T)}if(Je(S)||V(S))return S=rr(S,C.mode,T,null),S.return=C,S;ea(C,S)}return null}function $(C,S,T,W){var ae=S!==null?S.key:null;if(typeof T=="string"&&T!==""||typeof T=="number")return ae!==null?null:_(C,S,""+T,W);if(typeof T=="object"&&T!==null){switch(T.$$typeof){case B:return T.key===ae?E(C,S,T,W):null;case j:return T.key===ae?A(C,S,T,W):null;case re:return ae=T._init,$(C,S,ae(T._payload),W)}if(Je(T)||V(T))return ae!==null?null:F(C,S,T,W,null);ea(C,T)}return null}function q(C,S,T,W,ae){if(typeof W=="string"&&W!==""||typeof W=="number")return C=C.get(T)||null,_(S,C,""+W,ae);if(typeof W=="object"&&W!==null){switch(W.$$typeof){case B:return C=C.get(W.key===null?T:W.key)||null,E(S,C,W,ae);case j:return C=C.get(W.key===null?T:W.key)||null,A(S,C,W,ae);case re:var pe=W._init;return q(C,S,T,pe(W._payload),ae)}if(Je(W)||V(W))return C=C.get(T)||null,F(S,C,W,ae,null);ea(S,W)}return null}function ee(C,S,T,W){for(var ae=null,pe=null,me=S,ge=S=0,Ke=null;me!==null&&ge<T.length;ge++){me.index>ge?(Ke=me,me=null):Ke=me.sibling;var Ee=$(C,me,T[ge],W);if(Ee===null){me===null&&(me=Ke);break}e&&me&&Ee.alternate===null&&n(C,me),S=u(Ee,S,ge),pe===null?ae=Ee:pe.sibling=Ee,pe=Ee,me=Ke}if(ge===T.length)return r(C,me),Le&&Yn(C,ge),ae;if(me===null){for(;ge<T.length;ge++)me=U(C,T[ge],W),me!==null&&(S=u(me,S,ge),pe===null?ae=me:pe.sibling=me,pe=me);return Le&&Yn(C,ge),ae}for(me=a(C,me);ge<T.length;ge++)Ke=q(me,C,ge,T[ge],W),Ke!==null&&(e&&Ke.alternate!==null&&me.delete(Ke.key===null?ge:Ke.key),S=u(Ke,S,ge),pe===null?ae=Ke:pe.sibling=Ke,pe=Ke);return e&&me.forEach(function(Bn){return n(C,Bn)}),Le&&Yn(C,ge),ae}function ne(C,S,T,W){var ae=V(T);if(typeof ae!="function")throw Error(o(150));if(T=ae.call(T),T==null)throw Error(o(151));for(var pe=ae=null,me=S,ge=S=0,Ke=null,Ee=T.next();me!==null&&!Ee.done;ge++,Ee=T.next()){me.index>ge?(Ke=me,me=null):Ke=me.sibling;var Bn=$(C,me,Ee.value,W);if(Bn===null){me===null&&(me=Ke);break}e&&me&&Bn.alternate===null&&n(C,me),S=u(Bn,S,ge),pe===null?ae=Bn:pe.sibling=Bn,pe=Bn,me=Ke}if(Ee.done)return r(C,me),Le&&Yn(C,ge),ae;if(me===null){for(;!Ee.done;ge++,Ee=T.next())Ee=U(C,Ee.value,W),Ee!==null&&(S=u(Ee,S,ge),pe===null?ae=Ee:pe.sibling=Ee,pe=Ee);return Le&&Yn(C,ge),ae}for(me=a(C,me);!Ee.done;ge++,Ee=T.next())Ee=q(me,C,ge,Ee.value,W),Ee!==null&&(e&&Ee.alternate!==null&&me.delete(Ee.key===null?ge:Ee.key),S=u(Ee,S,ge),pe===null?ae=Ee:pe.sibling=Ee,pe=Ee);return e&&me.forEach(function(y0){return n(C,y0)}),Le&&Yn(C,ge),ae}function $e(C,S,T,W){if(typeof T=="object"&&T!==null&&T.type===X&&T.key===null&&(T=T.props.children),typeof T=="object"&&T!==null){switch(T.$$typeof){case B:e:{for(var ae=T.key,pe=S;pe!==null;){if(pe.key===ae){if(ae=T.type,ae===X){if(pe.tag===7){r(C,pe.sibling),S=s(pe,T.props.children),S.return=C,C=S;break e}}else if(pe.elementType===ae||typeof ae=="object"&&ae!==null&&ae.$$typeof===re&&cf(ae)===pe.type){r(C,pe.sibling),S=s(pe,T.props),S.ref=$o(C,pe,T),S.return=C,C=S;break e}r(C,pe);break}else n(C,pe);pe=pe.sibling}T.type===X?(S=rr(T.props.children,C.mode,W,T.key),S.return=C,C=S):(W=_a(T.type,T.key,T.props,null,C.mode,W),W.ref=$o(C,S,T),W.return=C,C=W)}return v(C);case j:e:{for(pe=T.key;S!==null;){if(S.key===pe)if(S.tag===4&&S.stateNode.containerInfo===T.containerInfo&&S.stateNode.implementation===T.implementation){r(C,S.sibling),S=s(S,T.children||[]),S.return=C,C=S;break e}else{r(C,S);break}else n(C,S);S=S.sibling}S=Gs(T,C.mode,W),S.return=C,C=S}return v(C);case re:return pe=T._init,$e(C,S,pe(T._payload),W)}if(Je(T))return ee(C,S,T,W);if(V(T))return ne(C,S,T,W);ea(C,T)}return typeof T=="string"&&T!==""||typeof T=="number"?(T=""+T,S!==null&&S.tag===6?(r(C,S.sibling),S=s(S,T),S.return=C,C=S):(r(C,S),S=Vs(T,C.mode,W),S.return=C,C=S),v(C)):r(C,S)}return $e}var jr=uf(!0),df=uf(!1),zo={},Vt=Cn(zo),Fo=Cn(zo),Xo=Cn(zo);function Qn(e){if(e===zo)throw Error(o(174));return e}function us(e,n){switch(Te(Xo,n),Te(Fo,e),Te(Vt,zo),e=n.nodeType,e){case 9:case 11:n=(n=n.documentElement)?n.namespaceURI:br(null,"");break;default:e=e===8?n.parentNode:n,n=e.namespaceURI||null,e=e.tagName,n=br(n,e)}Ae(Vt),Te(Vt,n)}function $r(){Ae(Vt),Ae(Fo),Ae(Xo)}function ff(e){Qn(Xo.current);var n=Qn(Vt.current),r=br(n,e.type);n!==r&&(Te(Fo,e),Te(Vt,r))}function ds(e){Fo.current===e&&(Ae(Vt),Ae(Fo))}var Re=Cn(0);function ta(e){for(var n=e;n!==null;){if(n.tag===13){var r=n.memoizedState;if(r!==null&&(r=r.dehydrated,r===null||r.data==="$?"||r.data==="$!"))return n}else if(n.tag===19&&n.memoizedProps.revealOrder!==void 0){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var fs=[];function ps(){for(var e=0;e<fs.length;e++)fs[e]._workInProgressVersionPrimary=null;fs.length=0}var na=I.ReactCurrentDispatcher,ms=I.ReactCurrentBatchConfig,Zn=0,Pe=null,He=null,Ve=null,ra=!1,Uo=!1,Ho=0,zg=0;function tt(){throw Error(o(321))}function vs(e,n){if(n===null)return!1;for(var r=0;r<n.length&&r<e.length;r++)if(!Pt(e[r],n[r]))return!1;return!0}function hs(e,n,r,a,s,u){if(Zn=u,Pe=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,na.current=e===null||e.memoizedState===null?Hg:Wg,e=r(a,s),Uo){u=0;do{if(Uo=!1,Ho=0,25<=u)throw Error(o(301));u+=1,Ve=He=null,n.updateQueue=null,na.current=Vg,e=r(a,s)}while(Uo)}if(na.current=aa,n=He!==null&&He.next!==null,Zn=0,Ve=He=Pe=null,ra=!1,n)throw Error(o(300));return e}function gs(){var e=Ho!==0;return Ho=0,e}function Gt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Ve===null?Pe.memoizedState=Ve=e:Ve=Ve.next=e,Ve}function St(){if(He===null){var e=Pe.alternate;e=e!==null?e.memoizedState:null}else e=He.next;var n=Ve===null?Pe.memoizedState:Ve.next;if(n!==null)Ve=n,He=e;else{if(e===null)throw Error(o(310));He=e,e={memoizedState:He.memoizedState,baseState:He.baseState,baseQueue:He.baseQueue,queue:He.queue,next:null},Ve===null?Pe.memoizedState=Ve=e:Ve=Ve.next=e}return Ve}function Wo(e,n){return typeof n=="function"?n(e):n}function ys(e){var n=St(),r=n.queue;if(r===null)throw Error(o(311));r.lastRenderedReducer=e;var a=He,s=a.baseQueue,u=r.pending;if(u!==null){if(s!==null){var v=s.next;s.next=u.next,u.next=v}a.baseQueue=s=u,r.pending=null}if(s!==null){u=s.next,a=a.baseState;var _=v=null,E=null,A=u;do{var F=A.lane;if((Zn&F)===F)E!==null&&(E=E.next={lane:0,action:A.action,hasEagerState:A.hasEagerState,eagerState:A.eagerState,next:null}),a=A.hasEagerState?A.eagerState:e(a,A.action);else{var U={lane:F,action:A.action,hasEagerState:A.hasEagerState,eagerState:A.eagerState,next:null};E===null?(_=E=U,v=a):E=E.next=U,Pe.lanes|=F,Jn|=F}A=A.next}while(A!==null&&A!==u);E===null?v=a:E.next=_,Pt(a,n.memoizedState)||(ct=!0),n.memoizedState=a,n.baseState=v,n.baseQueue=E,r.lastRenderedState=a}if(e=r.interleaved,e!==null){s=e;do u=s.lane,Pe.lanes|=u,Jn|=u,s=s.next;while(s!==e)}else s===null&&(r.lanes=0);return[n.memoizedState,r.dispatch]}function _s(e){var n=St(),r=n.queue;if(r===null)throw Error(o(311));r.lastRenderedReducer=e;var a=r.dispatch,s=r.pending,u=n.memoizedState;if(s!==null){r.pending=null;var v=s=s.next;do u=e(u,v.action),v=v.next;while(v!==s);Pt(u,n.memoizedState)||(ct=!0),n.memoizedState=u,n.baseQueue===null&&(n.baseState=u),r.lastRenderedState=u}return[u,a]}function pf(){}function mf(e,n){var r=Pe,a=St(),s=n(),u=!Pt(a.memoizedState,s);if(u&&(a.memoizedState=s,ct=!0),a=a.queue,bs(gf.bind(null,r,a,e),[e]),a.getSnapshot!==n||u||Ve!==null&&Ve.memoizedState.tag&1){if(r.flags|=2048,Vo(9,hf.bind(null,r,a,s,n),void 0,null),Ge===null)throw Error(o(349));(Zn&30)!==0||vf(r,n,s)}return s}function vf(e,n,r){e.flags|=16384,e={getSnapshot:n,value:r},n=Pe.updateQueue,n===null?(n={lastEffect:null,stores:null},Pe.updateQueue=n,n.stores=[e]):(r=n.stores,r===null?n.stores=[e]:r.push(e))}function hf(e,n,r,a){n.value=r,n.getSnapshot=a,yf(n)&&_f(e)}function gf(e,n,r){return r(function(){yf(n)&&_f(e)})}function yf(e){var n=e.getSnapshot;e=e.value;try{var r=n();return!Pt(e,r)}catch{return!0}}function _f(e){var n=on(e,1);n!==null&&jt(n,e,1,-1)}function bf(e){var n=Gt();return typeof e=="function"&&(e=e()),n.memoizedState=n.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Wo,lastRenderedState:e},n.queue=e,e=e.dispatch=Ug.bind(null,Pe,e),[n.memoizedState,e]}function Vo(e,n,r,a){return e={tag:e,create:n,destroy:r,deps:a,next:null},n=Pe.updateQueue,n===null?(n={lastEffect:null,stores:null},Pe.updateQueue=n,n.lastEffect=e.next=e):(r=n.lastEffect,r===null?n.lastEffect=e.next=e:(a=r.next,r.next=e,e.next=a,n.lastEffect=e)),e}function xf(){return St().memoizedState}function oa(e,n,r,a){var s=Gt();Pe.flags|=e,s.memoizedState=Vo(1|n,r,void 0,a===void 0?null:a)}function ia(e,n,r,a){var s=St();a=a===void 0?null:a;var u=void 0;if(He!==null){var v=He.memoizedState;if(u=v.destroy,a!==null&&vs(a,v.deps)){s.memoizedState=Vo(n,r,u,a);return}}Pe.flags|=e,s.memoizedState=Vo(1|n,r,u,a)}function kf(e,n){return oa(8390656,8,e,n)}function bs(e,n){return ia(2048,8,e,n)}function Ef(e,n){return ia(4,2,e,n)}function Sf(e,n){return ia(4,4,e,n)}function wf(e,n){if(typeof n=="function")return e=e(),n(e),function(){n(null)};if(n!=null)return e=e(),n.current=e,function(){n.current=null}}function Cf(e,n,r){return r=r!=null?r.concat([e]):null,ia(4,4,wf.bind(null,n,e),r)}function xs(){}function Tf(e,n){var r=St();n=n===void 0?null:n;var a=r.memoizedState;return a!==null&&n!==null&&vs(n,a[1])?a[0]:(r.memoizedState=[e,n],e)}function Of(e,n){var r=St();n=n===void 0?null:n;var a=r.memoizedState;return a!==null&&n!==null&&vs(n,a[1])?a[0]:(e=e(),r.memoizedState=[e,n],e)}function Af(e,n,r){return(Zn&21)===0?(e.baseState&&(e.baseState=!1,ct=!0),e.memoizedState=r):(Pt(r,n)||(r=ed(),Pe.lanes|=r,Jn|=r,e.baseState=!0),n)}function Fg(e,n){var r=we;we=r!==0&&4>r?r:4,e(!0);var a=ms.transition;ms.transition={};try{e(!1),n()}finally{we=r,ms.transition=a}}function Nf(){return St().memoizedState}function Xg(e,n,r){var a=Dn(e);if(r={lane:a,action:r,hasEagerState:!1,eagerState:null,next:null},Lf(e))Rf(n,r);else if(r=ef(e,n,r,a),r!==null){var s=it();jt(r,e,a,s),Pf(r,n,a)}}function Ug(e,n,r){var a=Dn(e),s={lane:a,action:r,hasEagerState:!1,eagerState:null,next:null};if(Lf(e))Rf(n,s);else{var u=e.alternate;if(e.lanes===0&&(u===null||u.lanes===0)&&(u=n.lastRenderedReducer,u!==null))try{var v=n.lastRenderedState,_=u(v,r);if(s.hasEagerState=!0,s.eagerState=_,Pt(_,v)){var E=n.interleaved;E===null?(s.next=s,as(n)):(s.next=E.next,E.next=s),n.interleaved=s;return}}catch{}finally{}r=ef(e,n,s,a),r!==null&&(s=it(),jt(r,e,a,s),Pf(r,n,a))}}function Lf(e){var n=e.alternate;return e===Pe||n!==null&&n===Pe}function Rf(e,n){Uo=ra=!0;var r=e.pending;r===null?n.next=n:(n.next=r.next,r.next=n),e.pending=n}function Pf(e,n,r){if((r&4194240)!==0){var a=n.lanes;a&=e.pendingLanes,r|=a,n.lanes=r,xl(e,r)}}var aa={readContext:Et,useCallback:tt,useContext:tt,useEffect:tt,useImperativeHandle:tt,useInsertionEffect:tt,useLayoutEffect:tt,useMemo:tt,useReducer:tt,useRef:tt,useState:tt,useDebugValue:tt,useDeferredValue:tt,useTransition:tt,useMutableSource:tt,useSyncExternalStore:tt,useId:tt,unstable_isNewReconciler:!1},Hg={readContext:Et,useCallback:function(e,n){return Gt().memoizedState=[e,n===void 0?null:n],e},useContext:Et,useEffect:kf,useImperativeHandle:function(e,n,r){return r=r!=null?r.concat([e]):null,oa(4194308,4,wf.bind(null,n,e),r)},useLayoutEffect:function(e,n){return oa(4194308,4,e,n)},useInsertionEffect:function(e,n){return oa(4,2,e,n)},useMemo:function(e,n){var r=Gt();return n=n===void 0?null:n,e=e(),r.memoizedState=[e,n],e},useReducer:function(e,n,r){var a=Gt();return n=r!==void 0?r(n):n,a.memoizedState=a.baseState=n,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:n},a.queue=e,e=e.dispatch=Xg.bind(null,Pe,e),[a.memoizedState,e]},useRef:function(e){var n=Gt();return e={current:e},n.memoizedState=e},useState:bf,useDebugValue:xs,useDeferredValue:function(e){return Gt().memoizedState=e},useTransition:function(){var e=bf(!1),n=e[0];return e=Fg.bind(null,e[1]),Gt().memoizedState=e,[n,e]},useMutableSource:function(){},useSyncExternalStore:function(e,n,r){var a=Pe,s=Gt();if(Le){if(r===void 0)throw Error(o(407));r=r()}else{if(r=n(),Ge===null)throw Error(o(349));(Zn&30)!==0||vf(a,n,r)}s.memoizedState=r;var u={value:r,getSnapshot:n};return s.queue=u,kf(gf.bind(null,a,u,e),[e]),a.flags|=2048,Vo(9,hf.bind(null,a,u,r,n),void 0,null),r},useId:function(){var e=Gt(),n=Ge.identifierPrefix;if(Le){var r=rn,a=nn;r=(a&~(1<<32-Rt(a)-1)).toString(32)+r,n=":"+n+"R"+r,r=Ho++,0<r&&(n+="H"+r.toString(32)),n+=":"}else r=zg++,n=":"+n+"r"+r.toString(32)+":";return e.memoizedState=n},unstable_isNewReconciler:!1},Wg={readContext:Et,useCallback:Tf,useContext:Et,useEffect:bs,useImperativeHandle:Cf,useInsertionEffect:Ef,useLayoutEffect:Sf,useMemo:Of,useReducer:ys,useRef:xf,useState:function(){return ys(Wo)},useDebugValue:xs,useDeferredValue:function(e){var n=St();return Af(n,He.memoizedState,e)},useTransition:function(){var e=ys(Wo)[0],n=St().memoizedState;return[e,n]},useMutableSource:pf,useSyncExternalStore:mf,useId:Nf,unstable_isNewReconciler:!1},Vg={readContext:Et,useCallback:Tf,useContext:Et,useEffect:bs,useImperativeHandle:Cf,useInsertionEffect:Ef,useLayoutEffect:Sf,useMemo:Of,useReducer:_s,useRef:xf,useState:function(){return _s(Wo)},useDebugValue:xs,useDeferredValue:function(e){var n=St();return He===null?n.memoizedState=e:Af(n,He.memoizedState,e)},useTransition:function(){var e=_s(Wo)[0],n=St().memoizedState;return[e,n]},useMutableSource:pf,useSyncExternalStore:mf,useId:Nf,unstable_isNewReconciler:!1};function zr(e,n){try{var r="",a=n;do r+=ye(a),a=a.return;while(a);var s=r}catch(u){s=`
Error generating stack: `+u.message+`
`+u.stack}return{value:e,source:n,stack:s,digest:null}}function ks(e,n,r){return{value:e,source:null,stack:r??null,digest:n??null}}function Es(e,n){try{console.error(n.value)}catch(r){setTimeout(function(){throw r})}}var Gg=typeof WeakMap=="function"?WeakMap:Map;function Df(e,n,r){r=an(-1,r),r.tag=3,r.payload={element:null};var a=n.value;return r.callback=function(){pa||(pa=!0,js=a),Es(e,n)},r}function If(e,n,r){r=an(-1,r),r.tag=3;var a=e.type.getDerivedStateFromError;if(typeof a=="function"){var s=n.value;r.payload=function(){return a(s)},r.callback=function(){Es(e,n)}}var u=e.stateNode;return u!==null&&typeof u.componentDidCatch=="function"&&(r.callback=function(){Es(e,n),typeof a!="function"&&(Rn===null?Rn=new Set([this]):Rn.add(this));var v=n.stack;this.componentDidCatch(n.value,{componentStack:v!==null?v:""})}),r}function Mf(e,n,r){var a=e.pingCache;if(a===null){a=e.pingCache=new Gg;var s=new Set;a.set(n,s)}else s=a.get(n),s===void 0&&(s=new Set,a.set(n,s));s.has(r)||(s.add(r),e=l0.bind(null,e,n,r),n.then(e,e))}function Bf(e){do{var n;if((n=e.tag===13)&&(n=e.memoizedState,n=n!==null?n.dehydrated!==null:!0),n)return e;e=e.return}while(e!==null);return null}function jf(e,n,r,a,s){return(e.mode&1)===0?(e===n?e.flags|=65536:(e.flags|=128,r.flags|=131072,r.flags&=-52805,r.tag===1&&(r.alternate===null?r.tag=17:(n=an(-1,1),n.tag=2,Nn(r,n,1))),r.lanes|=1),e):(e.flags|=65536,e.lanes=s,e)}var Kg=I.ReactCurrentOwner,ct=!1;function ot(e,n,r,a){n.child=e===null?df(n,null,r,a):jr(n,e.child,r,a)}function $f(e,n,r,a,s){r=r.render;var u=n.ref;return Br(n,s),a=hs(e,n,r,a,u,s),r=gs(),e!==null&&!ct?(n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~s,ln(e,n,s)):(Le&&r&&Ql(n),n.flags|=1,ot(e,n,a,s),n.child)}function zf(e,n,r,a,s){if(e===null){var u=r.type;return typeof u=="function"&&!Ws(u)&&u.defaultProps===void 0&&r.compare===null&&r.defaultProps===void 0?(n.tag=15,n.type=u,Ff(e,n,u,a,s)):(e=_a(r.type,null,a,n,n.mode,s),e.ref=n.ref,e.return=n,n.child=e)}if(u=e.child,(e.lanes&s)===0){var v=u.memoizedProps;if(r=r.compare,r=r!==null?r:Ro,r(v,a)&&e.ref===n.ref)return ln(e,n,s)}return n.flags|=1,e=Mn(u,a),e.ref=n.ref,e.return=n,n.child=e}function Ff(e,n,r,a,s){if(e!==null){var u=e.memoizedProps;if(Ro(u,a)&&e.ref===n.ref)if(ct=!1,n.pendingProps=a=u,(e.lanes&s)!==0)(e.flags&131072)!==0&&(ct=!0);else return n.lanes=e.lanes,ln(e,n,s)}return Ss(e,n,r,a,s)}function Xf(e,n,r){var a=n.pendingProps,s=a.children,u=e!==null?e.memoizedState:null;if(a.mode==="hidden")if((n.mode&1)===0)n.memoizedState={baseLanes:0,cachePool:null,transitions:null},Te(Xr,_t),_t|=r;else{if((r&1073741824)===0)return e=u!==null?u.baseLanes|r:r,n.lanes=n.childLanes=1073741824,n.memoizedState={baseLanes:e,cachePool:null,transitions:null},n.updateQueue=null,Te(Xr,_t),_t|=e,null;n.memoizedState={baseLanes:0,cachePool:null,transitions:null},a=u!==null?u.baseLanes:r,Te(Xr,_t),_t|=a}else u!==null?(a=u.baseLanes|r,n.memoizedState=null):a=r,Te(Xr,_t),_t|=a;return ot(e,n,s,r),n.child}function Uf(e,n){var r=n.ref;(e===null&&r!==null||e!==null&&e.ref!==r)&&(n.flags|=512,n.flags|=2097152)}function Ss(e,n,r,a,s){var u=st(r)?Gn:et.current;return u=Rr(n,u),Br(n,s),r=hs(e,n,r,a,u,s),a=gs(),e!==null&&!ct?(n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~s,ln(e,n,s)):(Le&&a&&Ql(n),n.flags|=1,ot(e,n,r,s),n.child)}function Hf(e,n,r,a,s){if(st(r)){var u=!0;Hi(n)}else u=!1;if(Br(n,s),n.stateNode===null)sa(e,n),lf(n,r,a),cs(n,r,a,s),a=!0;else if(e===null){var v=n.stateNode,_=n.memoizedProps;v.props=_;var E=v.context,A=r.contextType;typeof A=="object"&&A!==null?A=Et(A):(A=st(r)?Gn:et.current,A=Rr(n,A));var F=r.getDerivedStateFromProps,U=typeof F=="function"||typeof v.getSnapshotBeforeUpdate=="function";U||typeof v.UNSAFE_componentWillReceiveProps!="function"&&typeof v.componentWillReceiveProps!="function"||(_!==a||E!==A)&&sf(n,v,a,A),An=!1;var $=n.memoizedState;v.state=$,Zi(n,a,v,s),E=n.memoizedState,_!==a||$!==E||lt.current||An?(typeof F=="function"&&(ss(n,r,F,a),E=n.memoizedState),(_=An||af(n,r,_,a,$,E,A))?(U||typeof v.UNSAFE_componentWillMount!="function"&&typeof v.componentWillMount!="function"||(typeof v.componentWillMount=="function"&&v.componentWillMount(),typeof v.UNSAFE_componentWillMount=="function"&&v.UNSAFE_componentWillMount()),typeof v.componentDidMount=="function"&&(n.flags|=4194308)):(typeof v.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=a,n.memoizedState=E),v.props=a,v.state=E,v.context=A,a=_):(typeof v.componentDidMount=="function"&&(n.flags|=4194308),a=!1)}else{v=n.stateNode,tf(e,n),_=n.memoizedProps,A=n.type===n.elementType?_:It(n.type,_),v.props=A,U=n.pendingProps,$=v.context,E=r.contextType,typeof E=="object"&&E!==null?E=Et(E):(E=st(r)?Gn:et.current,E=Rr(n,E));var q=r.getDerivedStateFromProps;(F=typeof q=="function"||typeof v.getSnapshotBeforeUpdate=="function")||typeof v.UNSAFE_componentWillReceiveProps!="function"&&typeof v.componentWillReceiveProps!="function"||(_!==U||$!==E)&&sf(n,v,a,E),An=!1,$=n.memoizedState,v.state=$,Zi(n,a,v,s);var ee=n.memoizedState;_!==U||$!==ee||lt.current||An?(typeof q=="function"&&(ss(n,r,q,a),ee=n.memoizedState),(A=An||af(n,r,A,a,$,ee,E)||!1)?(F||typeof v.UNSAFE_componentWillUpdate!="function"&&typeof v.componentWillUpdate!="function"||(typeof v.componentWillUpdate=="function"&&v.componentWillUpdate(a,ee,E),typeof v.UNSAFE_componentWillUpdate=="function"&&v.UNSAFE_componentWillUpdate(a,ee,E)),typeof v.componentDidUpdate=="function"&&(n.flags|=4),typeof v.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof v.componentDidUpdate!="function"||_===e.memoizedProps&&$===e.memoizedState||(n.flags|=4),typeof v.getSnapshotBeforeUpdate!="function"||_===e.memoizedProps&&$===e.memoizedState||(n.flags|=1024),n.memoizedProps=a,n.memoizedState=ee),v.props=a,v.state=ee,v.context=E,a=A):(typeof v.componentDidUpdate!="function"||_===e.memoizedProps&&$===e.memoizedState||(n.flags|=4),typeof v.getSnapshotBeforeUpdate!="function"||_===e.memoizedProps&&$===e.memoizedState||(n.flags|=1024),a=!1)}return ws(e,n,r,a,u,s)}function ws(e,n,r,a,s,u){Uf(e,n);var v=(n.flags&128)!==0;if(!a&&!v)return s&&Gd(n,r,!1),ln(e,n,u);a=n.stateNode,Kg.current=n;var _=v&&typeof r.getDerivedStateFromError!="function"?null:a.render();return n.flags|=1,e!==null&&v?(n.child=jr(n,e.child,null,u),n.child=jr(n,null,_,u)):ot(e,n,_,u),n.memoizedState=a.state,s&&Gd(n,r,!0),n.child}function Wf(e){var n=e.stateNode;n.pendingContext?Wd(e,n.pendingContext,n.pendingContext!==n.context):n.context&&Wd(e,n.context,!1),us(e,n.containerInfo)}function Vf(e,n,r,a,s){return Ir(),ts(s),n.flags|=256,ot(e,n,r,a),n.child}var Cs={dehydrated:null,treeContext:null,retryLane:0};function Ts(e){return{baseLanes:e,cachePool:null,transitions:null}}function Gf(e,n,r){var a=n.pendingProps,s=Re.current,u=!1,v=(n.flags&128)!==0,_;if((_=v)||(_=e!==null&&e.memoizedState===null?!1:(s&2)!==0),_?(u=!0,n.flags&=-129):(e===null||e.memoizedState!==null)&&(s|=1),Te(Re,s&1),e===null)return es(n),e=n.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?((n.mode&1)===0?n.lanes=1:e.data==="$!"?n.lanes=8:n.lanes=1073741824,null):(v=a.children,e=a.fallback,u?(a=n.mode,u=n.child,v={mode:"hidden",children:v},(a&1)===0&&u!==null?(u.childLanes=0,u.pendingProps=v):u=ba(v,a,0,null),e=rr(e,a,r,null),u.return=n,e.return=n,u.sibling=e,n.child=u,n.child.memoizedState=Ts(r),n.memoizedState=Cs,e):Os(n,v));if(s=e.memoizedState,s!==null&&(_=s.dehydrated,_!==null))return Yg(e,n,v,a,_,s,r);if(u){u=a.fallback,v=n.mode,s=e.child,_=s.sibling;var E={mode:"hidden",children:a.children};return(v&1)===0&&n.child!==s?(a=n.child,a.childLanes=0,a.pendingProps=E,n.deletions=null):(a=Mn(s,E),a.subtreeFlags=s.subtreeFlags&14680064),_!==null?u=Mn(_,u):(u=rr(u,v,r,null),u.flags|=2),u.return=n,a.return=n,a.sibling=u,n.child=a,a=u,u=n.child,v=e.child.memoizedState,v=v===null?Ts(r):{baseLanes:v.baseLanes|r,cachePool:null,transitions:v.transitions},u.memoizedState=v,u.childLanes=e.childLanes&~r,n.memoizedState=Cs,a}return u=e.child,e=u.sibling,a=Mn(u,{mode:"visible",children:a.children}),(n.mode&1)===0&&(a.lanes=r),a.return=n,a.sibling=null,e!==null&&(r=n.deletions,r===null?(n.deletions=[e],n.flags|=16):r.push(e)),n.child=a,n.memoizedState=null,a}function Os(e,n){return n=ba({mode:"visible",children:n},e.mode,0,null),n.return=e,e.child=n}function la(e,n,r,a){return a!==null&&ts(a),jr(n,e.child,null,r),e=Os(n,n.pendingProps.children),e.flags|=2,n.memoizedState=null,e}function Yg(e,n,r,a,s,u,v){if(r)return n.flags&256?(n.flags&=-257,a=ks(Error(o(422))),la(e,n,v,a)):n.memoizedState!==null?(n.child=e.child,n.flags|=128,null):(u=a.fallback,s=n.mode,a=ba({mode:"visible",children:a.children},s,0,null),u=rr(u,s,v,null),u.flags|=2,a.return=n,u.return=n,a.sibling=u,n.child=a,(n.mode&1)!==0&&jr(n,e.child,null,v),n.child.memoizedState=Ts(v),n.memoizedState=Cs,u);if((n.mode&1)===0)return la(e,n,v,null);if(s.data==="$!"){if(a=s.nextSibling&&s.nextSibling.dataset,a)var _=a.dgst;return a=_,u=Error(o(419)),a=ks(u,a,void 0),la(e,n,v,a)}if(_=(v&e.childLanes)!==0,ct||_){if(a=Ge,a!==null){switch(v&-v){case 4:s=2;break;case 16:s=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:s=32;break;case 536870912:s=268435456;break;default:s=0}s=(s&(a.suspendedLanes|v))!==0?0:s,s!==0&&s!==u.retryLane&&(u.retryLane=s,on(e,s),jt(a,e,s,-1))}return Hs(),a=ks(Error(o(421))),la(e,n,v,a)}return s.data==="$?"?(n.flags|=128,n.child=e.child,n=s0.bind(null,e),s._reactRetry=n,null):(e=u.treeContext,yt=wn(s.nextSibling),gt=n,Le=!0,Dt=null,e!==null&&(xt[kt++]=nn,xt[kt++]=rn,xt[kt++]=Kn,nn=e.id,rn=e.overflow,Kn=n),n=Os(n,a.children),n.flags|=4096,n)}function Kf(e,n,r){e.lanes|=n;var a=e.alternate;a!==null&&(a.lanes|=n),is(e.return,n,r)}function As(e,n,r,a,s){var u=e.memoizedState;u===null?e.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:a,tail:r,tailMode:s}:(u.isBackwards=n,u.rendering=null,u.renderingStartTime=0,u.last=a,u.tail=r,u.tailMode=s)}function Yf(e,n,r){var a=n.pendingProps,s=a.revealOrder,u=a.tail;if(ot(e,n,a.children,r),a=Re.current,(a&2)!==0)a=a&1|2,n.flags|=128;else{if(e!==null&&(e.flags&128)!==0)e:for(e=n.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Kf(e,r,n);else if(e.tag===19)Kf(e,r,n);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===n)break e;for(;e.sibling===null;){if(e.return===null||e.return===n)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}a&=1}if(Te(Re,a),(n.mode&1)===0)n.memoizedState=null;else switch(s){case"forwards":for(r=n.child,s=null;r!==null;)e=r.alternate,e!==null&&ta(e)===null&&(s=r),r=r.sibling;r=s,r===null?(s=n.child,n.child=null):(s=r.sibling,r.sibling=null),As(n,!1,s,r,u);break;case"backwards":for(r=null,s=n.child,n.child=null;s!==null;){if(e=s.alternate,e!==null&&ta(e)===null){n.child=s;break}e=s.sibling,s.sibling=r,r=s,s=e}As(n,!0,r,null,u);break;case"together":As(n,!1,null,null,void 0);break;default:n.memoizedState=null}return n.child}function sa(e,n){(n.mode&1)===0&&e!==null&&(e.alternate=null,n.alternate=null,n.flags|=2)}function ln(e,n,r){if(e!==null&&(n.dependencies=e.dependencies),Jn|=n.lanes,(r&n.childLanes)===0)return null;if(e!==null&&n.child!==e.child)throw Error(o(153));if(n.child!==null){for(e=n.child,r=Mn(e,e.pendingProps),n.child=r,r.return=n;e.sibling!==null;)e=e.sibling,r=r.sibling=Mn(e,e.pendingProps),r.return=n;r.sibling=null}return n.child}function qg(e,n,r){switch(n.tag){case 3:Wf(n),Ir();break;case 5:ff(n);break;case 1:st(n.type)&&Hi(n);break;case 4:us(n,n.stateNode.containerInfo);break;case 10:var a=n.type._context,s=n.memoizedProps.value;Te(Yi,a._currentValue),a._currentValue=s;break;case 13:if(a=n.memoizedState,a!==null)return a.dehydrated!==null?(Te(Re,Re.current&1),n.flags|=128,null):(r&n.child.childLanes)!==0?Gf(e,n,r):(Te(Re,Re.current&1),e=ln(e,n,r),e!==null?e.sibling:null);Te(Re,Re.current&1);break;case 19:if(a=(r&n.childLanes)!==0,(e.flags&128)!==0){if(a)return Yf(e,n,r);n.flags|=128}if(s=n.memoizedState,s!==null&&(s.rendering=null,s.tail=null,s.lastEffect=null),Te(Re,Re.current),a)break;return null;case 22:case 23:return n.lanes=0,Xf(e,n,r)}return ln(e,n,r)}var qf,Ns,Qf,Zf;qf=function(e,n){for(var r=n.child;r!==null;){if(r.tag===5||r.tag===6)e.appendChild(r.stateNode);else if(r.tag!==4&&r.child!==null){r.child.return=r,r=r.child;continue}if(r===n)break;for(;r.sibling===null;){if(r.return===null||r.return===n)return;r=r.return}r.sibling.return=r.return,r=r.sibling}},Ns=function(){},Qf=function(e,n,r,a){var s=e.memoizedProps;if(s!==a){e=n.stateNode,Qn(Vt.current);var u=null;switch(r){case"input":s=hn(e,s),a=hn(e,a),u=[];break;case"select":s=x({},s,{value:void 0}),a=x({},a,{value:void 0}),u=[];break;case"textarea":s=yr(e,s),a=yr(e,a),u=[];break;default:typeof s.onClick!="function"&&typeof a.onClick=="function"&&(e.onclick=Fi)}ul(r,a);var v;r=null;for(A in s)if(!a.hasOwnProperty(A)&&s.hasOwnProperty(A)&&s[A]!=null)if(A==="style"){var _=s[A];for(v in _)_.hasOwnProperty(v)&&(r||(r={}),r[v]="")}else A!=="dangerouslySetInnerHTML"&&A!=="children"&&A!=="suppressContentEditableWarning"&&A!=="suppressHydrationWarning"&&A!=="autoFocus"&&(c.hasOwnProperty(A)?u||(u=[]):(u=u||[]).push(A,null));for(A in a){var E=a[A];if(_=s!=null?s[A]:void 0,a.hasOwnProperty(A)&&E!==_&&(E!=null||_!=null))if(A==="style")if(_){for(v in _)!_.hasOwnProperty(v)||E&&E.hasOwnProperty(v)||(r||(r={}),r[v]="");for(v in E)E.hasOwnProperty(v)&&_[v]!==E[v]&&(r||(r={}),r[v]=E[v])}else r||(u||(u=[]),u.push(A,r)),r=E;else A==="dangerouslySetInnerHTML"?(E=E?E.__html:void 0,_=_?_.__html:void 0,E!=null&&_!==E&&(u=u||[]).push(A,E)):A==="children"?typeof E!="string"&&typeof E!="number"||(u=u||[]).push(A,""+E):A!=="suppressContentEditableWarning"&&A!=="suppressHydrationWarning"&&(c.hasOwnProperty(A)?(E!=null&&A==="onScroll"&&Oe("scroll",e),u||_===E||(u=[])):(u=u||[]).push(A,E))}r&&(u=u||[]).push("style",r);var A=u;(n.updateQueue=A)&&(n.flags|=4)}},Zf=function(e,n,r,a){r!==a&&(n.flags|=4)};function Go(e,n){if(!Le)switch(e.tailMode){case"hidden":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?e.tail=null:r.sibling=null;break;case"collapsed":r=e.tail;for(var a=null;r!==null;)r.alternate!==null&&(a=r),r=r.sibling;a===null?n||e.tail===null?e.tail=null:e.tail.sibling=null:a.sibling=null}}function nt(e){var n=e.alternate!==null&&e.alternate.child===e.child,r=0,a=0;if(n)for(var s=e.child;s!==null;)r|=s.lanes|s.childLanes,a|=s.subtreeFlags&14680064,a|=s.flags&14680064,s.return=e,s=s.sibling;else for(s=e.child;s!==null;)r|=s.lanes|s.childLanes,a|=s.subtreeFlags,a|=s.flags,s.return=e,s=s.sibling;return e.subtreeFlags|=a,e.childLanes=r,n}function Qg(e,n,r){var a=n.pendingProps;switch(Zl(n),n.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return nt(n),null;case 1:return st(n.type)&&Ui(),nt(n),null;case 3:return a=n.stateNode,$r(),Ae(lt),Ae(et),ps(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(e===null||e.child===null)&&(Ki(n)?n.flags|=4:e===null||e.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Dt!==null&&(Fs(Dt),Dt=null))),Ns(e,n),nt(n),null;case 5:ds(n);var s=Qn(Xo.current);if(r=n.type,e!==null&&n.stateNode!=null)Qf(e,n,r,a,s),e.ref!==n.ref&&(n.flags|=512,n.flags|=2097152);else{if(!a){if(n.stateNode===null)throw Error(o(166));return nt(n),null}if(e=Qn(Vt.current),Ki(n)){a=n.stateNode,r=n.type;var u=n.memoizedProps;switch(a[Wt]=n,a[Bo]=u,e=(n.mode&1)!==0,r){case"dialog":Oe("cancel",a),Oe("close",a);break;case"iframe":case"object":case"embed":Oe("load",a);break;case"video":case"audio":for(s=0;s<Do.length;s++)Oe(Do[s],a);break;case"source":Oe("error",a);break;case"img":case"image":case"link":Oe("error",a),Oe("load",a);break;case"details":Oe("toggle",a);break;case"input":gn(a,u),Oe("invalid",a);break;case"select":a._wrapperState={wasMultiple:!!u.multiple},Oe("invalid",a);break;case"textarea":fo(a,u),Oe("invalid",a)}ul(r,u),s=null;for(var v in u)if(u.hasOwnProperty(v)){var _=u[v];v==="children"?typeof _=="string"?a.textContent!==_&&(u.suppressHydrationWarning!==!0&&zi(a.textContent,_,e),s=["children",_]):typeof _=="number"&&a.textContent!==""+_&&(u.suppressHydrationWarning!==!0&&zi(a.textContent,_,e),s=["children",""+_]):c.hasOwnProperty(v)&&_!=null&&v==="onScroll"&&Oe("scroll",a)}switch(r){case"input":Ue(a),yn(a,u,!0);break;case"textarea":Ue(a),po(a);break;case"select":case"option":break;default:typeof u.onClick=="function"&&(a.onclick=Fi)}a=s,n.updateQueue=a,a!==null&&(n.flags|=4)}else{v=s.nodeType===9?s:s.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=mo(r)),e==="http://www.w3.org/1999/xhtml"?r==="script"?(e=v.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof a.is=="string"?e=v.createElement(r,{is:a.is}):(e=v.createElement(r),r==="select"&&(v=e,a.multiple?v.multiple=!0:a.size&&(v.size=a.size))):e=v.createElementNS(e,r),e[Wt]=n,e[Bo]=a,qf(e,n,!1,!1),n.stateNode=e;e:{switch(v=dl(r,a),r){case"dialog":Oe("cancel",e),Oe("close",e),s=a;break;case"iframe":case"object":case"embed":Oe("load",e),s=a;break;case"video":case"audio":for(s=0;s<Do.length;s++)Oe(Do[s],e);s=a;break;case"source":Oe("error",e),s=a;break;case"img":case"image":case"link":Oe("error",e),Oe("load",e),s=a;break;case"details":Oe("toggle",e),s=a;break;case"input":gn(e,a),s=hn(e,a),Oe("invalid",e);break;case"option":s=a;break;case"select":e._wrapperState={wasMultiple:!!a.multiple},s=x({},a,{value:void 0}),Oe("invalid",e);break;case"textarea":fo(e,a),s=yr(e,a),Oe("invalid",e);break;default:s=a}ul(r,s),_=s;for(u in _)if(_.hasOwnProperty(u)){var E=_[u];u==="style"?$u(e,E):u==="dangerouslySetInnerHTML"?(E=E?E.__html:void 0,E!=null&&Bu(e,E)):u==="children"?typeof E=="string"?(r!=="textarea"||E!=="")&&vo(e,E):typeof E=="number"&&vo(e,""+E):u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&u!=="autoFocus"&&(c.hasOwnProperty(u)?E!=null&&u==="onScroll"&&Oe("scroll",e):E!=null&&z(e,u,E,v))}switch(r){case"input":Ue(e),yn(e,a,!1);break;case"textarea":Ue(e),po(e);break;case"option":a.value!=null&&e.setAttribute("value",""+Y(a.value));break;case"select":e.multiple=!!a.multiple,u=a.value,u!=null?Lt(e,!!a.multiple,u,!1):a.defaultValue!=null&&Lt(e,!!a.multiple,a.defaultValue,!0);break;default:typeof s.onClick=="function"&&(e.onclick=Fi)}switch(r){case"button":case"input":case"select":case"textarea":a=!!a.autoFocus;break e;case"img":a=!0;break e;default:a=!1}}a&&(n.flags|=4)}n.ref!==null&&(n.flags|=512,n.flags|=2097152)}return nt(n),null;case 6:if(e&&n.stateNode!=null)Zf(e,n,e.memoizedProps,a);else{if(typeof a!="string"&&n.stateNode===null)throw Error(o(166));if(r=Qn(Xo.current),Qn(Vt.current),Ki(n)){if(a=n.stateNode,r=n.memoizedProps,a[Wt]=n,(u=a.nodeValue!==r)&&(e=gt,e!==null))switch(e.tag){case 3:zi(a.nodeValue,r,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&zi(a.nodeValue,r,(e.mode&1)!==0)}u&&(n.flags|=4)}else a=(r.nodeType===9?r:r.ownerDocument).createTextNode(a),a[Wt]=n,n.stateNode=a}return nt(n),null;case 13:if(Ae(Re),a=n.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(Le&&yt!==null&&(n.mode&1)!==0&&(n.flags&128)===0)Jd(),Ir(),n.flags|=98560,u=!1;else if(u=Ki(n),a!==null&&a.dehydrated!==null){if(e===null){if(!u)throw Error(o(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(o(317));u[Wt]=n}else Ir(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;nt(n),u=!1}else Dt!==null&&(Fs(Dt),Dt=null),u=!0;if(!u)return n.flags&65536?n:null}return(n.flags&128)!==0?(n.lanes=r,n):(a=a!==null,a!==(e!==null&&e.memoizedState!==null)&&a&&(n.child.flags|=8192,(n.mode&1)!==0&&(e===null||(Re.current&1)!==0?We===0&&(We=3):Hs())),n.updateQueue!==null&&(n.flags|=4),nt(n),null);case 4:return $r(),Ns(e,n),e===null&&Io(n.stateNode.containerInfo),nt(n),null;case 10:return os(n.type._context),nt(n),null;case 17:return st(n.type)&&Ui(),nt(n),null;case 19:if(Ae(Re),u=n.memoizedState,u===null)return nt(n),null;if(a=(n.flags&128)!==0,v=u.rendering,v===null)if(a)Go(u,!1);else{if(We!==0||e!==null&&(e.flags&128)!==0)for(e=n.child;e!==null;){if(v=ta(e),v!==null){for(n.flags|=128,Go(u,!1),a=v.updateQueue,a!==null&&(n.updateQueue=a,n.flags|=4),n.subtreeFlags=0,a=r,r=n.child;r!==null;)u=r,e=a,u.flags&=14680066,v=u.alternate,v===null?(u.childLanes=0,u.lanes=e,u.child=null,u.subtreeFlags=0,u.memoizedProps=null,u.memoizedState=null,u.updateQueue=null,u.dependencies=null,u.stateNode=null):(u.childLanes=v.childLanes,u.lanes=v.lanes,u.child=v.child,u.subtreeFlags=0,u.deletions=null,u.memoizedProps=v.memoizedProps,u.memoizedState=v.memoizedState,u.updateQueue=v.updateQueue,u.type=v.type,e=v.dependencies,u.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),r=r.sibling;return Te(Re,Re.current&1|2),n.child}e=e.sibling}u.tail!==null&&je()>Ur&&(n.flags|=128,a=!0,Go(u,!1),n.lanes=4194304)}else{if(!a)if(e=ta(v),e!==null){if(n.flags|=128,a=!0,r=e.updateQueue,r!==null&&(n.updateQueue=r,n.flags|=4),Go(u,!0),u.tail===null&&u.tailMode==="hidden"&&!v.alternate&&!Le)return nt(n),null}else 2*je()-u.renderingStartTime>Ur&&r!==1073741824&&(n.flags|=128,a=!0,Go(u,!1),n.lanes=4194304);u.isBackwards?(v.sibling=n.child,n.child=v):(r=u.last,r!==null?r.sibling=v:n.child=v,u.last=v)}return u.tail!==null?(n=u.tail,u.rendering=n,u.tail=n.sibling,u.renderingStartTime=je(),n.sibling=null,r=Re.current,Te(Re,a?r&1|2:r&1),n):(nt(n),null);case 22:case 23:return Us(),a=n.memoizedState!==null,e!==null&&e.memoizedState!==null!==a&&(n.flags|=8192),a&&(n.mode&1)!==0?(_t&1073741824)!==0&&(nt(n),n.subtreeFlags&6&&(n.flags|=8192)):nt(n),null;case 24:return null;case 25:return null}throw Error(o(156,n.tag))}function Zg(e,n){switch(Zl(n),n.tag){case 1:return st(n.type)&&Ui(),e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 3:return $r(),Ae(lt),Ae(et),ps(),e=n.flags,(e&65536)!==0&&(e&128)===0?(n.flags=e&-65537|128,n):null;case 5:return ds(n),null;case 13:if(Ae(Re),e=n.memoizedState,e!==null&&e.dehydrated!==null){if(n.alternate===null)throw Error(o(340));Ir()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 19:return Ae(Re),null;case 4:return $r(),null;case 10:return os(n.type._context),null;case 22:case 23:return Us(),null;case 24:return null;default:return null}}var ca=!1,rt=!1,Jg=typeof WeakSet=="function"?WeakSet:Set,J=null;function Fr(e,n){var r=e.ref;if(r!==null)if(typeof r=="function")try{r(null)}catch(a){Me(e,n,a)}else r.current=null}function Ls(e,n,r){try{r()}catch(a){Me(e,n,a)}}var Jf=!1;function e0(e,n){if(Ul=Ai,e=Ad(),Il(e)){if("selectionStart"in e)var r={start:e.selectionStart,end:e.selectionEnd};else e:{r=(r=e.ownerDocument)&&r.defaultView||window;var a=r.getSelection&&r.getSelection();if(a&&a.rangeCount!==0){r=a.anchorNode;var s=a.anchorOffset,u=a.focusNode;a=a.focusOffset;try{r.nodeType,u.nodeType}catch{r=null;break e}var v=0,_=-1,E=-1,A=0,F=0,U=e,$=null;t:for(;;){for(var q;U!==r||s!==0&&U.nodeType!==3||(_=v+s),U!==u||a!==0&&U.nodeType!==3||(E=v+a),U.nodeType===3&&(v+=U.nodeValue.length),(q=U.firstChild)!==null;)$=U,U=q;for(;;){if(U===e)break t;if($===r&&++A===s&&(_=v),$===u&&++F===a&&(E=v),(q=U.nextSibling)!==null)break;U=$,$=U.parentNode}U=q}r=_===-1||E===-1?null:{start:_,end:E}}else r=null}r=r||{start:0,end:0}}else r=null;for(Hl={focusedElem:e,selectionRange:r},Ai=!1,J=n;J!==null;)if(n=J,e=n.child,(n.subtreeFlags&1028)!==0&&e!==null)e.return=n,J=e;else for(;J!==null;){n=J;try{var ee=n.alternate;if((n.flags&1024)!==0)switch(n.tag){case 0:case 11:case 15:break;case 1:if(ee!==null){var ne=ee.memoizedProps,$e=ee.memoizedState,C=n.stateNode,S=C.getSnapshotBeforeUpdate(n.elementType===n.type?ne:It(n.type,ne),$e);C.__reactInternalSnapshotBeforeUpdate=S}break;case 3:var T=n.stateNode.containerInfo;T.nodeType===1?T.textContent="":T.nodeType===9&&T.documentElement&&T.removeChild(T.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(o(163))}}catch(W){Me(n,n.return,W)}if(e=n.sibling,e!==null){e.return=n.return,J=e;break}J=n.return}return ee=Jf,Jf=!1,ee}function Ko(e,n,r){var a=n.updateQueue;if(a=a!==null?a.lastEffect:null,a!==null){var s=a=a.next;do{if((s.tag&e)===e){var u=s.destroy;s.destroy=void 0,u!==void 0&&Ls(n,r,u)}s=s.next}while(s!==a)}}function ua(e,n){if(n=n.updateQueue,n=n!==null?n.lastEffect:null,n!==null){var r=n=n.next;do{if((r.tag&e)===e){var a=r.create;r.destroy=a()}r=r.next}while(r!==n)}}function Rs(e){var n=e.ref;if(n!==null){var r=e.stateNode;switch(e.tag){case 5:e=r;break;default:e=r}typeof n=="function"?n(e):n.current=e}}function ep(e){var n=e.alternate;n!==null&&(e.alternate=null,ep(n)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(n=e.stateNode,n!==null&&(delete n[Wt],delete n[Bo],delete n[Kl],delete n[Mg],delete n[Bg])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function tp(e){return e.tag===5||e.tag===3||e.tag===4}function np(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||tp(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ps(e,n,r){var a=e.tag;if(a===5||a===6)e=e.stateNode,n?r.nodeType===8?r.parentNode.insertBefore(e,n):r.insertBefore(e,n):(r.nodeType===8?(n=r.parentNode,n.insertBefore(e,r)):(n=r,n.appendChild(e)),r=r._reactRootContainer,r!=null||n.onclick!==null||(n.onclick=Fi));else if(a!==4&&(e=e.child,e!==null))for(Ps(e,n,r),e=e.sibling;e!==null;)Ps(e,n,r),e=e.sibling}function Ds(e,n,r){var a=e.tag;if(a===5||a===6)e=e.stateNode,n?r.insertBefore(e,n):r.appendChild(e);else if(a!==4&&(e=e.child,e!==null))for(Ds(e,n,r),e=e.sibling;e!==null;)Ds(e,n,r),e=e.sibling}var Ye=null,Mt=!1;function Ln(e,n,r){for(r=r.child;r!==null;)rp(e,n,r),r=r.sibling}function rp(e,n,r){if(Ht&&typeof Ht.onCommitFiberUnmount=="function")try{Ht.onCommitFiberUnmount(Ei,r)}catch{}switch(r.tag){case 5:rt||Fr(r,n);case 6:var a=Ye,s=Mt;Ye=null,Ln(e,n,r),Ye=a,Mt=s,Ye!==null&&(Mt?(e=Ye,r=r.stateNode,e.nodeType===8?e.parentNode.removeChild(r):e.removeChild(r)):Ye.removeChild(r.stateNode));break;case 18:Ye!==null&&(Mt?(e=Ye,r=r.stateNode,e.nodeType===8?Gl(e.parentNode,r):e.nodeType===1&&Gl(e,r),Co(e)):Gl(Ye,r.stateNode));break;case 4:a=Ye,s=Mt,Ye=r.stateNode.containerInfo,Mt=!0,Ln(e,n,r),Ye=a,Mt=s;break;case 0:case 11:case 14:case 15:if(!rt&&(a=r.updateQueue,a!==null&&(a=a.lastEffect,a!==null))){s=a=a.next;do{var u=s,v=u.destroy;u=u.tag,v!==void 0&&((u&2)!==0||(u&4)!==0)&&Ls(r,n,v),s=s.next}while(s!==a)}Ln(e,n,r);break;case 1:if(!rt&&(Fr(r,n),a=r.stateNode,typeof a.componentWillUnmount=="function"))try{a.props=r.memoizedProps,a.state=r.memoizedState,a.componentWillUnmount()}catch(_){Me(r,n,_)}Ln(e,n,r);break;case 21:Ln(e,n,r);break;case 22:r.mode&1?(rt=(a=rt)||r.memoizedState!==null,Ln(e,n,r),rt=a):Ln(e,n,r);break;default:Ln(e,n,r)}}function op(e){var n=e.updateQueue;if(n!==null){e.updateQueue=null;var r=e.stateNode;r===null&&(r=e.stateNode=new Jg),n.forEach(function(a){var s=c0.bind(null,e,a);r.has(a)||(r.add(a),a.then(s,s))})}}function Bt(e,n){var r=n.deletions;if(r!==null)for(var a=0;a<r.length;a++){var s=r[a];try{var u=e,v=n,_=v;e:for(;_!==null;){switch(_.tag){case 5:Ye=_.stateNode,Mt=!1;break e;case 3:Ye=_.stateNode.containerInfo,Mt=!0;break e;case 4:Ye=_.stateNode.containerInfo,Mt=!0;break e}_=_.return}if(Ye===null)throw Error(o(160));rp(u,v,s),Ye=null,Mt=!1;var E=s.alternate;E!==null&&(E.return=null),s.return=null}catch(A){Me(s,n,A)}}if(n.subtreeFlags&12854)for(n=n.child;n!==null;)ip(n,e),n=n.sibling}function ip(e,n){var r=e.alternate,a=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Bt(n,e),Kt(e),a&4){try{Ko(3,e,e.return),ua(3,e)}catch(ne){Me(e,e.return,ne)}try{Ko(5,e,e.return)}catch(ne){Me(e,e.return,ne)}}break;case 1:Bt(n,e),Kt(e),a&512&&r!==null&&Fr(r,r.return);break;case 5:if(Bt(n,e),Kt(e),a&512&&r!==null&&Fr(r,r.return),e.flags&32){var s=e.stateNode;try{vo(s,"")}catch(ne){Me(e,e.return,ne)}}if(a&4&&(s=e.stateNode,s!=null)){var u=e.memoizedProps,v=r!==null?r.memoizedProps:u,_=e.type,E=e.updateQueue;if(e.updateQueue=null,E!==null)try{_==="input"&&u.type==="radio"&&u.name!=null&&Xt(s,u),dl(_,v);var A=dl(_,u);for(v=0;v<E.length;v+=2){var F=E[v],U=E[v+1];F==="style"?$u(s,U):F==="dangerouslySetInnerHTML"?Bu(s,U):F==="children"?vo(s,U):z(s,F,U,A)}switch(_){case"input":Ut(s,u);break;case"textarea":_r(s,u);break;case"select":var $=s._wrapperState.wasMultiple;s._wrapperState.wasMultiple=!!u.multiple;var q=u.value;q!=null?Lt(s,!!u.multiple,q,!1):$!==!!u.multiple&&(u.defaultValue!=null?Lt(s,!!u.multiple,u.defaultValue,!0):Lt(s,!!u.multiple,u.multiple?[]:"",!1))}s[Bo]=u}catch(ne){Me(e,e.return,ne)}}break;case 6:if(Bt(n,e),Kt(e),a&4){if(e.stateNode===null)throw Error(o(162));s=e.stateNode,u=e.memoizedProps;try{s.nodeValue=u}catch(ne){Me(e,e.return,ne)}}break;case 3:if(Bt(n,e),Kt(e),a&4&&r!==null&&r.memoizedState.isDehydrated)try{Co(n.containerInfo)}catch(ne){Me(e,e.return,ne)}break;case 4:Bt(n,e),Kt(e);break;case 13:Bt(n,e),Kt(e),s=e.child,s.flags&8192&&(u=s.memoizedState!==null,s.stateNode.isHidden=u,!u||s.alternate!==null&&s.alternate.memoizedState!==null||(Bs=je())),a&4&&op(e);break;case 22:if(F=r!==null&&r.memoizedState!==null,e.mode&1?(rt=(A=rt)||F,Bt(n,e),rt=A):Bt(n,e),Kt(e),a&8192){if(A=e.memoizedState!==null,(e.stateNode.isHidden=A)&&!F&&(e.mode&1)!==0)for(J=e,F=e.child;F!==null;){for(U=J=F;J!==null;){switch($=J,q=$.child,$.tag){case 0:case 11:case 14:case 15:Ko(4,$,$.return);break;case 1:Fr($,$.return);var ee=$.stateNode;if(typeof ee.componentWillUnmount=="function"){a=$,r=$.return;try{n=a,ee.props=n.memoizedProps,ee.state=n.memoizedState,ee.componentWillUnmount()}catch(ne){Me(a,r,ne)}}break;case 5:Fr($,$.return);break;case 22:if($.memoizedState!==null){sp(U);continue}}q!==null?(q.return=$,J=q):sp(U)}F=F.sibling}e:for(F=null,U=e;;){if(U.tag===5){if(F===null){F=U;try{s=U.stateNode,A?(u=s.style,typeof u.setProperty=="function"?u.setProperty("display","none","important"):u.display="none"):(_=U.stateNode,E=U.memoizedProps.style,v=E!=null&&E.hasOwnProperty("display")?E.display:null,_.style.display=ju("display",v))}catch(ne){Me(e,e.return,ne)}}}else if(U.tag===6){if(F===null)try{U.stateNode.nodeValue=A?"":U.memoizedProps}catch(ne){Me(e,e.return,ne)}}else if((U.tag!==22&&U.tag!==23||U.memoizedState===null||U===e)&&U.child!==null){U.child.return=U,U=U.child;continue}if(U===e)break e;for(;U.sibling===null;){if(U.return===null||U.return===e)break e;F===U&&(F=null),U=U.return}F===U&&(F=null),U.sibling.return=U.return,U=U.sibling}}break;case 19:Bt(n,e),Kt(e),a&4&&op(e);break;case 21:break;default:Bt(n,e),Kt(e)}}function Kt(e){var n=e.flags;if(n&2){try{e:{for(var r=e.return;r!==null;){if(tp(r)){var a=r;break e}r=r.return}throw Error(o(160))}switch(a.tag){case 5:var s=a.stateNode;a.flags&32&&(vo(s,""),a.flags&=-33);var u=np(e);Ds(e,u,s);break;case 3:case 4:var v=a.stateNode.containerInfo,_=np(e);Ps(e,_,v);break;default:throw Error(o(161))}}catch(E){Me(e,e.return,E)}e.flags&=-3}n&4096&&(e.flags&=-4097)}function t0(e,n,r){J=e,ap(e)}function ap(e,n,r){for(var a=(e.mode&1)!==0;J!==null;){var s=J,u=s.child;if(s.tag===22&&a){var v=s.memoizedState!==null||ca;if(!v){var _=s.alternate,E=_!==null&&_.memoizedState!==null||rt;_=ca;var A=rt;if(ca=v,(rt=E)&&!A)for(J=s;J!==null;)v=J,E=v.child,v.tag===22&&v.memoizedState!==null?cp(s):E!==null?(E.return=v,J=E):cp(s);for(;u!==null;)J=u,ap(u),u=u.sibling;J=s,ca=_,rt=A}lp(e)}else(s.subtreeFlags&8772)!==0&&u!==null?(u.return=s,J=u):lp(e)}}function lp(e){for(;J!==null;){var n=J;if((n.flags&8772)!==0){var r=n.alternate;try{if((n.flags&8772)!==0)switch(n.tag){case 0:case 11:case 15:rt||ua(5,n);break;case 1:var a=n.stateNode;if(n.flags&4&&!rt)if(r===null)a.componentDidMount();else{var s=n.elementType===n.type?r.memoizedProps:It(n.type,r.memoizedProps);a.componentDidUpdate(s,r.memoizedState,a.__reactInternalSnapshotBeforeUpdate)}var u=n.updateQueue;u!==null&&rf(n,u,a);break;case 3:var v=n.updateQueue;if(v!==null){if(r=null,n.child!==null)switch(n.child.tag){case 5:r=n.child.stateNode;break;case 1:r=n.child.stateNode}rf(n,v,r)}break;case 5:var _=n.stateNode;if(r===null&&n.flags&4){r=_;var E=n.memoizedProps;switch(n.type){case"button":case"input":case"select":case"textarea":E.autoFocus&&r.focus();break;case"img":E.src&&(r.src=E.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(n.memoizedState===null){var A=n.alternate;if(A!==null){var F=A.memoizedState;if(F!==null){var U=F.dehydrated;U!==null&&Co(U)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(o(163))}rt||n.flags&512&&Rs(n)}catch($){Me(n,n.return,$)}}if(n===e){J=null;break}if(r=n.sibling,r!==null){r.return=n.return,J=r;break}J=n.return}}function sp(e){for(;J!==null;){var n=J;if(n===e){J=null;break}var r=n.sibling;if(r!==null){r.return=n.return,J=r;break}J=n.return}}function cp(e){for(;J!==null;){var n=J;try{switch(n.tag){case 0:case 11:case 15:var r=n.return;try{ua(4,n)}catch(E){Me(n,r,E)}break;case 1:var a=n.stateNode;if(typeof a.componentDidMount=="function"){var s=n.return;try{a.componentDidMount()}catch(E){Me(n,s,E)}}var u=n.return;try{Rs(n)}catch(E){Me(n,u,E)}break;case 5:var v=n.return;try{Rs(n)}catch(E){Me(n,v,E)}}}catch(E){Me(n,n.return,E)}if(n===e){J=null;break}var _=n.sibling;if(_!==null){_.return=n.return,J=_;break}J=n.return}}var n0=Math.ceil,da=I.ReactCurrentDispatcher,Is=I.ReactCurrentOwner,wt=I.ReactCurrentBatchConfig,ke=0,Ge=null,ze=null,qe=0,_t=0,Xr=Cn(0),We=0,Yo=null,Jn=0,fa=0,Ms=0,qo=null,ut=null,Bs=0,Ur=1/0,sn=null,pa=!1,js=null,Rn=null,ma=!1,Pn=null,va=0,Qo=0,$s=null,ha=-1,ga=0;function it(){return(ke&6)!==0?je():ha!==-1?ha:ha=je()}function Dn(e){return(e.mode&1)===0?1:(ke&2)!==0&&qe!==0?qe&-qe:$g.transition!==null?(ga===0&&(ga=ed()),ga):(e=we,e!==0||(e=window.event,e=e===void 0?16:cd(e.type)),e)}function jt(e,n,r,a){if(50<Qo)throw Qo=0,$s=null,Error(o(185));xo(e,r,a),((ke&2)===0||e!==Ge)&&(e===Ge&&((ke&2)===0&&(fa|=r),We===4&&In(e,qe)),dt(e,a),r===1&&ke===0&&(n.mode&1)===0&&(Ur=je()+500,Wi&&On()))}function dt(e,n){var r=e.callbackNode;$h(e,n);var a=Ci(e,e===Ge?qe:0);if(a===0)r!==null&&Qu(r),e.callbackNode=null,e.callbackPriority=0;else if(n=a&-a,e.callbackPriority!==n){if(r!=null&&Qu(r),n===1)e.tag===0?jg(dp.bind(null,e)):Kd(dp.bind(null,e)),Dg(function(){(ke&6)===0&&On()}),r=null;else{switch(td(a)){case 1:r=yl;break;case 4:r=Zu;break;case 16:r=ki;break;case 536870912:r=Ju;break;default:r=ki}r=_p(r,up.bind(null,e))}e.callbackPriority=n,e.callbackNode=r}}function up(e,n){if(ha=-1,ga=0,(ke&6)!==0)throw Error(o(327));var r=e.callbackNode;if(Hr()&&e.callbackNode!==r)return null;var a=Ci(e,e===Ge?qe:0);if(a===0)return null;if((a&30)!==0||(a&e.expiredLanes)!==0||n)n=ya(e,a);else{n=a;var s=ke;ke|=2;var u=pp();(Ge!==e||qe!==n)&&(sn=null,Ur=je()+500,tr(e,n));do try{i0();break}catch(_){fp(e,_)}while(!0);rs(),da.current=u,ke=s,ze!==null?n=0:(Ge=null,qe=0,n=We)}if(n!==0){if(n===2&&(s=_l(e),s!==0&&(a=s,n=zs(e,s))),n===1)throw r=Yo,tr(e,0),In(e,a),dt(e,je()),r;if(n===6)In(e,a);else{if(s=e.current.alternate,(a&30)===0&&!r0(s)&&(n=ya(e,a),n===2&&(u=_l(e),u!==0&&(a=u,n=zs(e,u))),n===1))throw r=Yo,tr(e,0),In(e,a),dt(e,je()),r;switch(e.finishedWork=s,e.finishedLanes=a,n){case 0:case 1:throw Error(o(345));case 2:nr(e,ut,sn);break;case 3:if(In(e,a),(a&130023424)===a&&(n=Bs+500-je(),10<n)){if(Ci(e,0)!==0)break;if(s=e.suspendedLanes,(s&a)!==a){it(),e.pingedLanes|=e.suspendedLanes&s;break}e.timeoutHandle=Vl(nr.bind(null,e,ut,sn),n);break}nr(e,ut,sn);break;case 4:if(In(e,a),(a&4194240)===a)break;for(n=e.eventTimes,s=-1;0<a;){var v=31-Rt(a);u=1<<v,v=n[v],v>s&&(s=v),a&=~u}if(a=s,a=je()-a,a=(120>a?120:480>a?480:1080>a?1080:1920>a?1920:3e3>a?3e3:4320>a?4320:1960*n0(a/1960))-a,10<a){e.timeoutHandle=Vl(nr.bind(null,e,ut,sn),a);break}nr(e,ut,sn);break;case 5:nr(e,ut,sn);break;default:throw Error(o(329))}}}return dt(e,je()),e.callbackNode===r?up.bind(null,e):null}function zs(e,n){var r=qo;return e.current.memoizedState.isDehydrated&&(tr(e,n).flags|=256),e=ya(e,n),e!==2&&(n=ut,ut=r,n!==null&&Fs(n)),e}function Fs(e){ut===null?ut=e:ut.push.apply(ut,e)}function r0(e){for(var n=e;;){if(n.flags&16384){var r=n.updateQueue;if(r!==null&&(r=r.stores,r!==null))for(var a=0;a<r.length;a++){var s=r[a],u=s.getSnapshot;s=s.value;try{if(!Pt(u(),s))return!1}catch{return!1}}}if(r=n.child,n.subtreeFlags&16384&&r!==null)r.return=n,n=r;else{if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function In(e,n){for(n&=~Ms,n&=~fa,e.suspendedLanes|=n,e.pingedLanes&=~n,e=e.expirationTimes;0<n;){var r=31-Rt(n),a=1<<r;e[r]=-1,n&=~a}}function dp(e){if((ke&6)!==0)throw Error(o(327));Hr();var n=Ci(e,0);if((n&1)===0)return dt(e,je()),null;var r=ya(e,n);if(e.tag!==0&&r===2){var a=_l(e);a!==0&&(n=a,r=zs(e,a))}if(r===1)throw r=Yo,tr(e,0),In(e,n),dt(e,je()),r;if(r===6)throw Error(o(345));return e.finishedWork=e.current.alternate,e.finishedLanes=n,nr(e,ut,sn),dt(e,je()),null}function Xs(e,n){var r=ke;ke|=1;try{return e(n)}finally{ke=r,ke===0&&(Ur=je()+500,Wi&&On())}}function er(e){Pn!==null&&Pn.tag===0&&(ke&6)===0&&Hr();var n=ke;ke|=1;var r=wt.transition,a=we;try{if(wt.transition=null,we=1,e)return e()}finally{we=a,wt.transition=r,ke=n,(ke&6)===0&&On()}}function Us(){_t=Xr.current,Ae(Xr)}function tr(e,n){e.finishedWork=null,e.finishedLanes=0;var r=e.timeoutHandle;if(r!==-1&&(e.timeoutHandle=-1,Pg(r)),ze!==null)for(r=ze.return;r!==null;){var a=r;switch(Zl(a),a.tag){case 1:a=a.type.childContextTypes,a!=null&&Ui();break;case 3:$r(),Ae(lt),Ae(et),ps();break;case 5:ds(a);break;case 4:$r();break;case 13:Ae(Re);break;case 19:Ae(Re);break;case 10:os(a.type._context);break;case 22:case 23:Us()}r=r.return}if(Ge=e,ze=e=Mn(e.current,null),qe=_t=n,We=0,Yo=null,Ms=fa=Jn=0,ut=qo=null,qn!==null){for(n=0;n<qn.length;n++)if(r=qn[n],a=r.interleaved,a!==null){r.interleaved=null;var s=a.next,u=r.pending;if(u!==null){var v=u.next;u.next=s,a.next=v}r.pending=a}qn=null}return e}function fp(e,n){do{var r=ze;try{if(rs(),na.current=aa,ra){for(var a=Pe.memoizedState;a!==null;){var s=a.queue;s!==null&&(s.pending=null),a=a.next}ra=!1}if(Zn=0,Ve=He=Pe=null,Uo=!1,Ho=0,Is.current=null,r===null||r.return===null){We=1,Yo=n,ze=null;break}e:{var u=e,v=r.return,_=r,E=n;if(n=qe,_.flags|=32768,E!==null&&typeof E=="object"&&typeof E.then=="function"){var A=E,F=_,U=F.tag;if((F.mode&1)===0&&(U===0||U===11||U===15)){var $=F.alternate;$?(F.updateQueue=$.updateQueue,F.memoizedState=$.memoizedState,F.lanes=$.lanes):(F.updateQueue=null,F.memoizedState=null)}var q=Bf(v);if(q!==null){q.flags&=-257,jf(q,v,_,u,n),q.mode&1&&Mf(u,A,n),n=q,E=A;var ee=n.updateQueue;if(ee===null){var ne=new Set;ne.add(E),n.updateQueue=ne}else ee.add(E);break e}else{if((n&1)===0){Mf(u,A,n),Hs();break e}E=Error(o(426))}}else if(Le&&_.mode&1){var $e=Bf(v);if($e!==null){($e.flags&65536)===0&&($e.flags|=256),jf($e,v,_,u,n),ts(zr(E,_));break e}}u=E=zr(E,_),We!==4&&(We=2),qo===null?qo=[u]:qo.push(u),u=v;do{switch(u.tag){case 3:u.flags|=65536,n&=-n,u.lanes|=n;var C=Df(u,E,n);nf(u,C);break e;case 1:_=E;var S=u.type,T=u.stateNode;if((u.flags&128)===0&&(typeof S.getDerivedStateFromError=="function"||T!==null&&typeof T.componentDidCatch=="function"&&(Rn===null||!Rn.has(T)))){u.flags|=65536,n&=-n,u.lanes|=n;var W=If(u,_,n);nf(u,W);break e}}u=u.return}while(u!==null)}vp(r)}catch(ae){n=ae,ze===r&&r!==null&&(ze=r=r.return);continue}break}while(!0)}function pp(){var e=da.current;return da.current=aa,e===null?aa:e}function Hs(){(We===0||We===3||We===2)&&(We=4),Ge===null||(Jn&268435455)===0&&(fa&268435455)===0||In(Ge,qe)}function ya(e,n){var r=ke;ke|=2;var a=pp();(Ge!==e||qe!==n)&&(sn=null,tr(e,n));do try{o0();break}catch(s){fp(e,s)}while(!0);if(rs(),ke=r,da.current=a,ze!==null)throw Error(o(261));return Ge=null,qe=0,We}function o0(){for(;ze!==null;)mp(ze)}function i0(){for(;ze!==null&&!Nh();)mp(ze)}function mp(e){var n=yp(e.alternate,e,_t);e.memoizedProps=e.pendingProps,n===null?vp(e):ze=n,Is.current=null}function vp(e){var n=e;do{var r=n.alternate;if(e=n.return,(n.flags&32768)===0){if(r=Qg(r,n,_t),r!==null){ze=r;return}}else{if(r=Zg(r,n),r!==null){r.flags&=32767,ze=r;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{We=6,ze=null;return}}if(n=n.sibling,n!==null){ze=n;return}ze=n=e}while(n!==null);We===0&&(We=5)}function nr(e,n,r){var a=we,s=wt.transition;try{wt.transition=null,we=1,a0(e,n,r,a)}finally{wt.transition=s,we=a}return null}function a0(e,n,r,a){do Hr();while(Pn!==null);if((ke&6)!==0)throw Error(o(327));r=e.finishedWork;var s=e.finishedLanes;if(r===null)return null;if(e.finishedWork=null,e.finishedLanes=0,r===e.current)throw Error(o(177));e.callbackNode=null,e.callbackPriority=0;var u=r.lanes|r.childLanes;if(zh(e,u),e===Ge&&(ze=Ge=null,qe=0),(r.subtreeFlags&2064)===0&&(r.flags&2064)===0||ma||(ma=!0,_p(ki,function(){return Hr(),null})),u=(r.flags&15990)!==0,(r.subtreeFlags&15990)!==0||u){u=wt.transition,wt.transition=null;var v=we;we=1;var _=ke;ke|=4,Is.current=null,e0(e,r),ip(r,e),Cg(Hl),Ai=!!Ul,Hl=Ul=null,e.current=r,t0(r),Lh(),ke=_,we=v,wt.transition=u}else e.current=r;if(ma&&(ma=!1,Pn=e,va=s),u=e.pendingLanes,u===0&&(Rn=null),Dh(r.stateNode),dt(e,je()),n!==null)for(a=e.onRecoverableError,r=0;r<n.length;r++)s=n[r],a(s.value,{componentStack:s.stack,digest:s.digest});if(pa)throw pa=!1,e=js,js=null,e;return(va&1)!==0&&e.tag!==0&&Hr(),u=e.pendingLanes,(u&1)!==0?e===$s?Qo++:(Qo=0,$s=e):Qo=0,On(),null}function Hr(){if(Pn!==null){var e=td(va),n=wt.transition,r=we;try{if(wt.transition=null,we=16>e?16:e,Pn===null)var a=!1;else{if(e=Pn,Pn=null,va=0,(ke&6)!==0)throw Error(o(331));var s=ke;for(ke|=4,J=e.current;J!==null;){var u=J,v=u.child;if((J.flags&16)!==0){var _=u.deletions;if(_!==null){for(var E=0;E<_.length;E++){var A=_[E];for(J=A;J!==null;){var F=J;switch(F.tag){case 0:case 11:case 15:Ko(8,F,u)}var U=F.child;if(U!==null)U.return=F,J=U;else for(;J!==null;){F=J;var $=F.sibling,q=F.return;if(ep(F),F===A){J=null;break}if($!==null){$.return=q,J=$;break}J=q}}}var ee=u.alternate;if(ee!==null){var ne=ee.child;if(ne!==null){ee.child=null;do{var $e=ne.sibling;ne.sibling=null,ne=$e}while(ne!==null)}}J=u}}if((u.subtreeFlags&2064)!==0&&v!==null)v.return=u,J=v;else e:for(;J!==null;){if(u=J,(u.flags&2048)!==0)switch(u.tag){case 0:case 11:case 15:Ko(9,u,u.return)}var C=u.sibling;if(C!==null){C.return=u.return,J=C;break e}J=u.return}}var S=e.current;for(J=S;J!==null;){v=J;var T=v.child;if((v.subtreeFlags&2064)!==0&&T!==null)T.return=v,J=T;else e:for(v=S;J!==null;){if(_=J,(_.flags&2048)!==0)try{switch(_.tag){case 0:case 11:case 15:ua(9,_)}}catch(ae){Me(_,_.return,ae)}if(_===v){J=null;break e}var W=_.sibling;if(W!==null){W.return=_.return,J=W;break e}J=_.return}}if(ke=s,On(),Ht&&typeof Ht.onPostCommitFiberRoot=="function")try{Ht.onPostCommitFiberRoot(Ei,e)}catch{}a=!0}return a}finally{we=r,wt.transition=n}}return!1}function hp(e,n,r){n=zr(r,n),n=Df(e,n,1),e=Nn(e,n,1),n=it(),e!==null&&(xo(e,1,n),dt(e,n))}function Me(e,n,r){if(e.tag===3)hp(e,e,r);else for(;n!==null;){if(n.tag===3){hp(n,e,r);break}else if(n.tag===1){var a=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof a.componentDidCatch=="function"&&(Rn===null||!Rn.has(a))){e=zr(r,e),e=If(n,e,1),n=Nn(n,e,1),e=it(),n!==null&&(xo(n,1,e),dt(n,e));break}}n=n.return}}function l0(e,n,r){var a=e.pingCache;a!==null&&a.delete(n),n=it(),e.pingedLanes|=e.suspendedLanes&r,Ge===e&&(qe&r)===r&&(We===4||We===3&&(qe&130023424)===qe&&500>je()-Bs?tr(e,0):Ms|=r),dt(e,n)}function gp(e,n){n===0&&((e.mode&1)===0?n=1:(n=wi,wi<<=1,(wi&130023424)===0&&(wi=4194304)));var r=it();e=on(e,n),e!==null&&(xo(e,n,r),dt(e,r))}function s0(e){var n=e.memoizedState,r=0;n!==null&&(r=n.retryLane),gp(e,r)}function c0(e,n){var r=0;switch(e.tag){case 13:var a=e.stateNode,s=e.memoizedState;s!==null&&(r=s.retryLane);break;case 19:a=e.stateNode;break;default:throw Error(o(314))}a!==null&&a.delete(n),gp(e,r)}var yp;yp=function(e,n,r){if(e!==null)if(e.memoizedProps!==n.pendingProps||lt.current)ct=!0;else{if((e.lanes&r)===0&&(n.flags&128)===0)return ct=!1,qg(e,n,r);ct=(e.flags&131072)!==0}else ct=!1,Le&&(n.flags&1048576)!==0&&Yd(n,Gi,n.index);switch(n.lanes=0,n.tag){case 2:var a=n.type;sa(e,n),e=n.pendingProps;var s=Rr(n,et.current);Br(n,r),s=hs(null,n,a,e,s,r);var u=gs();return n.flags|=1,typeof s=="object"&&s!==null&&typeof s.render=="function"&&s.$$typeof===void 0?(n.tag=1,n.memoizedState=null,n.updateQueue=null,st(a)?(u=!0,Hi(n)):u=!1,n.memoizedState=s.state!==null&&s.state!==void 0?s.state:null,ls(n),s.updater=Ji,n.stateNode=s,s._reactInternals=n,cs(n,a,e,r),n=ws(null,n,a,!0,u,r)):(n.tag=0,Le&&u&&Ql(n),ot(null,n,s,r),n=n.child),n;case 16:a=n.elementType;e:{switch(sa(e,n),e=n.pendingProps,s=a._init,a=s(a._payload),n.type=a,s=n.tag=d0(a),e=It(a,e),s){case 0:n=Ss(null,n,a,e,r);break e;case 1:n=Hf(null,n,a,e,r);break e;case 11:n=$f(null,n,a,e,r);break e;case 14:n=zf(null,n,a,It(a.type,e),r);break e}throw Error(o(306,a,""))}return n;case 0:return a=n.type,s=n.pendingProps,s=n.elementType===a?s:It(a,s),Ss(e,n,a,s,r);case 1:return a=n.type,s=n.pendingProps,s=n.elementType===a?s:It(a,s),Hf(e,n,a,s,r);case 3:e:{if(Wf(n),e===null)throw Error(o(387));a=n.pendingProps,u=n.memoizedState,s=u.element,tf(e,n),Zi(n,a,null,r);var v=n.memoizedState;if(a=v.element,u.isDehydrated)if(u={element:a,isDehydrated:!1,cache:v.cache,pendingSuspenseBoundaries:v.pendingSuspenseBoundaries,transitions:v.transitions},n.updateQueue.baseState=u,n.memoizedState=u,n.flags&256){s=zr(Error(o(423)),n),n=Vf(e,n,a,r,s);break e}else if(a!==s){s=zr(Error(o(424)),n),n=Vf(e,n,a,r,s);break e}else for(yt=wn(n.stateNode.containerInfo.firstChild),gt=n,Le=!0,Dt=null,r=df(n,null,a,r),n.child=r;r;)r.flags=r.flags&-3|4096,r=r.sibling;else{if(Ir(),a===s){n=ln(e,n,r);break e}ot(e,n,a,r)}n=n.child}return n;case 5:return ff(n),e===null&&es(n),a=n.type,s=n.pendingProps,u=e!==null?e.memoizedProps:null,v=s.children,Wl(a,s)?v=null:u!==null&&Wl(a,u)&&(n.flags|=32),Uf(e,n),ot(e,n,v,r),n.child;case 6:return e===null&&es(n),null;case 13:return Gf(e,n,r);case 4:return us(n,n.stateNode.containerInfo),a=n.pendingProps,e===null?n.child=jr(n,null,a,r):ot(e,n,a,r),n.child;case 11:return a=n.type,s=n.pendingProps,s=n.elementType===a?s:It(a,s),$f(e,n,a,s,r);case 7:return ot(e,n,n.pendingProps,r),n.child;case 8:return ot(e,n,n.pendingProps.children,r),n.child;case 12:return ot(e,n,n.pendingProps.children,r),n.child;case 10:e:{if(a=n.type._context,s=n.pendingProps,u=n.memoizedProps,v=s.value,Te(Yi,a._currentValue),a._currentValue=v,u!==null)if(Pt(u.value,v)){if(u.children===s.children&&!lt.current){n=ln(e,n,r);break e}}else for(u=n.child,u!==null&&(u.return=n);u!==null;){var _=u.dependencies;if(_!==null){v=u.child;for(var E=_.firstContext;E!==null;){if(E.context===a){if(u.tag===1){E=an(-1,r&-r),E.tag=2;var A=u.updateQueue;if(A!==null){A=A.shared;var F=A.pending;F===null?E.next=E:(E.next=F.next,F.next=E),A.pending=E}}u.lanes|=r,E=u.alternate,E!==null&&(E.lanes|=r),is(u.return,r,n),_.lanes|=r;break}E=E.next}}else if(u.tag===10)v=u.type===n.type?null:u.child;else if(u.tag===18){if(v=u.return,v===null)throw Error(o(341));v.lanes|=r,_=v.alternate,_!==null&&(_.lanes|=r),is(v,r,n),v=u.sibling}else v=u.child;if(v!==null)v.return=u;else for(v=u;v!==null;){if(v===n){v=null;break}if(u=v.sibling,u!==null){u.return=v.return,v=u;break}v=v.return}u=v}ot(e,n,s.children,r),n=n.child}return n;case 9:return s=n.type,a=n.pendingProps.children,Br(n,r),s=Et(s),a=a(s),n.flags|=1,ot(e,n,a,r),n.child;case 14:return a=n.type,s=It(a,n.pendingProps),s=It(a.type,s),zf(e,n,a,s,r);case 15:return Ff(e,n,n.type,n.pendingProps,r);case 17:return a=n.type,s=n.pendingProps,s=n.elementType===a?s:It(a,s),sa(e,n),n.tag=1,st(a)?(e=!0,Hi(n)):e=!1,Br(n,r),lf(n,a,s),cs(n,a,s,r),ws(null,n,a,!0,e,r);case 19:return Yf(e,n,r);case 22:return Xf(e,n,r)}throw Error(o(156,n.tag))};function _p(e,n){return qu(e,n)}function u0(e,n,r,a){this.tag=e,this.key=r,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=a,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Ct(e,n,r,a){return new u0(e,n,r,a)}function Ws(e){return e=e.prototype,!(!e||!e.isReactComponent)}function d0(e){if(typeof e=="function")return Ws(e)?1:0;if(e!=null){if(e=e.$$typeof,e===le)return 11;if(e===ve)return 14}return 2}function Mn(e,n){var r=e.alternate;return r===null?(r=Ct(e.tag,n,e.key,e.mode),r.elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=n,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=e.flags&14680064,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,n=e.dependencies,r.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r}function _a(e,n,r,a,s,u){var v=2;if(a=e,typeof e=="function")Ws(e)&&(v=1);else if(typeof e=="string")v=5;else e:switch(e){case X:return rr(r.children,s,u,n);case K:v=8,s|=8;break;case ce:return e=Ct(12,r,n,s|2),e.elementType=ce,e.lanes=u,e;case de:return e=Ct(13,r,n,s),e.elementType=de,e.lanes=u,e;case oe:return e=Ct(19,r,n,s),e.elementType=oe,e.lanes=u,e;case fe:return ba(r,s,u,n);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case Q:v=10;break e;case Z:v=9;break e;case le:v=11;break e;case ve:v=14;break e;case re:v=16,a=null;break e}throw Error(o(130,e==null?e:typeof e,""))}return n=Ct(v,r,n,s),n.elementType=e,n.type=a,n.lanes=u,n}function rr(e,n,r,a){return e=Ct(7,e,a,n),e.lanes=r,e}function ba(e,n,r,a){return e=Ct(22,e,a,n),e.elementType=fe,e.lanes=r,e.stateNode={isHidden:!1},e}function Vs(e,n,r){return e=Ct(6,e,null,n),e.lanes=r,e}function Gs(e,n,r){return n=Ct(4,e.children!==null?e.children:[],e.key,n),n.lanes=r,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n}function f0(e,n,r,a,s){this.tag=n,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=bl(0),this.expirationTimes=bl(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=bl(0),this.identifierPrefix=a,this.onRecoverableError=s,this.mutableSourceEagerHydrationData=null}function Ks(e,n,r,a,s,u,v,_,E){return e=new f0(e,n,r,_,E),n===1?(n=1,u===!0&&(n|=8)):n=0,u=Ct(3,null,null,n),e.current=u,u.stateNode=e,u.memoizedState={element:a,isDehydrated:r,cache:null,transitions:null,pendingSuspenseBoundaries:null},ls(u),e}function p0(e,n,r){var a=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:j,key:a==null?null:""+a,children:e,containerInfo:n,implementation:r}}function bp(e){if(!e)return Tn;e=e._reactInternals;e:{if(Wn(e)!==e||e.tag!==1)throw Error(o(170));var n=e;do{switch(n.tag){case 3:n=n.stateNode.context;break e;case 1:if(st(n.type)){n=n.stateNode.__reactInternalMemoizedMergedChildContext;break e}}n=n.return}while(n!==null);throw Error(o(171))}if(e.tag===1){var r=e.type;if(st(r))return Vd(e,r,n)}return n}function xp(e,n,r,a,s,u,v,_,E){return e=Ks(r,a,!0,e,s,u,v,_,E),e.context=bp(null),r=e.current,a=it(),s=Dn(r),u=an(a,s),u.callback=n??null,Nn(r,u,s),e.current.lanes=s,xo(e,s,a),dt(e,a),e}function xa(e,n,r,a){var s=n.current,u=it(),v=Dn(s);return r=bp(r),n.context===null?n.context=r:n.pendingContext=r,n=an(u,v),n.payload={element:e},a=a===void 0?null:a,a!==null&&(n.callback=a),e=Nn(s,n,v),e!==null&&(jt(e,s,v,u),Qi(e,s,v)),v}function ka(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function kp(e,n){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var r=e.retryLane;e.retryLane=r!==0&&r<n?r:n}}function Ys(e,n){kp(e,n),(e=e.alternate)&&kp(e,n)}function m0(){return null}var Ep=typeof reportError=="function"?reportError:function(e){console.error(e)};function qs(e){this._internalRoot=e}Ea.prototype.render=qs.prototype.render=function(e){var n=this._internalRoot;if(n===null)throw Error(o(409));xa(e,n,null,null)},Ea.prototype.unmount=qs.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var n=e.containerInfo;er(function(){xa(null,e,null,null)}),n[en]=null}};function Ea(e){this._internalRoot=e}Ea.prototype.unstable_scheduleHydration=function(e){if(e){var n=od();e={blockedOn:null,target:e,priority:n};for(var r=0;r<kn.length&&n!==0&&n<kn[r].priority;r++);kn.splice(r,0,e),r===0&&ld(e)}};function Qs(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Sa(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function Sp(){}function v0(e,n,r,a,s){if(s){if(typeof a=="function"){var u=a;a=function(){var A=ka(v);u.call(A)}}var v=xp(n,a,e,0,null,!1,!1,"",Sp);return e._reactRootContainer=v,e[en]=v.current,Io(e.nodeType===8?e.parentNode:e),er(),v}for(;s=e.lastChild;)e.removeChild(s);if(typeof a=="function"){var _=a;a=function(){var A=ka(E);_.call(A)}}var E=Ks(e,0,!1,null,null,!1,!1,"",Sp);return e._reactRootContainer=E,e[en]=E.current,Io(e.nodeType===8?e.parentNode:e),er(function(){xa(n,E,r,a)}),E}function wa(e,n,r,a,s){var u=r._reactRootContainer;if(u){var v=u;if(typeof s=="function"){var _=s;s=function(){var E=ka(v);_.call(E)}}xa(n,v,e,s)}else v=v0(r,n,e,s,a);return ka(v)}nd=function(e){switch(e.tag){case 3:var n=e.stateNode;if(n.current.memoizedState.isDehydrated){var r=bo(n.pendingLanes);r!==0&&(xl(n,r|1),dt(n,je()),(ke&6)===0&&(Ur=je()+500,On()))}break;case 13:er(function(){var a=on(e,1);if(a!==null){var s=it();jt(a,e,1,s)}}),Ys(e,1)}},kl=function(e){if(e.tag===13){var n=on(e,134217728);if(n!==null){var r=it();jt(n,e,134217728,r)}Ys(e,134217728)}},rd=function(e){if(e.tag===13){var n=Dn(e),r=on(e,n);if(r!==null){var a=it();jt(r,e,n,a)}Ys(e,n)}},od=function(){return we},id=function(e,n){var r=we;try{return we=e,n()}finally{we=r}},ml=function(e,n,r){switch(n){case"input":if(Ut(e,r),n=r.name,r.type==="radio"&&n!=null){for(r=e;r.parentNode;)r=r.parentNode;for(r=r.querySelectorAll("input[name="+JSON.stringify(""+n)+'][type="radio"]'),n=0;n<r.length;n++){var a=r[n];if(a!==e&&a.form===e.form){var s=Xi(a);if(!s)throw Error(o(90));Ft(a),Ut(a,s)}}}break;case"textarea":_r(e,r);break;case"select":n=r.value,n!=null&&Lt(e,!!r.multiple,n,!1)}},Uu=Xs,Hu=er;var h0={usingClientEntryPoint:!1,Events:[jo,Nr,Xi,Fu,Xu,Xs]},Zo={findFiberByHostInstance:Vn,bundleType:0,version:"18.2.0",rendererPackageName:"react-dom"},g0={bundleType:Zo.bundleType,version:Zo.version,rendererPackageName:Zo.rendererPackageName,rendererConfig:Zo.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:I.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=Ku(e),e===null?null:e.stateNode},findFiberByHostInstance:Zo.findFiberByHostInstance||m0,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.2.0-next-9e3b772b8-20220608"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Ca=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Ca.isDisabled&&Ca.supportsFiber)try{Ei=Ca.inject(g0),Ht=Ca}catch{}}return ft.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=h0,ft.createPortal=function(e,n){var r=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!Qs(n))throw Error(o(200));return p0(e,n,null,r)},ft.createRoot=function(e,n){if(!Qs(e))throw Error(o(299));var r=!1,a="",s=Ep;return n!=null&&(n.unstable_strictMode===!0&&(r=!0),n.identifierPrefix!==void 0&&(a=n.identifierPrefix),n.onRecoverableError!==void 0&&(s=n.onRecoverableError)),n=Ks(e,1,!1,null,null,r,!1,a,s),e[en]=n.current,Io(e.nodeType===8?e.parentNode:e),new qs(n)},ft.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var n=e._reactInternals;if(n===void 0)throw typeof e.render=="function"?Error(o(188)):(e=Object.keys(e).join(","),Error(o(268,e)));return e=Ku(n),e=e===null?null:e.stateNode,e},ft.flushSync=function(e){return er(e)},ft.hydrate=function(e,n,r){if(!Sa(n))throw Error(o(200));return wa(null,e,n,!0,r)},ft.hydrateRoot=function(e,n,r){if(!Qs(e))throw Error(o(405));var a=r!=null&&r.hydratedSources||null,s=!1,u="",v=Ep;if(r!=null&&(r.unstable_strictMode===!0&&(s=!0),r.identifierPrefix!==void 0&&(u=r.identifierPrefix),r.onRecoverableError!==void 0&&(v=r.onRecoverableError)),n=xp(n,null,e,1,r??null,s,!1,u,v),e[en]=n.current,Io(e),a)for(e=0;e<a.length;e++)r=a[e],s=r._getVersion,s=s(r._source),n.mutableSourceEagerHydrationData==null?n.mutableSourceEagerHydrationData=[r,s]:n.mutableSourceEagerHydrationData.push(r,s);return new Ea(n)},ft.render=function(e,n,r){if(!Sa(n))throw Error(o(200));return wa(null,e,n,!1,r)},ft.unmountComponentAtNode=function(e){if(!Sa(e))throw Error(o(40));return e._reactRootContainer?(er(function(){wa(null,null,e,!1,function(){e._reactRootContainer=null,e[en]=null})}),!0):!1},ft.unstable_batchedUpdates=Xs,ft.unstable_renderSubtreeIntoContainer=function(e,n,r,a){if(!Sa(r))throw Error(o(200));if(e==null||e._reactInternals===void 0)throw Error(o(38));return wa(e,n,r,!1,a)},ft.version="18.2.0-next-9e3b772b8-20220608",ft}var Pp;function Ym(){if(Pp)return ec.exports;Pp=1;function t(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(t)}catch(i){console.error(i)}}return t(),ec.exports=S0(),ec.exports}var Dp;function w0(){if(Dp)return Ta;Dp=1;var t=Ym();return Ta.createRoot=t.createRoot,Ta.hydrateRoot=t.hydrateRoot,Ta}var C0=w0(),ja={exports:{}},rc,Ip;function qm(){if(Ip)return rc;Ip=1;const t=o=>Array.isArray(o)?o:[o],i=typeof window<"u"&&typeof window.document<"u";return rc={convertToArrayIfNeeded:t,isBrowser:i},rc}var oc,Mp;function Eu(){if(Mp)return oc;Mp=1;const t=(m,h)=>h,i=()=>t("MONDAY_COM_PROTOCOL","https"),o=()=>t("MONDAY_COM_DOMAIN","monday.com"),l=()=>t("MONDAY_SUBDOMAIN_API","api."),c=()=>t("MONDAY_OAUTH_SUBDOMAIN","auth."),d=()=>`${i()}://${l()}${o()}/v2`,p=()=>`${i()}://${c()}${o()}/oauth2/authorize`,f=()=>`${i()}://${c()}${o()}/oauth2/token`;return oc={get MONDAY_DOMAIN(){return o()},get MONDAY_PROTOCOL(){return i()},get MONDAY_API_URL(){return d()},get MONDAY_OAUTH_URL(){return p()},get MONDAY_OAUTH_TOKEN_URL(){return f()}},oc}var Oa={exports:{}},Bp;function T0(){return Bp||(Bp=1,function(t,i){var o=function(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof wp<"u")return wp;throw new Error("unable to locate global object")},l=o();t.exports=i=l.fetch,l.fetch&&(i.default=l.fetch.bind(l)),i.Headers=l.Headers,i.Request=l.Request,i.Response=l.Response}(Oa,Oa.exports)),Oa.exports}var ic,jp;function O0(){if(jp)return ic;jp=1;const t=T0();function i(o,l={}){return t(o,l)}return ic={nodeFetch:i},ic}var ac,$p;function A0(){if($p)return ac;$p=1;const{MONDAY_API_URL:t,MONDAY_OAUTH_TOKEN_URL:i}=Eu(),o=O0(),l="Could not parse JSON from monday.com's GraphQL API response",c="Token is required",d="Received timeout from monday.com's GraphQL API";function p(m,h,g,y={}){return o.nodeFetch(m,{method:y.method||"POST",body:JSON.stringify(h||{}),headers:{Authorization:g,"Content-Type":"application/json",...y.apiVersion?{"API-Version":y.apiVersion}:{}}})}async function f(m,h,g={}){if(!h&&g.url!==i)throw new Error(c);const y=g.url||t,b=g.path||"",w=`${y}${b}`;let N=await p(w,m,h,g);const L=N.status,O=N.headers.get("content-type");if(!O||!O.includes("application/json")){if(L===504)throw new Error(d);const R=await N.text();throw new Error(R)}try{return await N.json()}catch{throw new Error(l)}}return ac={execute:f,COULD_NOT_PARSE_JSON_RESPONSE_ERROR:l,TOKEN_IS_REQUIRED_ERROR:c,API_TIMEOUT_ERROR:d},ac}var lc,zp;function Su(){return zp||(zp=1,lc=A0()),lc}var sc,Fp;function N0(){if(Fp)return sc;Fp=1;let t=!1;function i(){if(t)return;t=!0;const o='body::before { content: ""; position: fixed; top: 0; right: 0; bottom: 0; left: 0; pointer-events: none; z-index: 2147483647; /* mondaySdk css - can be disabled with: mondaySdk({withoutScrollHelper: true }) */ }',l=document.createElement("style");l.appendChild(document.createTextNode(o)),(document.head||document.getElementsByTagName("head")[0]).appendChild(l)}return sc={initScrollHelperIfNeeded:i},sc}var cc,Xp;function L0(){if(Xp)return cc;Xp=1;const t=5*60*1e3;let i=!1;return cc={initBackgroundTracking:l=>{if(i)return;i=!0;const c=()=>{l.track("ping")};c(),setInterval(c,t)}},cc}var uc,Up;function Qm(){return Up||(Up=1,uc={logWarnings:i=>{const o=i&&i.extensions&&i.extensions.warnings;return!o||!Array.isArray(o)||o.forEach(l=>{if(!(!l||!l.message))try{const c=l.locations&&l.locations.map(m=>`line ${m.line}, column ${m.column}`).join("; "),d=l.path&&l.path.join(" → ");let p=l.message;p=p.replace(/\.$/,""),p=p.charAt(0).toLowerCase()+p.slice(1);const f=["[monday API]",`${d}:`,p,c&&`@ ${c}`,l.extensions?[`

Additional details:`,l.extensions]:void 0].flat().filter(Boolean);console.warn(...f)}catch{l&&console.warn("[monday API] Warning:",l)}}),i}}),uc}const R0="0.5.5",P0={version:R0};var dc,Hp;function D0(){if(Hp)return dc;Hp=1;const t=Su(),{MONDAY_OAUTH_URL:i}=Eu(),{convertToArrayIfNeeded:o}=qm(),{initScrollHelperIfNeeded:l}=N0(),{initBackgroundTracking:c}=L0(),{logWarnings:d}=Qm(),p=[],f={GLOBAL:"v2",INSTANCE:"instance"};class m{constructor(y={}){this._clientId=y.clientId,this._apiToken=y.apiToken,this._apiVersion=y.apiVersion,this.listeners={},this.setClientId=this.setClientId.bind(this),this.setToken=this.setToken.bind(this),this.setApiVersion=this.setApiVersion.bind(this),this.api=this.api.bind(this),this.listen=this.listen.bind(this),this.get=this.get.bind(this),this.set=this.set.bind(this),this.execute=this.execute.bind(this),this.oauth=this.oauth.bind(this),this._receiveMessage=this._receiveMessage.bind(this),this.storage={setItem:this.setStorageItem.bind(this),getItem:this.getStorageItem.bind(this),deleteItem:this.deleteStorageItem.bind(this),instance:{setItem:this.setStorageInstanceItem.bind(this),getItem:this.getStorageInstanceItem.bind(this),deleteItem:this.deleteStorageInstanceItem.bind(this)}},window.addEventListener("message",this._receiveMessage,!1),y.withoutScrollHelper||l(),c(this)}setClientId(y){this._clientId=y}setToken(y){this._apiToken=y}setApiVersion(y){this._apiVersion=y}api(y,b={}){const w={query:y,variables:b.variables},N=b.token||this._apiToken,L=b.apiVersion||this._apiVersion;let O;return N?O=t.execute(w,N,{apiVersion:L}):O=this._localApi("api",{params:w,apiVersion:L}).then(R=>R.data),O.then(d)}listen(y,b,w){const N=o(y),L=[];return N.forEach(O=>{L.push(this._addListener(O,b)),this._localApi("listen",{type:O,params:w})}),()=>{L.forEach(O=>O())}}get(y,b){return this._localApi("get",{type:y,params:b})}set(y,b){return this._localApi("set",{type:y,params:b})}execute(y,b){return this._localApi("execute",{type:y,params:b})}track(y,b){return this.execute("track",{name:y,data:b})}oauth(y={}){const b=y.clientId||this._clientId;if(!b)throw new Error("clientId is required");const N=`${y.mondayOauthUrl||i}?client_id=${b}`;window.location=N}setStorageItem(y,b,w={}){return this._localApi("storage",{method:"set",key:y,value:b,options:w,segment:f.GLOBAL})}getStorageItem(y,b={}){return this._localApi("storage",{method:"get",key:y,options:b,segment:f.GLOBAL})}deleteStorageItem(y,b={}){return this._localApi("storage",{method:"delete",key:y,options:b,segment:f.GLOBAL})}setStorageInstanceItem(y,b,w={}){return this._localApi("storage",{method:"set",key:y,value:b,options:w,segment:f.INSTANCE})}getStorageInstanceItem(y,b={}){return this._localApi("storage",{method:"get",key:y,options:b,segment:f.INSTANCE})}deleteStorageInstanceItem(y,b={}){return this._localApi("storage",{method:"delete",key:y,options:b,segment:f.INSTANCE})}_localApi(y,b){return new Promise((w,N)=>{const L=this._generateRequestId(),O=this._clientId,M=P0.version;window.parent.postMessage({method:y,args:b,requestId:L,clientId:O,version:M},"*");const z=this._addListener(L,I=>{if(z(),I.errorMessage){const B=new Error(I.errorMessage);B.data=I.data,N(B)}else w(I)})})}_receiveMessage(y){const{method:b,type:w,requestId:N}=y.data,L=this.listeners[b]||p,O=this.listeners[w]||p,R=this.listeners[N]||p;let M=new Set([...L,...O,...R]);M&&M.forEach(z=>{try{z(y.data)}catch(I){console.error("Message callback error: ",I)}})}_addListener(y,b){return this.listeners[y]=this.listeners[y]||new Set,this.listeners[y].add(b),()=>{this.listeners[y].delete(b),this.listeners[y].size===0&&delete this.listeners[y]}}_generateRequestId(){return Math.random().toString(36).substring(2,9)}_removeEventListener(){window.removeEventListener("message",this._receiveMessage,!1)}_clearListeners(){this.listeners=[]}}function h(g={}){return new m(g)}return dc=h,dc}var fc,Wp;function I0(){if(Wp)return fc;Wp=1;const{execute:t}=Su(),{MONDAY_OAUTH_TOKEN_URL:i}=Eu();return fc={oauthToken:(l,c,d)=>t({code:l,client_id:c,client_secret:d},null,{url:i})},fc}var pc,Vp;function M0(){if(Vp)return pc;Vp=1;const{logWarnings:t}=Qm(),i=Su(),{oauthToken:o}=I0(),l="Should send 'token' as an option or call mondaySdk.setToken(TOKEN)";class c{constructor(f={}){this._token=f.token,this._apiVersion=f.apiVersion,this.setToken=this.setToken.bind(this),this.setApiVersion=this.setApiVersion.bind(this),this.api=this.api.bind(this)}setToken(f){this._token=f}setApiVersion(f){this._apiVersion=f}api(f,m={}){const h={query:f,variables:m.variables},g=m.token||this._token,y=m.apiVersion||this._apiVersion;if(!g)throw new Error(l);return i.execute(h,g,{apiVersion:y}).then(t)}oauthToken(f,m,h){return o(f,m,h)}}function d(p={}){return new c(p)}return pc=d,pc}var B0=ja.exports,Gp;function j0(){return Gp||(Gp=1,function(t,i){const{isBrowser:o}=qm(),l=o?D0():M0();(function(c,d){t.exports=d()})(typeof self<"u"?self:B0,function(){return typeof __BUNDLE__<"u"&&__BUNDLE__&&(window.mondaySdk=l),l})}(ja)),ja.exports}var $0=j0();const z0=lo($0);let F0={data:""},X0=t=>typeof window=="object"?((t?t.querySelector("#_goober"):window._goober)||Object.assign((t||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:t||F0,U0=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,H0=/\/\*[^]*?\*\/|  +/g,Kp=/\n+/g,Fn=(t,i)=>{let o="",l="",c="";for(let d in t){let p=t[d];d[0]=="@"?d[1]=="i"?o=d+" "+p+";":l+=d[1]=="f"?Fn(p,d):d+"{"+Fn(p,d[1]=="k"?"":i)+"}":typeof p=="object"?l+=Fn(p,i?i.replace(/([^,])+/g,f=>d.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,m=>/&/.test(m)?m.replace(/&/g,f):f?f+" "+m:m)):d):p!=null&&(d=/^--/.test(d)?d:d.replace(/[A-Z]/g,"-$&").toLowerCase(),c+=Fn.p?Fn.p(d,p):d+":"+p+";")}return o+(i&&c?i+"{"+c+"}":c)+l},cn={},Zm=t=>{if(typeof t=="object"){let i="";for(let o in t)i+=o+Zm(t[o]);return i}return t},W0=(t,i,o,l,c)=>{let d=Zm(t),p=cn[d]||(cn[d]=(m=>{let h=0,g=11;for(;h<m.length;)g=101*g+m.charCodeAt(h++)>>>0;return"go"+g})(d));if(!cn[p]){let m=d!==t?t:(h=>{let g,y,b=[{}];for(;g=U0.exec(h.replace(H0,""));)g[4]?b.shift():g[3]?(y=g[3].replace(Kp," ").trim(),b.unshift(b[0][y]=b[0][y]||{})):b[0][g[1]]=g[2].replace(Kp," ").trim();return b[0]})(t);cn[p]=Fn(c?{["@keyframes "+p]:m}:m,o?"":"."+p)}let f=o&&cn.g?cn.g:null;return o&&(cn.g=cn[p]),((m,h,g,y)=>{y?h.data=h.data.replace(y,m):h.data.indexOf(m)===-1&&(h.data=g?m+h.data:h.data+m)})(cn[p],i,l,f),p},V0=(t,i,o)=>t.reduce((l,c,d)=>{let p=i[d];if(p&&p.call){let f=p(o),m=f&&f.props&&f.props.className||/^go/.test(f)&&f;p=m?"."+m:f&&typeof f=="object"?f.props?"":Fn(f,""):f===!1?"":f}return l+c+(p??"")},"");function Ja(t){let i=this||{},o=t.call?t(i.p):t;return W0(o.unshift?o.raw?V0(o,[].slice.call(arguments,1),i.p):o.reduce((l,c)=>Object.assign(l,c&&c.call?c(i.p):c),{}):o,X0(i.target),i.g,i.o,i.k)}let Jm,Sc,wc;Ja.bind({g:1});let fn=Ja.bind({k:1});function G0(t,i,o,l){Fn.p=i,Jm=t,Sc=o,wc=l}function Xn(t,i){let o=this||{};return function(){let l=arguments;function c(d,p){let f=Object.assign({},d),m=f.className||c.className;o.p=Object.assign({theme:Sc&&Sc()},f),o.o=/ *go\d+/.test(m),f.className=Ja.apply(o,l)+(m?" "+m:"");let h=t;return t[0]&&(h=f.as||t,delete f.as),wc&&h[0]&&wc(f),Jm(h,f)}return c}}var K0=t=>typeof t=="function",Y0=(t,i)=>K0(t)?t(i):t,q0=(()=>{let t;return()=>{if(t===void 0&&typeof window<"u"){let i=matchMedia("(prefers-reduced-motion: reduce)");t=!i||i.matches}return t}})(),Q0=fn`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Z0=fn`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,J0=fn`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ey=Xn("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Q0} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Z0} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${t=>t.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${J0} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,ty=fn`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,ny=Xn("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${t=>t.secondary||"#e0e0e0"};
  border-right-color: ${t=>t.primary||"#616161"};
  animation: ${ty} 1s linear infinite;
`,ry=fn`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,oy=fn`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,iy=Xn("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${ry} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${oy} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${t=>t.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ay=Xn("div")`
  position: absolute;
`,ly=Xn("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,sy=fn`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,cy=Xn("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${sy} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,uy=({toast:t})=>{let{icon:i,type:o,iconTheme:l}=t;return i!==void 0?typeof i=="string"?k.createElement(cy,null,i):i:o==="blank"?null:k.createElement(ly,null,k.createElement(ny,{...l}),o!=="loading"&&k.createElement(ay,null,o==="error"?k.createElement(ey,{...l}):k.createElement(iy,{...l})))},dy=t=>`
0% {transform: translate3d(0,${t*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,fy=t=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${t*-150}%,-1px) scale(.6); opacity:0;}
`,py="0%{opacity:0;} 100%{opacity:1;}",my="0%{opacity:1;} 100%{opacity:0;}",vy=Xn("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,hy=Xn("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,gy=(t,i)=>{let o=t.includes("top")?1:-1,[l,c]=q0()?[py,my]:[dy(o),fy(o)];return{animation:i?`${fn(l)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${fn(c)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}};k.memo(({toast:t,position:i,style:o,children:l})=>{let c=t.height?gy(t.position||i||"top-center",t.visible):{opacity:0},d=k.createElement(uy,{toast:t}),p=k.createElement(hy,{...t.ariaProps},Y0(t.message,t));return k.createElement(vy,{className:t.className,style:{...c,...o,...t.style}},typeof l=="function"?l({icon:d,message:p}):k.createElement(k.Fragment,null,d,p))});G0(k.createElement);Ja`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;const dn={AccessDeniedForIncorrectCode:3,CodeNotFoundInLocalStorage:5,FileFolderNotFound:6,DesktopAppNotRunning:7};function Yp(t,i,o,l){if(i(!1),o(0),t==null||t=="")return;let c=ev(t);if(c.isValid){window.open(c.url,"_blank");return}let d=localStorage.getItem("token");if(d==null||d==""){o(dn.CodeNotFoundInLocalStorage);return}const p=d.split("-"),f=p[p.length-1],m=p.slice(0,-1).join("-");fetch(`http://localhost:${f}/api/open/${encodeURIComponent(t)}?openParentFolder=${l}`,{method:"GET",headers:{"Content-Type":"application/json",bearer:m}}).then(h=>{if(!h.ok)throw new Error("Network response was not ok: "+h.status);return h.json()}).then(h=>{console.log("Received data:",h),h===dn.AccessDeniedForIncorrectCode?o(dn.AccessDeniedForIncorrectCode):h===dn.FileFolderNotFound&&o(dn.FileFolderNotFound)}).catch(h=>{console.error("Fetch error:",h),i(!0),o(dn.DesktopAppNotRunning)})}function ev(t){if(typeof t!="string")return{isValid:!1,url:null};let i=t.trim();i.startsWith("www.")&&(i="http://"+i);try{const o=new URL(i);return o.protocol==="http:"||o.protocol==="https:"?{isValid:!0,url:o.href}:{isValid:!1,url:null}}catch{return{isValid:!1,url:null}}}async function gi(t,i){let o=`item-links-${i}`;const l=await t.storage.getItem(o);return console.log(l),l.data}async function el(t,i,o,l){let c=`item-links-${i}`;await t.storage.setItem(c,o,{previous_version:l})}async function yy(t,i,o,l,c,d){let p=JSON.stringify(l);if(l.list[o][0]!==(c==null?void 0:c.trim()))try{const m=[...l.list];m[o]=[(c||"").trim(),m[o][1]];const h={list:m,version:l.version};await el(t,i,JSON.stringify(m),l.version);const g=await gi(t,i);console.log("updated response",g),h.version=g.version,h.list=JSON.parse(g.value),console.log("new version",h),d(h)}catch{console.log("Reverting to old values"),d(JSON.parse(p))}}async function _y(t,i,o,l,c,d){const p=JSON.stringify(l),f=l.list[o][1];(c!=null&&c.startsWith('"')&&(c!=null&&c.endsWith('"'))||c!=null&&c.startsWith("'")&&(c!=null&&c.endsWith("'")))&&(c=c.slice(1,-1));const h=(c||"").trim();if(f!==h)try{const g=[...l.list];if(g[o][1]=h,g[o][0]===""){const N=decodeURIComponent(g[o][1]);g[o][0]=N.length>20?"..."+N.slice(-20):N}const y={list:g,version:l.version};let b=await el(t,i,JSON.stringify(g),l.version);const w=await gi(t,i);console.log("updated response",w),y.version=w.version,y.list=JSON.parse(w.value),d(y)}catch{console.log("Reverting to old values"),d(JSON.parse(p))}}async function by(t,i,o,l,c,d){var f;if(c||((f=o==null?void 0:o.list)==null?void 0:f.length)>=500)return;d(!0);const p=JSON.stringify(o);try{o.list||(o.list=[]);const m=[...o.list,["",""]],h={list:m,version:o.version};await el(t,i,JSON.stringify(m),o.version);const g=await gi(t,i);console.log("Added item response",g),h.version=g.version,h.list=JSON.parse(g.value),l(h)}catch{console.log("Reverting to old values due to error"),l(JSON.parse(p))}finally{d(!1)}}async function xy(t,i,o,l,c,d){d(!0);const p=JSON.stringify(l);try{const f=[...l.list];f.splice(o,1);const m={list:f,version:l.version};await el(t,i,JSON.stringify(f),l.version);const h=await gi(t,i);console.log("Deleted item response",h),m.version=h.version,m.list=JSON.parse(h.value),c(m)}catch{console.log("Reverting to old values due to error"),c(JSON.parse(p))}finally{d(!1)}}function tv(t,i,o){return i=Xa(i),wy(t,nv()?Reflect.construct(i,o||[],Xa(t).constructor):i.apply(t,o))}function nv(){try{var t=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(nv=function(){return!!t})()}function ky(t,i){var o=t==null?null:typeof Symbol<"u"&&t[Symbol.iterator]||t["@@iterator"];if(o!=null){var l,c,d,p,f=[],m=!0,h=!1;try{if(d=(o=o.call(t)).next,i!==0)for(;!(m=(l=d.call(o)).done)&&(f.push(l.value),f.length!==i);m=!0);}catch(g){h=!0,c=g}finally{try{if(!m&&o.return!=null&&(p=o.return(),Object(p)!==p))return}finally{if(h)throw c}}return f}}function Ey(t,i){if(typeof t!="object"||!t)return t;var o=t[Symbol.toPrimitive];if(o!==void 0){var l=o.call(t,i);if(typeof l!="object")return l;throw new TypeError("@@toPrimitive must return a primitive value.")}return(i==="string"?String:Number)(t)}function rv(t){var i=Ey(t,"string");return typeof i=="symbol"?i:i+""}function fr(t){return fr=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(i){return typeof i}:function(i){return i&&typeof Symbol=="function"&&i.constructor===Symbol&&i!==Symbol.prototype?"symbol":typeof i},fr(t)}function ov(t,i){if(!(t instanceof i))throw new TypeError("Cannot call a class as a function")}function qp(t,i){for(var o=0;i.length>o;o++){var l=i[o];l.enumerable=l.enumerable||!1,l.configurable=!0,"value"in l&&(l.writable=!0),Object.defineProperty(t,rv(l.key),l)}}function iv(t,i,o){return i&&qp(t.prototype,i),o&&qp(t,o),Object.defineProperty(t,"prototype",{writable:!1}),t}function se(t,i,o){return(i=rv(i))in t?Object.defineProperty(t,i,{value:o,enumerable:!0,configurable:!0,writable:!0}):t[i]=o,t}function av(t,i){if(typeof i!="function"&&i!==null)throw new TypeError("Super expression must either be null or a function");t.prototype=Object.create(i&&i.prototype,{constructor:{value:t,writable:!0,configurable:!0}}),Object.defineProperty(t,"prototype",{writable:!1}),i&&Cc(t,i)}function Xa(t){return Xa=Object.setPrototypeOf?Object.getPrototypeOf.bind():function(i){return i.__proto__||Object.getPrototypeOf(i)},Xa(t)}function Cc(t,i){return Cc=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(o,l){return o.__proto__=l,o},Cc(t,i)}function Sy(t){if(t===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return t}function wy(t,i){if(i&&(typeof i=="object"||typeof i=="function"))return i;if(i!==void 0)throw new TypeError("Derived constructors may only return object or undefined");return Sy(t)}function Tt(t,i){return Ty(t)||ky(t,i)||lv(t,i)||Ny()}function wu(t){return Cy(t)||Oy(t)||lv(t)||Ay()}function Cy(t){if(Array.isArray(t))return Tc(t)}function Ty(t){if(Array.isArray(t))return t}function Oy(t){if(typeof Symbol<"u"&&t[Symbol.iterator]!=null||t["@@iterator"]!=null)return Array.from(t)}function lv(t,i){if(t){if(typeof t=="string")return Tc(t,i);var o=Object.prototype.toString.call(t).slice(8,-1);return o==="Object"&&t.constructor&&(o=t.constructor.name),o==="Map"||o==="Set"?Array.from(t):o==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)?Tc(t,i):void 0}}function Tc(t,i){(i==null||i>t.length)&&(i=t.length);for(var o=0,l=Array(i);i>o;o++)l[o]=t[o];return l}function Ay(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Ny(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var mc={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/var Qp;function Ly(){return Qp||(Qp=1,function(t){(function(){var i={}.hasOwnProperty;function o(){for(var l=[],c=0;c<arguments.length;c++){var d=arguments[c];if(d){var p=typeof d;if(p==="string"||p==="number")l.push(d);else if(Array.isArray(d)){if(d.length){var f=o.apply(null,d);f&&l.push(f)}}else if(p==="object"){if(d.toString!==Object.prototype.toString&&!d.toString.toString().includes("[native code]")){l.push(d.toString());continue}for(var m in d)i.call(d,m)&&d[m]&&l.push(m)}}}return l.join(" ")}t.exports?(o.default=o,t.exports=o):window.classNames=o})()}(mc)),mc.exports}var Ry=Ly();const ue=lo(Ry);var Jr=function(){return typeof window<"u"},tl=Jr()?k.useLayoutEffect:k.useEffect;function $t(){for(var t=arguments.length,i=Array(t),o=0;t>o;o++)i[o]=arguments[o];var l=k.useRef(null);return tl(function(){i.forEach(function(c){c&&(typeof c=="function"?c(l.current):c.current=l.current)})},[i]),l}var Ze,Zp,pr;(function(t){t.EMPTY_STATE="empty-state",t.TRANSITION_VIEW="transition-view",t.TEXT_AREA="text-area",t.EDITABLE_TEXT="editable-text",t.TIPSEEN_MEDIA="tipseen-media",t.INDICATOR="indicator",t.BADGE="badge",t.TITLE="title",t.TEXT="text",t.COMBOBOX="combobox",t.COMBOBOX_CATEGORY="combobox-category",t.COMBOBOX_OPTION="combobox-option",t.COLOR_PICKER="color-picker",t.CHECKBOX="checkbox",t.CHECKBOX_LABEL="checkbox-label",t.CHECKBOX_CHECKBOX="checkbox-checkbox",t.DROPDOWN="dropdown",t.DROPDOWN_OPTION_CONTENT="dropdown-option-content",t.BUTTON="button",t.BUTTON_GROUP="button-group",t.CLICKABLE="clickable",t.VIRTUALIZED_LIST="virtualized-list",t.VIRTUALIZED_GRID="virtualized-grid",t.TEXT_FIELD="text-field",t.TEXT_FIELD_SECONDARY_BUTTON="text-field-secondary-button",t.SEARCH="search",t.CLEAN_SEARCH_BUTTON="clean-search-button",t.COLOR_PICKER_ITEM="color-picker-item",t.ICON_BUTTON="icon-button",t.SVG_ICON="svg-icon",t.CHIP="chip",t.RADIO_BUTTON="radio-button",t.RADIO_BUTTON_LABEL="radio-button-label",t.RADIO_BUTTON_CONTROL="radio-button-control",t.TAB="tab",t.TAB_PANEL="tab-panel",t.TAB_PANELS="tab-panels",t.TAB_LIST="tab-list",t.TABS_CONTEXT="tabs-context",t.ALERT_BANNER="alert-banner",t.ALERT_BANNER_BUTTON="alert-banner-button",t.ALERT_BANNER_LINK="alert-banner-link",t.ALERT_BANNER_TEXT="alert-banner-text",t.ATTENTION_BOX="attention-box",t.BOX="box",t.AVATAR="avatar",t.AVATAR_BADGE="avatar-badge",t.AVATAR_CONTENT="avatar-content",t.BREADCRUMB_ITEM="breadcrumb-item",t.BREADCRUMBS_BAR="breadcrumbs-bar",t.BREADCRUMB_MENU="breadcrumb-menu",t.BREADCRUMB_MENU_ITEM="breadcrumb-menu-item",t.LINEAR_PROGRESS_BAR="linear-progress-bar",t.BAR="bar",t.BAR_PRIMARY="bar-primary",t.BAR_SECONDARY="bar-secondary",t.COLOR_PICKER_ITEM_COMPONENT="color-picker-item-component",t.COUNTER="counter",t.MENU="menu",t.OPTION="option",t.EXPAND_COLLAPSE="expand-collapse",t.EDITABLE_INPUT="editable-input",t.EDITABLE_HEADING="editable-heading",t.HEADING="heading",t.LABEL="label",t.LINK="link",t.MENU_DIVIDER="menu-divider",t.MENU_ITEM="menu-item",t.MENU_ITEM_BUTTON="menu-item-button",t.MENU_TITLE="menu-title",t.MENU_TITLE_CAPTION="menu-title-caption",t.MENU_GRID_ITEM="menu-grid-item",t.MENU_BUTTON="menu-button",t.STEP_INDICATOR="step-indicator",t.STEPS="steps",t.STEPS_FORWARD_COMMAND="steps-forward-command",t.STEPS_BACKWARD_COMMAND="steps-backward-command",t.MULTI_STEP_INDICATOR="multi-step-indicator",t.SKELETON="skeleton",t.SPLIT_BUTTON="split-button",t.SPLIT_BUTTON_PRIMARY_BUTTON="split-button-primary-button",t.SPLIT_BUTTON_SECONDARY_BUTTON="split-button-secondary-button",t.TEXT_WITH_HIGHLIGHT="text-with-highlight",t.TOAST="toast",t.TOAST_CONTENT="toast-content",t.TOAST_LINK="toast-link",t.TOAST_BUTTON="toast-button",t.TOAST_CLOSE_BUTTON="toast-close-button",t.TOGGLE="toggle",t.TIPSEEN="tipseen",t.TIPSEEN_CONTENT="tipseen-content",t.TIPSEEN_CONTENT_SUBMIT="tipseen-content-submit",t.TIPSEEN_CONTENT_DISMISS="tipseen-content-dismiss",t.TIPSEEN_TITLE="tipseen-title",t.DIVIDER="divider",t.DATEPICKER="date-picker",t.DATEPICKER_HEADER="date-picker-header",t.DATEPICKER_YEAR_SELECTION="date-picker-year-selection",t.LOADER="loader",t.ICON="icon",t.RESPONSIVE_LIST="responsive-list",t.LIST="list",t.MODAL="monday-dialog-container",t.MODAL_OVERLAY="monday-modal-overlay",t.MODAL_CONTENT="modal-content",t.MODAL_HEADER="modal-header",t.MODAL_FOOTER_BUTTONS="modal-footer-buttons",t.MODAL_NEXT="modal",t.MODAL_NEXT_OVERLAY="modal-overlay",t.MODAL_NEXT_HEADER="modal-header",t.MODAL_NEXT_CLOSE_BUTTON="modal-close-button",t.MODAL_NEXT_CONTENT="modal-content",t.MODAL_NEXT_FOOTER="modal-footer",t.MODAL_NEXT_MEDIA="modal-media",t.MODAL_NEXT_BASIC_LAYOUT="modal-basic-layout",t.MODAL_NEXT_SIDE_BY_SIDE_LAYOUT="modal-side-by-side-layout",t.MODAL_NEXT_MEDIA_LAYOUT="modal-media-layout",t.FORMATTED_NUMBER="formatted-number",t.HIDDEN_TEXT="hidden-text",t.DIALOG_CONTENT_CONTAINER="dialog-content-container",t.FLEX="flex",t.TOOLTIP="tooltip",t.DIALOG="dialog",t.TABLE="table",t.TABLE_CONTAINER="table-container",t.TABLE_BODY="table-body",t.TABLE_VIRTUALIZED_BODY="table-virtualized-body",t.TABLE_CELL="table-cell",t.TABLE_HEADER="table-header",t.TABLE_HEADER_CELL="table-header-cell",t.TABLE_ROW="table-row",t.TABLE_ROW_MENU="table-row-menu"})(Ze||(Ze={})),function(t){t.RIGHT_ARROW="{arrowright}",t.LEFT_ARROW="{arrowleft}",t.UP_ARROW="{arrowup}",t.DOWN_ARROW="{arrowdown}",t.TAB="#TAB#",t.ENTER="{enter}",t.PAGE_UP="{pageup}",t.PAGE_DOWN="{pagedown}"}(Zp||(Zp={})),function(t){t.ACCORDION="Accordion",t.ALERT_BANNER="AlertBanner",t.ATTENTION_BOX="AttentionBox",t.AVATAR="Avatar",t.AVATAR_GROUP="AvatarGroup",t.BADGE="Badge",t.BOX="Box",t.BREADCRUMBS_BAR="BreadcrumbsBar",t.BUTTON="Button",t.BUTTON_GROUP="ButtonGroup",t.CHECKBOX="Checkbox",t.CHIPS="Chips",t.COLOR_PICKER="ColorPicker",t.COMBOBOX="Combobox",t.COUNTER="Counter",t.DATE_PICKER="DatePicker",t.DIALOG="Dialog",t.DIVIDER="Divider",t.DROPDOWN="Dropdown",t.EDITABLE_HEADING="EditableHeading",t.EDITABLE_TEXT="EditableText",t.EXPAND_COLLAPSE="ExpandCollapse",t.FLEX="Flex",t.HEADING="Heading",t.ICON="Icon",t.ICON_BUTTON="IconButton",t.LABEL="Label",t.LINEAR_PROGRESS_BAR="LinearProgressBar",t.LINK="Link",t.LIST="List",t.LOADER="Loader",t.MENU="Menu",t.MENU_BUTTON="MenuButton",t.MODAL="Modal",t.MULTI_STEP_INDICATOR="MultiStepIndicator",t.RADIO_BUTTON="RadioButton",t.SEARCH="Search",t.SKELETON="Skeleton",t.SLIDER="Slider",t.SPLIT_BUTTON="SplitButton",t.STEPS="Steps",t.TAB="Tab",t.TABLE="Table",t.TEXT="Text",t.TEXT_AREA="TextArea",t.TEXT_FIELD="TextField",t.TEXT_WITH_HIGHLIGHT="TextWithHighlight",t.THEME_PROVIDER="ThemeProvider",t.TIPSEEN="Tipseen",t.TOAST="Toast",t.TOGGLE="Toggle",t.TOOLTIP="Tooltip",t.VIRTUALIZED_GRID="VirtualizedGrid",t.VIRTUALIZED_LIST="VirtualizedList"}(pr||(pr={}));var pn=Ze,De=function(t,i){var o=""+(i??"");return"".concat(t).concat(o&&"_".concat(o))},Oc;(function(t){t.SVG="svg",t.ICON_FONT="font",t.SRC="src"})(Oc||(Oc={}));var Py=t=>typeof t!="string"?{}:t.split(/ ?; ?/).reduce((i,o)=>{const[l,c]=o.split(/ ?: ?/).map((d,p)=>p===0?d.replace(/\s+/g,""):d.trim());if(l&&c){const d=l.replace(/(\w)-(\w)/g,(f,m,h)=>`${m}${h.toUpperCase()}`);let p=c.trim();Number.isNaN(Number(c))||(p=Number(c)),i[l.startsWith("-")?l:d]=p}return i},{});function Dy(t=6){const i="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";let o="";for(let l=t;l>0;--l)o+=i[Math.round(Math.random()*(i.length-1))];return o}var Iy=["br","col","colgroup","dl","hr","iframe","img","input","link","menuitem","meta","ol","param","select","table","tbody","tfoot","thead","tr","ul","wbr"],Jp={"accept-charset":"acceptCharset",acceptcharset:"acceptCharset",accesskey:"accessKey",allowfullscreen:"allowFullScreen",autocapitalize:"autoCapitalize",autocomplete:"autoComplete",autocorrect:"autoCorrect",autofocus:"autoFocus",autoplay:"autoPlay",autosave:"autoSave",cellpadding:"cellPadding",cellspacing:"cellSpacing",charset:"charSet",class:"className",classid:"classID",classname:"className",colspan:"colSpan",contenteditable:"contentEditable",contextmenu:"contextMenu",controlslist:"controlsList",crossorigin:"crossOrigin",dangerouslysetinnerhtml:"dangerouslySetInnerHTML",datetime:"dateTime",defaultchecked:"defaultChecked",defaultvalue:"defaultValue",enctype:"encType",for:"htmlFor",formmethod:"formMethod",formaction:"formAction",formenctype:"formEncType",formnovalidate:"formNoValidate",formtarget:"formTarget",frameborder:"frameBorder",hreflang:"hrefLang",htmlfor:"htmlFor",httpequiv:"httpEquiv","http-equiv":"httpEquiv",icon:"icon",innerhtml:"innerHTML",inputmode:"inputMode",itemid:"itemID",itemprop:"itemProp",itemref:"itemRef",itemscope:"itemScope",itemtype:"itemType",keyparams:"keyParams",keytype:"keyType",marginwidth:"marginWidth",marginheight:"marginHeight",maxlength:"maxLength",mediagroup:"mediaGroup",minlength:"minLength",nomodule:"noModule",novalidate:"noValidate",playsinline:"playsInline",radiogroup:"radioGroup",readonly:"readOnly",referrerpolicy:"referrerPolicy",rowspan:"rowSpan",spellcheck:"spellCheck",srcdoc:"srcDoc",srclang:"srcLang",srcset:"srcSet",tabindex:"tabIndex",typemustmatch:"typeMustMatch",usemap:"useMap",accentheight:"accentHeight","accent-height":"accentHeight",alignmentbaseline:"alignmentBaseline","alignment-baseline":"alignmentBaseline",allowreorder:"allowReorder",arabicform:"arabicForm","arabic-form":"arabicForm",attributename:"attributeName",attributetype:"attributeType",autoreverse:"autoReverse",basefrequency:"baseFrequency",baselineshift:"baselineShift","baseline-shift":"baselineShift",baseprofile:"baseProfile",calcmode:"calcMode",capheight:"capHeight","cap-height":"capHeight",clippath:"clipPath","clip-path":"clipPath",clippathunits:"clipPathUnits",cliprule:"clipRule","clip-rule":"clipRule",colorinterpolation:"colorInterpolation","color-interpolation":"colorInterpolation",colorinterpolationfilters:"colorInterpolationFilters","color-interpolation-filters":"colorInterpolationFilters",colorprofile:"colorProfile","color-profile":"colorProfile",colorrendering:"colorRendering","color-rendering":"colorRendering",contentscripttype:"contentScriptType",contentstyletype:"contentStyleType",diffuseconstant:"diffuseConstant",dominantbaseline:"dominantBaseline","dominant-baseline":"dominantBaseline",edgemode:"edgeMode",enablebackground:"enableBackground","enable-background":"enableBackground",externalresourcesrequired:"externalResourcesRequired",fillopacity:"fillOpacity","fill-opacity":"fillOpacity",fillrule:"fillRule","fill-rule":"fillRule",filterres:"filterRes",filterunits:"filterUnits",floodopacity:"floodOpacity","flood-opacity":"floodOpacity",floodcolor:"floodColor","flood-color":"floodColor",fontfamily:"fontFamily","font-family":"fontFamily",fontsize:"fontSize","font-size":"fontSize",fontsizeadjust:"fontSizeAdjust","font-size-adjust":"fontSizeAdjust",fontstretch:"fontStretch","font-stretch":"fontStretch",fontstyle:"fontStyle","font-style":"fontStyle",fontvariant:"fontVariant","font-variant":"fontVariant",fontweight:"fontWeight","font-weight":"fontWeight",glyphname:"glyphName","glyph-name":"glyphName",glyphorientationhorizontal:"glyphOrientationHorizontal","glyph-orientation-horizontal":"glyphOrientationHorizontal",glyphorientationvertical:"glyphOrientationVertical","glyph-orientation-vertical":"glyphOrientationVertical",glyphref:"glyphRef",gradienttransform:"gradientTransform",gradientunits:"gradientUnits",horizadvx:"horizAdvX","horiz-adv-x":"horizAdvX",horizoriginx:"horizOriginX","horiz-origin-x":"horizOriginX",imagerendering:"imageRendering","image-rendering":"imageRendering",kernelmatrix:"kernelMatrix",kernelunitlength:"kernelUnitLength",keypoints:"keyPoints",keysplines:"keySplines",keytimes:"keyTimes",lengthadjust:"lengthAdjust",letterspacing:"letterSpacing","letter-spacing":"letterSpacing",lightingcolor:"lightingColor","lighting-color":"lightingColor",limitingconeangle:"limitingConeAngle",markerend:"markerEnd","marker-end":"markerEnd",markerheight:"markerHeight",markermid:"markerMid","marker-mid":"markerMid",markerstart:"markerStart","marker-start":"markerStart",markerunits:"markerUnits",markerwidth:"markerWidth",maskcontentunits:"maskContentUnits",maskunits:"maskUnits",numoctaves:"numOctaves",overlineposition:"overlinePosition","overline-position":"overlinePosition",overlinethickness:"overlineThickness","overline-thickness":"overlineThickness",paintorder:"paintOrder","paint-order":"paintOrder","panose-1":"panose1",pathlength:"pathLength",patterncontentunits:"patternContentUnits",patterntransform:"patternTransform",patternunits:"patternUnits",pointerevents:"pointerEvents","pointer-events":"pointerEvents",pointsatx:"pointsAtX",pointsaty:"pointsAtY",pointsatz:"pointsAtZ",preservealpha:"preserveAlpha",preserveaspectratio:"preserveAspectRatio",primitiveunits:"primitiveUnits",refx:"refX",refy:"refY",renderingintent:"renderingIntent","rendering-intent":"renderingIntent",repeatcount:"repeatCount",repeatdur:"repeatDur",requiredextensions:"requiredExtensions",requiredfeatures:"requiredFeatures",shaperendering:"shapeRendering","shape-rendering":"shapeRendering",specularconstant:"specularConstant",specularexponent:"specularExponent",spreadmethod:"spreadMethod",startoffset:"startOffset",stddeviation:"stdDeviation",stitchtiles:"stitchTiles",stopcolor:"stopColor","stop-color":"stopColor",stopopacity:"stopOpacity","stop-opacity":"stopOpacity",strikethroughposition:"strikethroughPosition","strikethrough-position":"strikethroughPosition",strikethroughthickness:"strikethroughThickness","strikethrough-thickness":"strikethroughThickness",strokedasharray:"strokeDasharray","stroke-dasharray":"strokeDasharray",strokedashoffset:"strokeDashoffset","stroke-dashoffset":"strokeDashoffset",strokelinecap:"strokeLinecap","stroke-linecap":"strokeLinecap",strokelinejoin:"strokeLinejoin","stroke-linejoin":"strokeLinejoin",strokemiterlimit:"strokeMiterlimit","stroke-miterlimit":"strokeMiterlimit",strokewidth:"strokeWidth","stroke-width":"strokeWidth",strokeopacity:"strokeOpacity","stroke-opacity":"strokeOpacity",suppresscontenteditablewarning:"suppressContentEditableWarning",suppresshydrationwarning:"suppressHydrationWarning",surfacescale:"surfaceScale",systemlanguage:"systemLanguage",tablevalues:"tableValues",targetx:"targetX",targety:"targetY",textanchor:"textAnchor","text-anchor":"textAnchor",textdecoration:"textDecoration","text-decoration":"textDecoration",textlength:"textLength",textrendering:"textRendering","text-rendering":"textRendering",underlineposition:"underlinePosition","underline-position":"underlinePosition",underlinethickness:"underlineThickness","underline-thickness":"underlineThickness",unicodebidi:"unicodeBidi","unicode-bidi":"unicodeBidi",unicoderange:"unicodeRange","unicode-range":"unicodeRange",unitsperem:"unitsPerEm","units-per-em":"unitsPerEm",unselectable:"unselectable",valphabetic:"vAlphabetic","v-alphabetic":"vAlphabetic",vectoreffect:"vectorEffect","vector-effect":"vectorEffect",vertadvy:"vertAdvY","vert-adv-y":"vertAdvY",vertoriginx:"vertOriginX","vert-origin-x":"vertOriginX",vertoriginy:"vertOriginY","vert-origin-y":"vertOriginY",vhanging:"vHanging","v-hanging":"vHanging",videographic:"vIdeographic","v-ideographic":"vIdeographic",viewbox:"viewBox",viewtarget:"viewTarget",vmathematical:"vMathematical","v-mathematical":"vMathematical",wordspacing:"wordSpacing","word-spacing":"wordSpacing",writingmode:"writingMode","writing-mode":"writingMode",xchannelselector:"xChannelSelector",xheight:"xHeight","x-height":"xHeight",xlinkactuate:"xlinkActuate","xlink:actuate":"xlinkActuate",xlinkarcrole:"xlinkArcrole","xlink:arcrole":"xlinkArcrole",xlinkhref:"xlinkHref","xlink:href":"xlinkHref",xlinkrole:"xlinkRole","xlink:role":"xlinkRole",xlinkshow:"xlinkShow","xlink:show":"xlinkShow",xlinktitle:"xlinkTitle","xlink:title":"xlinkTitle",xlinktype:"xlinkType","xlink:type":"xlinkType",xmlbase:"xmlBase","xml:base":"xmlBase",xmllang:"xmlLang","xml:lang":"xmlLang","xml:space":"xmlSpace",xmlnsxlink:"xmlnsXlink","xmlns:xlink":"xmlnsXlink",xmlspace:"xmlSpace",ychannelselector:"yChannelSelector",zoomandpan:"zoomAndPan",onblur:"onBlur",onchange:"onChange",onclick:"onClick",oncontextmenu:"onContextMenu",ondoubleclick:"onDoubleClick",ondrag:"onDrag",ondragend:"onDragEnd",ondragenter:"onDragEnter",ondragexit:"onDragExit",ondragleave:"onDragLeave",ondragover:"onDragOver",ondragstart:"onDragStart",ondrop:"onDrop",onerror:"onError",onfocus:"onFocus",oninput:"onInput",oninvalid:"onInvalid",onkeydown:"onKeyDown",onkeypress:"onKeyPress",onkeyup:"onKeyUp",onload:"onLoad",onmousedown:"onMouseDown",onmouseenter:"onMouseEnter",onmouseleave:"onMouseLeave",onmousemove:"onMouseMove",onmouseout:"onMouseOut",onmouseover:"onMouseOver",onmouseup:"onMouseUp",onscroll:"onScroll",onsubmit:"onSubmit",ontouchcancel:"onTouchCancel",ontouchend:"onTouchEnd",ontouchmove:"onTouchMove",ontouchstart:"onTouchStart",onwheel:"onWheel"};function My(t,i){var d;const{key:o,level:l,...c}=i;switch(t.nodeType){case 1:return k.createElement(jy(t.nodeName),By(t,o),em(t.childNodes,l,c));case 3:{const p=((d=t.nodeValue)==null?void 0:d.toString())??"";if(!c.allowWhiteSpaces&&/^\s+$/.test(p)&&!/[\u00A0\u202F]/.test(p))return null;if(!t.parentNode)return p;const f=t.parentNode.nodeName.toLowerCase();return Iy.includes(f)?(/\S/.test(p)&&console.warn(`A textNode is not allowed inside '${f}'. Your text "${p}" will be ignored`),null):p}case 8:return null;case 11:return em(t.childNodes,l,i);default:return null}}function By(t,i){const o={key:i};if(t instanceof Element){const l=t.getAttribute("class");l&&(o.className=l),[...t.attributes].forEach(c=>{switch(c.name){case"class":break;case"style":o[c.name]=Py(c.value);break;case"allowfullscreen":case"allowpaymentrequest":case"async":case"autofocus":case"autoplay":case"checked":case"controls":case"default":case"defer":case"disabled":case"formnovalidate":case"hidden":case"ismap":case"itemscope":case"loop":case"multiple":case"muted":case"nomodule":case"novalidate":case"open":case"readonly":case"required":case"reversed":case"selected":case"typemustmatch":o[Jp[c.name]||c.name]=!0;break;default:o[Jp[c.name]||c.name]=c.value}})}return o}function em(t,i,o){const l=[...t].map((c,d)=>Ua(c,{...o,index:d,level:i+1})).filter(Boolean);return l.length?l:null}function jy(t){return/[a-z]+[A-Z]+[a-z]+/.test(t)?t:t.toLowerCase()}function Ua(t,i={}){if(!t||!(t instanceof Node))return null;const{actions:o=[],index:l=0,level:c=0,randomKey:d}=i;let p=t,f=`${c}-${l}`;const m=[];return d&&c===0&&(f=`${Dy()}-${f}`),Array.isArray(o)&&o.forEach(h=>{h.condition(p,f,c)&&(typeof h.pre=="function"&&(p=h.pre(p,f,c),p instanceof Node||(p=t)),typeof h.post=="function"&&m.push(h.post(p,f,c)))}),m.length?m:My(p,{key:f,level:c,...i})}function $y(t,i={}){if(!t||typeof t!="string")return null;const{includeAllNodes:o=!1,nodeOnly:l=!1,selector:c="body > *",type:d="text/html"}=i;try{const f=new DOMParser().parseFromString(t,d);if(o){const{childNodes:h}=f.body;return l?h:[...h].map(g=>Ua(g,i))}const m=f.querySelector(c)||f.body.childNodes[0];if(!(m instanceof Node))throw new TypeError("Error parsing input");return l?m:Ua(m,i)}catch{}return null}function sv(t,i={}){return typeof t=="string"?$y(t,i):t instanceof Node?Ua(t,i):null}var zy=Object.defineProperty,Fy=(t,i,o)=>i in t?zy(t,i,{enumerable:!0,configurable:!0,writable:!0,value:o}):t[i]=o,Aa=(t,i,o)=>(Fy(t,typeof i!="symbol"?i+"":i,o),o),tm="react-inlinesvg",nm=10,Ce={IDLE:"idle",LOADING:"loading",LOADED:"loaded",FAILED:"failed",READY:"ready",UNSUPPORTED:"unsupported"};function $a(){return!!(typeof window<"u"&&window.document&&window.document.createElement)}function Xy(){return Hy()&&typeof window<"u"&&window!==null}async function cv(t,i){const o=await fetch(t,i),l=o.headers.get("content-type"),[c]=(l??"").split(/ ?; ?/);if(o.status>299)throw new Error("Not found");if(!["image/svg+xml","text/plain"].some(d=>c.includes(d)))throw new Error(`Content type isn't valid: ${c}`);return o.text()}function Uy(t=1){return new Promise(i=>{setTimeout(i,t*1e3)})}function Hy(){if(!document)return!1;const t=document.createElement("div");t.innerHTML="<svg />";const i=t.firstChild;return!!i&&i.namespaceURI==="http://www.w3.org/2000/svg"}function Wy(t){return t[Math.floor(Math.random()*t.length)]}function Vy(t){const i="abcdefghijklmnopqrstuvwxyz",l=`${i}${i.toUpperCase()}1234567890`;let c="";for(let d=0;d<t;d++)c+=Wy(l);return c}function Gy(t,...i){const o={};for(const l in t)({}).hasOwnProperty.call(t,l)&&(i.includes(l)||(o[l]=t[l]));return o}var Ky=class{constructor(){Aa(this,"cacheApi"),Aa(this,"cacheStore"),Aa(this,"subscribers",[]),Aa(this,"isReady",!1),this.cacheStore=new Map;let t=tm,i=!1;$a()&&(t=window.REACT_INLINESVG_CACHE_NAME??tm,i=!!window.REACT_INLINESVG_PERSISTENT_CACHE&&"caches"in window),i?caches.open(t).then(o=>{this.cacheApi=o,this.isReady=!0,this.subscribers.forEach(l=>l())}).catch(o=>{this.isReady=!0,console.error(`Failed to open cache: ${o.message}`)}):this.isReady=!0}onReady(t){this.isReady?t():this.subscribers.push(t)}async get(t,i){var o;return await(this.cacheApi?this.fetchAndAddToPersistentCache(t,i):this.fetchAndAddToInternalCache(t,i)),((o=this.cacheStore.get(t))==null?void 0:o.content)??""}set(t,i){this.cacheStore.set(t,i)}isCached(t){var i;return((i=this.cacheStore.get(t))==null?void 0:i.status)===Ce.LOADED}async fetchAndAddToInternalCache(t,i){const o=this.cacheStore.get(t);if((o==null?void 0:o.status)===Ce.LOADING){await this.handleLoading(t,async()=>{this.cacheStore.set(t,{content:"",status:Ce.IDLE}),await this.fetchAndAddToInternalCache(t,i)});return}if(!(o!=null&&o.content)){this.cacheStore.set(t,{content:"",status:Ce.LOADING});try{const l=await cv(t,i);this.cacheStore.set(t,{content:l,status:Ce.LOADED})}catch(l){throw this.cacheStore.set(t,{content:"",status:Ce.FAILED}),l}}}async fetchAndAddToPersistentCache(t,i){var c,d,p;const o=this.cacheStore.get(t);if((o==null?void 0:o.status)===Ce.LOADED)return;if((o==null?void 0:o.status)===Ce.LOADING){await this.handleLoading(t,async()=>{this.cacheStore.set(t,{content:"",status:Ce.IDLE}),await this.fetchAndAddToPersistentCache(t,i)});return}this.cacheStore.set(t,{content:"",status:Ce.LOADING});const l=await((c=this.cacheApi)==null?void 0:c.match(t));if(l){const f=await l.text();this.cacheStore.set(t,{content:f,status:Ce.LOADED});return}try{await((d=this.cacheApi)==null?void 0:d.add(new Request(t,i)));const f=await((p=this.cacheApi)==null?void 0:p.match(t)),m=await(f==null?void 0:f.text())??"";this.cacheStore.set(t,{content:m,status:Ce.LOADED})}catch(f){throw this.cacheStore.set(t,{content:"",status:Ce.FAILED}),f}}async handleLoading(t,i){var l;let o=0;for(;((l=this.cacheStore.get(t))==null?void 0:l.status)===Ce.LOADING&&o<nm;)await Uy(.1),o+=1;o>=nm&&await i()}keys(){return[...this.cacheStore.keys()]}data(){return[...this.cacheStore.entries()].map(([t,i])=>({[t]:i}))}async delete(t){this.cacheApi&&await this.cacheApi.delete(t),this.cacheStore.delete(t)}async clear(){if(this.cacheApi){const t=await this.cacheApi.keys();for(const i of t)await this.cacheApi.delete(i)}this.cacheStore.clear()}};function rm(t){const i=k.useRef();return k.useEffect(()=>{i.current=t}),i.current}function Yy(t){const{baseURL:i,content:o,description:l,handleError:c,hash:d,preProcessor:p,title:f,uniquifyIDs:m=!1}=t;try{const h=qy(o,p),g=sv(h,{nodeOnly:!0});if(!g||!(g instanceof SVGSVGElement))throw new Error("Could not convert the src to a DOM Node");const y=uv(g,{baseURL:i,hash:d,uniquifyIDs:m});if(l){const b=y.querySelector("desc");b!=null&&b.parentNode&&b.parentNode.removeChild(b);const w=document.createElementNS("http://www.w3.org/2000/svg","desc");w.innerHTML=l,y.prepend(w)}if(typeof f<"u"){const b=y.querySelector("title");if(b!=null&&b.parentNode&&b.parentNode.removeChild(b),f){const w=document.createElementNS("http://www.w3.org/2000/svg","title");w.innerHTML=f,y.prepend(w)}}return y}catch(h){return c(h)}}function qy(t,i){return i?i(t):t}function uv(t,i){const{baseURL:o="",hash:l,uniquifyIDs:c}=i,d=["id","href","xlink:href","xlink:role","xlink:arcrole"],p=["href","xlink:href"],f=(m,h)=>p.includes(m)&&(h?!h.includes("#"):!1);return c&&[...t.children].forEach(m=>{var h;if((h=m.attributes)!=null&&h.length){const g=Object.values(m.attributes).map(y=>{const b=y,w=/url\((.*?)\)/.exec(y.value);return w!=null&&w[1]&&(b.value=y.value.replace(w[0],`url(${o}${w[1]}__${l})`)),b});d.forEach(y=>{const b=g.find(w=>w.name===y);b&&!f(y,b.value)&&(b.value=`${b.value}__${l}`)})}return m.children.length?uv(m,i):m}),t}var Qr;function Qy(t){const{cacheRequests:i=!0,children:o=null,description:l,fetchOptions:c,innerRef:d,loader:p=null,onError:f,onLoad:m,src:h,title:g,uniqueHash:y}=t,[b,w]=k.useReducer((oe,ve)=>({...oe,...ve}),{content:"",element:null,isCached:i&&Qr.isCached(t.src),status:Ce.IDLE}),{content:N,element:L,isCached:O,status:R}=b,M=rm(t),z=rm(b),I=k.useRef(y??Vy(8)),B=k.useRef(!1),j=k.useRef(!1),X=k.useCallback(oe=>{B.current&&(w({status:oe.message==="Browser does not support SVG"?Ce.UNSUPPORTED:Ce.FAILED}),f==null||f(oe))},[f]),K=k.useCallback((oe,ve=!1)=>{B.current&&w({content:oe,isCached:ve,status:Ce.LOADED})},[]),ce=k.useCallback(async()=>{const oe=await cv(h,c);K(oe)},[c,K,h]),Q=k.useCallback(()=>{try{const oe=Yy({...t,handleError:X,hash:I.current,content:N}),ve=sv(oe);if(!ve||!k.isValidElement(ve))throw new Error("Could not convert the src to a React element");w({element:ve,status:Ce.READY})}catch(oe){X(new Error(oe.message))}},[N,X,t]),Z=k.useCallback(async()=>{const oe=/^data:image\/svg[^,]*?(;base64)?,(.*)/u.exec(h);let ve;if(oe?ve=oe[1]?window.atob(oe[2]):decodeURIComponent(oe[2]):h.includes("<svg")&&(ve=h),ve){K(ve);return}try{if(i){const re=await Qr.get(h,c);K(re,!0)}else await ce()}catch(re){X(re)}},[i,ce,c,X,K,h]),le=k.useCallback(async()=>{B.current&&w({content:"",element:null,isCached:!1,status:Ce.LOADING})},[]);k.useEffect(()=>{if(B.current=!0,!$a()||j.current)return()=>{};try{if(R===Ce.IDLE){if(!Xy())throw new Error("Browser does not support SVG");if(!h)throw new Error("Missing src");le()}}catch(oe){X(oe)}return j.current=!0,()=>{B.current=!1}},[]),k.useEffect(()=>{if($a()&&M)if(M.src!==h){if(!h){X(new Error("Missing src"));return}le()}else(M.title!==g||M.description!==l)&&Q()},[l,Q,X,le,M,h,g]),k.useEffect(()=>{z&&(z.status!==Ce.LOADING&&R===Ce.LOADING&&Z(),z.status!==Ce.LOADED&&R===Ce.LOADED&&Q(),z.status!==Ce.READY&&R===Ce.READY&&(m==null||m(h,O)))},[Z,Q,O,m,z,h,R]);const de=Gy(t,"baseURL","cacheRequests","children","description","fetchOptions","innerRef","loader","onError","onLoad","preProcessor","src","title","uniqueHash","uniquifyIDs");return $a()?L?k.cloneElement(L,{ref:d,...de}):[Ce.UNSUPPORTED,Ce.FAILED].includes(R)?o:p:p}function om(t){Qr||(Qr=new Ky);const{loader:i}=t,o=k.useRef(!1),[l,c]=k.useState(Qr.isReady);return k.useEffect(()=>{o.current||(Qr.onReady(()=>{c(!0)}),o.current=!0)},[]),l?he.jsx(Qy,{...t}):i}var Zy=typeof global=="object"&&global&&global.Object===Object&&global,Jy=typeof self=="object"&&self&&self.Object===Object&&self,nl=Zy||Jy||Function("return this")(),no=nl.Symbol,dv=Object.prototype,e1=dv.hasOwnProperty,t1=dv.toString,ei=no?no.toStringTag:void 0;function n1(t){var i=e1.call(t,ei),o=t[ei];try{t[ei]=void 0;var l=!0}catch{}var c=t1.call(t);return l&&(i?t[ei]=o:delete t[ei]),c}var r1=Object.prototype,o1=r1.toString;function i1(t){return o1.call(t)}var a1="[object Null]",l1="[object Undefined]",im=no?no.toStringTag:void 0;function fv(t){return t==null?t===void 0?l1:a1:im&&im in Object(t)?n1(t):i1(t)}function s1(t){return t!=null&&typeof t=="object"}var c1="[object Symbol]";function pv(t){return typeof t=="symbol"||s1(t)&&fv(t)==c1}function u1(t,i){for(var o=-1,l=t==null?0:t.length,c=Array(l);++o<l;)c[o]=i(t[o],o,t);return c}var mv=Array.isArray,am=no?no.prototype:void 0,lm=am?am.toString:void 0;function vv(t){if(typeof t=="string")return t;if(mv(t))return u1(t,vv)+"";if(pv(t))return lm?lm.call(t):"";var i=t+"";return i=="0"&&1/t==-1/0?"-0":i}var d1=/\s/;function f1(t){for(var i=t.length;i--&&d1.test(t.charAt(i)););return i}var p1=/^\s+/;function m1(t){return t&&t.slice(0,f1(t)+1).replace(p1,"")}function fi(t){var i=typeof t;return t!=null&&(i=="object"||i=="function")}var sm=NaN,v1=/^[-+]0x[0-9a-f]+$/i,h1=/^0b[01]+$/i,g1=/^0o[0-7]+$/i,y1=parseInt;function cm(t){if(typeof t=="number")return t;if(pv(t))return sm;if(fi(t)){var i=typeof t.valueOf=="function"?t.valueOf():t;t=fi(i)?i+"":i}if(typeof t!="string")return t===0?t:+t;t=m1(t);var o=h1.test(t);return o||g1.test(t)?y1(t.slice(2),o?2:8):v1.test(t)?sm:+t}var _1="[object AsyncFunction]",b1="[object Function]",x1="[object GeneratorFunction]",k1="[object Proxy]";function rl(t){if(!fi(t))return!1;var i=fv(t);return i==b1||i==x1||i==_1||i==k1}var vc=nl["__core-js_shared__"],um=function(){var t=/[^.]+$/.exec(vc&&vc.keys&&vc.keys.IE_PROTO||"");return t?"Symbol(src)_1."+t:""}();function E1(t){return!!um&&um in t}var S1=Function.prototype,w1=S1.toString;function C1(t){if(t!=null){try{return w1.call(t)}catch{}try{return t+""}catch{}}return""}var T1=/[\\^$.*+?()[\]{}|]/g,O1=/^\[object .+?Constructor\]$/,A1=Function.prototype,N1=Object.prototype,L1=A1.toString,R1=N1.hasOwnProperty,P1=RegExp("^"+L1.call(R1).replace(T1,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$");function D1(t){if(!fi(t)||E1(t))return!1;var i=rl(t)?P1:O1;return i.test(C1(t))}function I1(t,i){return t==null?void 0:t[i]}function hv(t,i){var o=I1(t,i);return D1(o)?o:void 0}function Zr(){}function M1(t,i){return t===i||t!==t&&i!==i}var pi=hv(Object,"create");function B1(){this.__data__=pi?pi(null):{},this.size=0}function j1(t){var i=this.has(t)&&delete this.__data__[t];return this.size-=i?1:0,i}var $1="__lodash_hash_undefined__",z1=Object.prototype,F1=z1.hasOwnProperty;function X1(t){var i=this.__data__;if(pi){var o=i[t];return o===$1?void 0:o}return F1.call(i,t)?i[t]:void 0}var U1=Object.prototype,H1=U1.hasOwnProperty;function W1(t){var i=this.__data__;return pi?i[t]!==void 0:H1.call(i,t)}var V1="__lodash_hash_undefined__";function G1(t,i){var o=this.__data__;return this.size+=this.has(t)?0:1,o[t]=pi&&i===void 0?V1:i,this}function mr(t){var i=-1,o=t==null?0:t.length;for(this.clear();++i<o;){var l=t[i];this.set(l[0],l[1])}}mr.prototype.clear=B1;mr.prototype.delete=j1;mr.prototype.get=X1;mr.prototype.has=W1;mr.prototype.set=G1;function K1(){this.__data__=[],this.size=0}function ol(t,i){for(var o=t.length;o--;)if(M1(t[o][0],i))return o;return-1}var Y1=Array.prototype,q1=Y1.splice;function Q1(t){var i=this.__data__,o=ol(i,t);if(o<0)return!1;var l=i.length-1;return o==l?i.pop():q1.call(i,o,1),--this.size,!0}function Z1(t){var i=this.__data__,o=ol(i,t);return o<0?void 0:i[o][1]}function J1(t){return ol(this.__data__,t)>-1}function e_(t,i){var o=this.__data__,l=ol(o,t);return l<0?(++this.size,o.push([t,i])):o[l][1]=i,this}function so(t){var i=-1,o=t==null?0:t.length;for(this.clear();++i<o;){var l=t[i];this.set(l[0],l[1])}}so.prototype.clear=K1;so.prototype.delete=Q1;so.prototype.get=Z1;so.prototype.has=J1;so.prototype.set=e_;var t_=hv(nl,"Map");function n_(){this.size=0,this.__data__={hash:new mr,map:new(t_||so),string:new mr}}function r_(t){var i=typeof t;return i=="string"||i=="number"||i=="symbol"||i=="boolean"?t!=="__proto__":t===null}function il(t,i){var o=t.__data__;return r_(i)?o[typeof i=="string"?"string":"hash"]:o.map}function o_(t){var i=il(this,t).delete(t);return this.size-=i?1:0,i}function i_(t){return il(this,t).get(t)}function a_(t){return il(this,t).has(t)}function l_(t,i){var o=il(this,t),l=o.size;return o.set(t,i),this.size+=o.size==l?0:1,this}function gr(t){var i=-1,o=t==null?0:t.length;for(this.clear();++i<o;){var l=t[i];this.set(l[0],l[1])}}gr.prototype.clear=n_;gr.prototype.delete=o_;gr.prototype.get=i_;gr.prototype.has=a_;gr.prototype.set=l_;var s_="Expected a function";function Cu(t,i){if(typeof t!="function"||i!=null&&typeof i!="function")throw new TypeError(s_);var o=function(){var l=arguments,c=i?i.apply(this,l):l[0],d=o.cache;if(d.has(c))return d.get(c);var p=t.apply(this,l);return o.cache=d.set(c,p)||d,p};return o.cache=new(Cu.Cache||gr),o}Cu.Cache=gr;function al(t){return t==null?"":vv(t)}function c_(t,i,o){var l=-1,c=t.length;i<0&&(i=-i>c?0:c+i),o=o>c?c:o,o<0&&(o+=c),c=i>o?0:o-i>>>0,i>>>=0;for(var d=Array(c);++l<c;)d[l]=t[l+i];return d}function u_(t,i,o){var l=t.length;return o=o===void 0?l:o,c_(t,i,o)}var d_="\\ud800-\\udfff",f_="\\u0300-\\u036f",p_="\\ufe20-\\ufe2f",m_="\\u20d0-\\u20ff",v_=f_+p_+m_,h_="\\ufe0e\\ufe0f",g_="\\u200d",y_=RegExp("["+g_+d_+v_+h_+"]");function gv(t){return y_.test(t)}function __(t){return t.split("")}var yv="\\ud800-\\udfff",b_="\\u0300-\\u036f",x_="\\ufe20-\\ufe2f",k_="\\u20d0-\\u20ff",E_=b_+x_+k_,S_="\\ufe0e\\ufe0f",w_="["+yv+"]",Ac="["+E_+"]",Nc="\\ud83c[\\udffb-\\udfff]",C_="(?:"+Ac+"|"+Nc+")",_v="[^"+yv+"]",bv="(?:\\ud83c[\\udde6-\\uddff]){2}",xv="[\\ud800-\\udbff][\\udc00-\\udfff]",T_="\\u200d",kv=C_+"?",Ev="["+S_+"]?",O_="(?:"+T_+"(?:"+[_v,bv,xv].join("|")+")"+Ev+kv+")*",A_=Ev+kv+O_,N_="(?:"+[_v+Ac+"?",Ac,bv,xv,w_].join("|")+")",L_=RegExp(Nc+"(?="+Nc+")|"+N_+A_,"g");function R_(t){return t.match(L_)||[]}function P_(t){return gv(t)?R_(t):__(t)}function D_(t){return function(i){i=al(i);var o=gv(i)?P_(i):void 0,l=o?o[0]:i.charAt(0),c=o?u_(o,1).join(""):i.slice(1);return l[t]()+c}}var I_=D_("toUpperCase");function M_(t){return I_(al(t).toLowerCase())}function B_(t,i,o,l){for(var c=-1,d=t==null?0:t.length;++c<d;)o=i(o,t[c],c,t);return o}function j_(t){return function(i){return t==null?void 0:t[i]}}var $_={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},z_=j_($_),F_=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,X_="\\u0300-\\u036f",U_="\\ufe20-\\ufe2f",H_="\\u20d0-\\u20ff",W_=X_+U_+H_,V_="["+W_+"]",G_=RegExp(V_,"g");function K_(t){return t=al(t),t&&t.replace(F_,z_).replace(G_,"")}var Y_=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function q_(t){return t.match(Y_)||[]}var Q_=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function Z_(t){return Q_.test(t)}var Sv="\\ud800-\\udfff",J_="\\u0300-\\u036f",eb="\\ufe20-\\ufe2f",tb="\\u20d0-\\u20ff",nb=J_+eb+tb,wv="\\u2700-\\u27bf",Cv="a-z\\xdf-\\xf6\\xf8-\\xff",rb="\\xac\\xb1\\xd7\\xf7",ob="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",ib="\\u2000-\\u206f",ab=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",Tv="A-Z\\xc0-\\xd6\\xd8-\\xde",lb="\\ufe0e\\ufe0f",Ov=rb+ob+ib+ab,Av="['’]",dm="["+Ov+"]",sb="["+nb+"]",Nv="\\d+",cb="["+wv+"]",Lv="["+Cv+"]",Rv="[^"+Sv+Ov+Nv+wv+Cv+Tv+"]",ub="\\ud83c[\\udffb-\\udfff]",db="(?:"+sb+"|"+ub+")",fb="[^"+Sv+"]",Pv="(?:\\ud83c[\\udde6-\\uddff]){2}",Dv="[\\ud800-\\udbff][\\udc00-\\udfff]",Kr="["+Tv+"]",pb="\\u200d",fm="(?:"+Lv+"|"+Rv+")",mb="(?:"+Kr+"|"+Rv+")",pm="(?:"+Av+"(?:d|ll|m|re|s|t|ve))?",mm="(?:"+Av+"(?:D|LL|M|RE|S|T|VE))?",Iv=db+"?",Mv="["+lb+"]?",vb="(?:"+pb+"(?:"+[fb,Pv,Dv].join("|")+")"+Mv+Iv+")*",hb="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",gb="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",yb=Mv+Iv+vb,_b="(?:"+[cb,Pv,Dv].join("|")+")"+yb,bb=RegExp([Kr+"?"+Lv+"+"+pm+"(?="+[dm,Kr,"$"].join("|")+")",mb+"+"+mm+"(?="+[dm,Kr+fm,"$"].join("|")+")",Kr+"?"+fm+"+"+pm,Kr+"+"+mm,gb,hb,Nv,_b].join("|"),"g");function xb(t){return t.match(bb)||[]}function kb(t,i,o){return t=al(t),i=i,i===void 0?Z_(t)?xb(t):q_(t):t.match(i)||[]}var Eb="['’]",Sb=RegExp(Eb,"g");function wb(t){return function(i){return B_(kb(K_(i).replace(Sb,"")),t,"")}}var Qe=wb(function(t,i,o){return i=i.toLowerCase(),t+(o?M_(i):i)}),hc=function(){return nl.Date.now()},Cb="Expected a function",Tb=Math.max,Ob=Math.min;function Ab(t,i,o){var l,c,d,p,f,m,h=0,g=!1,y=!1,b=!0;if(typeof t!="function")throw new TypeError(Cb);i=cm(i)||0,fi(o)&&(g=!!o.leading,y="maxWait"in o,d=y?Tb(cm(o.maxWait)||0,i):d,b="trailing"in o?!!o.trailing:b);function w(j){var X=l,K=c;return l=c=void 0,h=j,p=t.apply(K,X),p}function N(j){return h=j,f=setTimeout(R,i),g?w(j):p}function L(j){var X=j-m,K=j-h,ce=i-X;return y?Ob(ce,d-K):ce}function O(j){var X=j-m,K=j-h;return m===void 0||X>=i||X<0||y&&K>=d}function R(){var j=hc();if(O(j))return M(j);f=setTimeout(R,L(j))}function M(j){return f=void 0,b&&l?w(j):(l=c=void 0,p)}function z(){f!==void 0&&clearTimeout(f),h=0,l=m=c=f=void 0}function I(){return f===void 0?p:M(hc())}function B(){var j=hc(),X=O(j);if(l=arguments,c=this,m=j,X){if(f===void 0)return N(m);if(y)return clearTimeout(f),f=setTimeout(R,i),w(m)}return f===void 0&&(f=setTimeout(R,i)),p}return B.cancel=z,B.flush=I,B}function Nb(t){return t==null}function Lb(t){var i=t.isClickable,o=t.isDecorationOnly,l=t.isKeyboardAccessible,c=t.label,d=Nb(o)?!i&&!c:o;return i||c?Pb({label:c,isDecorationOnly:d,isKeyboardAccessible:l,isHoverOnly:!i&&!!c}):{role:d?void 0:"img","aria-hidden":d,tabIndex:void 0,"aria-label":o?void 0:c}}function Rb(t){var i=t.isKeyboardAccessible,o=t.isDecorationOnly,l=t.isHoverOnly;return{role:l!==void 0&&l?"img":"button",tabIndex:i===void 0||i?0:-1,"aria-hidden":o!==void 0&&o}}function Pb(t){var i=t.label,o=t.isDecorationOnly,l=t.isKeyboardAccessible,c=t.isHoverOnly;return Object.assign(Object.assign({},Rb({isDecorationOnly:o!==void 0&&o,isKeyboardAccessible:l===void 0||l,isHoverOnly:c!==void 0&&c})),{"aria-label":i})}function Bv(t){var i=t.isClickable,o=t.label,l=t.isDecorationOnly;return k.useMemo(function(){return Lb({isClickable:i,label:o,isDecorationOnly:l})},[i,o,l])}var Db=function(){var t=k.useState(!1),i=Tt(t,2),o=i[0],l=i[1];return k.useEffect(function(){return l(!0),function(){l(!1)}},[]),o};function vm(t){return t.replace(/fill=".*?"/g,'fill="'.concat(arguments.length>1&&arguments[1]!==void 0?arguments[1]:"currentColor",'"'))}var Ib=function(t){var i=t.className,o=t.ref,l=t.src,c=t.onClick,d=t.replaceToCurrentColor,p=d!==void 0&&d,f=t.customColor,m=t.id,h=t["data-testid"],g=Bv({isClickable:t.clickable,label:t.ariaLabel,isDecorationOnly:t.ariaHidden}),y=Db(),b=k.useCallback(function(L){return p?vm(L,"currentColor"):f?vm(L,f):L},[p,f]);if(typeof l!="string")return null;var w=om.default||om,N=D.createElement("div",{className:i,id:m});return y?D.createElement(w,Object.assign({innerRef:o},g,{onClick:c,loader:N,src:l,className:i,preProcessor:b,id:m,"data-testid":h||De(Ze.SVG_ICON,m),"data-vibe":pr.ICON}),N):N},Mb=k.forwardRef(function(t,i){var o=t.id,l=t.onClick,c=t["aria-label"],d=t.tabIndex,p=t.icon,f=t.role,m=f===void 0?"img":f,h=t["data-testid"],g=typeof p=="function";return D.createElement("span",{"aria-hidden":t["aria-hidden"],className:ue(t.className,"fa",g?"":p),onClick:l,ref:i,"aria-label":c,tabIndex:d,role:m,id:o,"data-testid":h,"data-vibe":pr.ICON},g&&D.createElement(p,null))});function Ha(t){var i=t.eventName,o=t.callback,l=t.ref,c=t.capture,d=c!==void 0&&c;k.useEffect(function(){var p=l&&l.current;if(p){var f={capture:d};return p.addEventListener(i,o,f),function(){p.removeEventListener(i,o,f)}}},[i,l,o,d])}var Wa;(function(t){t.ALT="altKey",t.META="metaKey",t.CTRL="ctrlKey",t.SHIFT="shiftKey",t.CTRL_OR_META="ctrlOrMetaKey"})(Wa||(Wa={}));function ll(t){var i=t.keys,o=i===void 0?[]:i,l=t.callback,c=t.modifier,d=t.withoutAnyModifier,p=t.ref,f=t.ignoreDocumentFallback,m=f!==void 0&&f,h=t.capture,g=h!==void 0&&h,y=t.preventDefault,b=y!==void 0&&y,w=t.stopPropagation,N=w!==void 0&&w,L=t.keyEventName,O=L===void 0?"keydown":L,R=k.useRef(Jr()?document.body:null),M=k.useCallback(function(z){o.includes(z.key)&&(c&&!function(I,B){return B===Wa.CTRL_OR_META?I.ctrlKey||I.metaKey:I[B]}(z,c)||d&&!function(I){return!Object.values(ll.modifiers).some(function(B){if(B!=="ctrlOrMetaKey")return!!I[B]})}(z)||(b&&z.preventDefault(),N&&z.stopPropagation(),l(z)))},[o,c,d,b,N,l]);Ha({eventName:O,callback:M,ref:p||(m?null:R),capture:g})}ll.modifiers=Wa;var vr={ENTER:"Enter",SPACE:" ",ESCAPE:"Escape"},gc={icon:"icon_e634ab32bf",noFocusStyle:"noFocusStyle_b51f6a8a28",clickable:"clickable_a02d56f501"};(function(t){const i="s_id-039c30c54242_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.icon_e634ab32bf {
  position: relative;
}

.icon_e634ab32bf:before {
  text-decoration: none !important;
}

.noFocusStyle_b51f6a8a28:focus {
  outline: none;
}

.clickable_a02d56f501 {
  cursor: pointer;
}`);var Bb=[vr.ENTER,vr.SPACE];function jb(t){var i=t.onClick,o=t.className,l=t.clickable,c=t.ignoreFocusStyle,d=t.isDecorationOnly,p=t.iconLabel,f=t.externalTabIndex,m=k.useRef(null),h=k.useCallback(function(N){document.activeElement===m.current&&i(N)},[m,i]),g=k.useCallback(function(N){N.preventDefault()},[]),y=k.useMemo(function(){return ue(gc.icon,o,se(se({},gc.clickable,l),gc.noFocusStyle,c))},[l,o,c]);Ha({eventName:"mousedown",callback:g,ref:m}),ll({keys:Bb,ref:m,callback:h,ignoreDocumentFallback:!0,capture:!0,stopPropagation:!0,preventDefault:!0});var b=k.useCallback(function(N){(i||Zr)(N)},[i]),w=Bv({isClickable:l,label:p,isDecorationOnly:d});return w.tabIndex=f??w.tabIndex,{screenReaderAccessProps:w,onClickCallback:b,computedClassName:y,onEnterCallback:h,iconRef:m}}var zt=function(t,i){return Object.assign(t,i)},jv=function(t,i){return Object.assign(t,i)},Qt=zt(k.forwardRef(function(t,i){var o=t.id,l=t.icon,c=l===void 0?"":l,d=t.iconType,p=d===void 0?"svg":d,f=t.iconSize,m=f===void 0?16:f,h=t.ignoreFocusStyle,g=t.tabindex,y=t.style,b=t.useCurrentColor,w=b!==void 0&&b,N=t.customColor,L=t["data-testid"],O=jb({iconLabel:t.iconLabel,className:t.className,isDecorationOnly:t.ariaHidden,ignoreFocusStyle:h!==void 0&&h,externalTabIndex:g&&+g}),R=O.screenReaderAccessProps,M=O.onClickCallback,z=O.computedClassName,I=$t(i,O.iconRef);if(!c)return null;var B=typeof c=="function",j=L||De(pn.ICON,o);return p==="svg"||B||fr(c)==="object"?function(X,K){return D.createElement(X,Object.assign({},K,{"data-testid":K["data-testid"]||De(pn.ICON,K.id),"data-vibe":pr.ICON}))}(c,Object.assign(Object.assign({id:o},R),{ref:B?void 0:I,size:""+m,className:z,style:y,"data-testid":j})):p==="src"?D.createElement(Ib,Object.assign({id:o,src:c},R,{className:ue(z),onClick:M,replaceToCurrentColor:w,customColor:N,"data-testid":j})):D.createElement(Mb,Object.assign({id:o},R,{className:ue(z),onClick:M,ref:I,icon:c,"data-testid":j}))}),{type:Oc});function co(t,i){var o={};for(var l in t)Object.prototype.hasOwnProperty.call(t,l)&&0>i.indexOf(l)&&(o[l]=t[l]);if(t!=null&&typeof Object.getOwnPropertySymbols=="function"){var c=0;for(l=Object.getOwnPropertySymbols(t);l.length>c;c++)0>i.indexOf(l[c])&&Object.prototype.propertyIsEnumerable.call(t,l[c])&&(o[l[c]]=t[l[c]])}return o}function Xe(t,i){return i&&t[i]?t[i]:""}var Va,Ga;(function(t){t.TEXT1="text1",t.TEXT2="text2",t.TEXT3="text3"})(Va||(Va={})),function(t){t.BOLD="bold",t.MEDIUM="medium",t.NORMAL="normal"}(Ga||(Ga={}));function $b(t){var i=t.ref,o=t.callback,l=t.debounceTime,c=l===void 0?200:l,d=k.useCallback(Ab(o,c),[o,c]);k.useEffect(function(){if(window.ResizeObserver&&(i!=null&&i.current)){var p=null,f=new ResizeObserver(function(h){var g,y=h[0];if(y&&y.borderBoxSize)Array.isArray(y.borderBoxSize)?p=m(y.borderBoxSize[0]):p=m(y.borderBoxSize);else{if(!y.contentRect)return;var b={blockSize:y.contentRect.height,inlineSize:((g=y==null?void 0:y.contentRect)===null||g===void 0?void 0:g.width)||0};p=m(b)}});return f.observe(i==null?void 0:i.current),function(){c!==0&&d.cancel(),p&&window.cancelAnimationFrame(p),f.disconnect()}}function m(h){var g=Array.isArray(h)?h[0]:h;return window.requestAnimationFrame(function(){d({borderBoxSize:g})})}},[i==null?void 0:i.current,o,c,d])}function hm(t,i){return!!t&&(t.scrollWidth>t.clientWidth+(arguments.length>3&&arguments[3]!==void 0?arguments[3]:0)||!i&&t.scrollHeight>t.clientHeight+(arguments.length>2&&arguments[2]!==void 0?arguments[2]:0))}function $v(t){var i=t.ref,o=t.ignoreHeightOverflow,l=o!==void 0&&o,c=t.tolerance,d=t.widthTolerance,p=k.useState(function(){return hm(i==null?void 0:i.current,l,c,d)}),f=Tt(p,2),m=f[0],h=f[1],g=k.useCallback(function(){var y=i==null?void 0:i.current;if(y){var b=hm(y,l,c,d);h(function(w){return w!==b?b:w})}},[l,i,c,d]);return $b({ref:i,callback:g,debounceTime:0}),m}var ci={typography:"typography_2a1e03a281","focus-visible":"focus-visible_b0a5cd5036",primary:"primary_db5589817c",secondary:"secondary_7bf2726c24",negative:"negative_de113c8c75",onPrimary:"onPrimary_e3d5c4d9dc",onInverted:"onInverted_b227ee6f36",fixedLight:"fixedLight_50d6e9de8b",fixedDark:"fixedDark_f8eaa9a0c2",inherit:"inherit_36db1551f9",alignInherit:"alignInherit_1f2c91ec30",start:"start_e8bcf9f212",center:"center_12712165ac",end:"end_aad034f0a1",singleLineEllipsis:"singleLineEllipsis_260bce7ad5",multiLineEllipsis:"multiLineEllipsis_8c5a11c071"};(function(t){const i="s_id-1a3a21ac499a_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.typography_2a1e03a281 > a {
  text-decoration: none;
  color: var(--link-color);
}
.typography_2a1e03a281 > a:focus-visible, .typography_2a1e03a281 > a.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px hsla(209, 100%, 50%, 0.5), 0 0 0 1px var(--primary-hover-color) inset;
}
.typography_2a1e03a281 > a:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.typography_2a1e03a281 > a:hover {
  text-decoration: underline;
}
.typography_2a1e03a281:disabled, .typography_2a1e03a281[aria-disabled=true] {
  color: var(--disabled-text-color);
}
.primary_db5589817c {
  color: var(--primary-text-color);
}
.secondary_7bf2726c24 {
  color: var(--secondary-text-color);
}
.negative_de113c8c75 {
  color: var(--color-error);
}
.onPrimary_e3d5c4d9dc {
  color: var(--text-color-on-primary);
}
.onPrimary_e3d5c4d9dc a {
  color: var(--text-color-on-primary);
  text-decoration: underline;
}
.onInverted_b227ee6f36 {
  color: var(--text-color-on-inverted);
}
.onInverted_b227ee6f36 a {
  color: var(--text-color-on-inverted);
  text-decoration: underline;
}
.fixedLight_50d6e9de8b {
  color: var(--fixed-light-color);
}
.fixedLight_50d6e9de8b a {
  color: var(--fixed-light-color);
  text-decoration: underline;
}
.fixedDark_f8eaa9a0c2 {
  color: var(--fixed-dark-color);
}
.fixedDark_f8eaa9a0c2 a {
  color: var(--fixed-dark-color);
  text-decoration: underline;
}
.inherit_36db1551f9 {
  color: inherit;
}
.inherit_36db1551f9 a {
  color: inherit;
  text-decoration: underline;
}
.alignInherit_1f2c91ec30 {
  text-align: inherit;
}
.start_e8bcf9f212 {
  text-align: start;
}
.center_12712165ac {
  text-align: center;
}
.end_aad034f0a1 {
  text-align: end;
}
.singleLineEllipsis_260bce7ad5 {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.multiLineEllipsis_8c5a11c071 {
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: var(--text-clamp-lines);
  -webkit-box-orient: vertical;
  white-space: initial;
}`);function zb(t){var i=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1;return k.useMemo(function(){var o,l;return t&&(o=i>1?ci.multiLineEllipsis:ci.singleLineEllipsis,i>1&&(l={"--text-clamp-lines":""+i})),{class:o,style:l}},[t,i])}function Fb(t,i,o,l,c,d,p){var f=$v({ref:o?t:null,ignoreHeightOverflow:d,tolerance:p});return!i&&o&&f?Object.assign(Object.assign({},l),{content:c}):{}}var Tu=Ym();const Na=lo(Tu);var zv=k.createContext(),Fv=k.createContext();function Xb(t){var i=t.children,o=k.useState(null),l=o[0],c=o[1],d=k.useRef(!1);k.useEffect(function(){return function(){d.current=!0}},[]);var p=k.useCallback(function(f){d.current||c(f)},[]);return k.createElement(zv.Provider,{value:l},k.createElement(Fv.Provider,{value:p},i))}var Xv=function(i){return Array.isArray(i)?i[0]:i},Uv=function(i){if(typeof i=="function"){for(var o=arguments.length,l=new Array(o>1?o-1:0),c=1;c<o;c++)l[c-1]=arguments[c];return i.apply(void 0,l)}},Lc=function(i,o){if(typeof i=="function")return Uv(i,o);i!=null&&(i.current=o)},gm=function(i){return i.reduce(function(o,l){var c=l[0],d=l[1];return o[c]=d,o},{})},ym=typeof window<"u"&&window.document&&window.document.createElement?k.useLayoutEffect:k.useEffect,pt="top",At="bottom",Nt="right",mt="left",Ou="auto",yi=[pt,At,Nt,mt],ro="start",mi="end",Ub="clippingParents",Hv="viewport",ti="popper",Hb="reference",_m=yi.reduce(function(t,i){return t.concat([i+"-"+ro,i+"-"+mi])},[]),Wv=[].concat(yi,[Ou]).reduce(function(t,i){return t.concat([i,i+"-"+ro,i+"-"+mi])},[]),Wb="beforeRead",Vb="read",Gb="afterRead",Kb="beforeMain",Yb="main",qb="afterMain",Qb="beforeWrite",Zb="write",Jb="afterWrite",ex=[Wb,Vb,Gb,Kb,Yb,qb,Qb,Zb,Jb];function Jt(t){return t?(t.nodeName||"").toLowerCase():null}function bt(t){if(t==null)return window;if(t.toString()!=="[object Window]"){var i=t.ownerDocument;return i&&i.defaultView||window}return t}function hr(t){var i=bt(t).Element;return t instanceof i||t instanceof Element}function Ot(t){var i=bt(t).HTMLElement;return t instanceof i||t instanceof HTMLElement}function Au(t){if(typeof ShadowRoot>"u")return!1;var i=bt(t).ShadowRoot;return t instanceof i||t instanceof ShadowRoot}function tx(t){var i=t.state;Object.keys(i.elements).forEach(function(o){var l=i.styles[o]||{},c=i.attributes[o]||{},d=i.elements[o];!Ot(d)||!Jt(d)||(Object.assign(d.style,l),Object.keys(c).forEach(function(p){var f=c[p];f===!1?d.removeAttribute(p):d.setAttribute(p,f===!0?"":f)}))})}function nx(t){var i=t.state,o={popper:{position:i.options.strategy,left:"0",top:"0",margin:"0"},arrow:{position:"absolute"},reference:{}};return Object.assign(i.elements.popper.style,o.popper),i.styles=o,i.elements.arrow&&Object.assign(i.elements.arrow.style,o.arrow),function(){Object.keys(i.elements).forEach(function(l){var c=i.elements[l],d=i.attributes[l]||{},p=Object.keys(i.styles.hasOwnProperty(l)?i.styles[l]:o[l]),f=p.reduce(function(m,h){return m[h]="",m},{});!Ot(c)||!Jt(c)||(Object.assign(c.style,f),Object.keys(d).forEach(function(m){c.removeAttribute(m)}))})}}const rx={name:"applyStyles",enabled:!0,phase:"write",fn:tx,effect:nx,requires:["computeStyles"]};function Zt(t){return t.split("-")[0]}var cr=Math.max,Ka=Math.min,oo=Math.round;function Rc(){var t=navigator.userAgentData;return t!=null&&t.brands&&Array.isArray(t.brands)?t.brands.map(function(i){return i.brand+"/"+i.version}).join(" "):navigator.userAgent}function Vv(){return!/^((?!chrome|android).)*safari/i.test(Rc())}function io(t,i,o){i===void 0&&(i=!1),o===void 0&&(o=!1);var l=t.getBoundingClientRect(),c=1,d=1;i&&Ot(t)&&(c=t.offsetWidth>0&&oo(l.width)/t.offsetWidth||1,d=t.offsetHeight>0&&oo(l.height)/t.offsetHeight||1);var p=hr(t)?bt(t):window,f=p.visualViewport,m=!Vv()&&o,h=(l.left+(m&&f?f.offsetLeft:0))/c,g=(l.top+(m&&f?f.offsetTop:0))/d,y=l.width/c,b=l.height/d;return{width:y,height:b,top:g,right:h+y,bottom:g+b,left:h,x:h,y:g}}function Nu(t){var i=io(t),o=t.offsetWidth,l=t.offsetHeight;return Math.abs(i.width-o)<=1&&(o=i.width),Math.abs(i.height-l)<=1&&(l=i.height),{x:t.offsetLeft,y:t.offsetTop,width:o,height:l}}function Gv(t,i){var o=i.getRootNode&&i.getRootNode();if(t.contains(i))return!0;if(o&&Au(o)){var l=i;do{if(l&&t.isSameNode(l))return!0;l=l.parentNode||l.host}while(l)}return!1}function mn(t){return bt(t).getComputedStyle(t)}function ox(t){return["table","td","th"].indexOf(Jt(t))>=0}function Un(t){return((hr(t)?t.ownerDocument:t.document)||window.document).documentElement}function sl(t){return Jt(t)==="html"?t:t.assignedSlot||t.parentNode||(Au(t)?t.host:null)||Un(t)}function bm(t){return!Ot(t)||mn(t).position==="fixed"?null:t.offsetParent}function ix(t){var i=/firefox/i.test(Rc()),o=/Trident/i.test(Rc());if(o&&Ot(t)){var l=mn(t);if(l.position==="fixed")return null}var c=sl(t);for(Au(c)&&(c=c.host);Ot(c)&&["html","body"].indexOf(Jt(c))<0;){var d=mn(c);if(d.transform!=="none"||d.perspective!=="none"||d.contain==="paint"||["transform","perspective"].indexOf(d.willChange)!==-1||i&&d.willChange==="filter"||i&&d.filter&&d.filter!=="none")return c;c=c.parentNode}return null}function _i(t){for(var i=bt(t),o=bm(t);o&&ox(o)&&mn(o).position==="static";)o=bm(o);return o&&(Jt(o)==="html"||Jt(o)==="body"&&mn(o).position==="static")?i:o||ix(t)||i}function Lu(t){return["top","bottom"].indexOf(t)>=0?"x":"y"}function ui(t,i,o){return cr(t,Ka(i,o))}function ax(t,i,o){var l=ui(t,i,o);return l>o?o:l}function Kv(){return{top:0,right:0,bottom:0,left:0}}function Yv(t){return Object.assign({},Kv(),t)}function qv(t,i){return i.reduce(function(o,l){return o[l]=t,o},{})}var lx=function(i,o){return i=typeof i=="function"?i(Object.assign({},o.rects,{placement:o.placement})):i,Yv(typeof i!="number"?i:qv(i,yi))};function sx(t){var i,o=t.state,l=t.name,c=t.options,d=o.elements.arrow,p=o.modifiersData.popperOffsets,f=Zt(o.placement),m=Lu(f),h=[mt,Nt].indexOf(f)>=0,g=h?"height":"width";if(!(!d||!p)){var y=lx(c.padding,o),b=Nu(d),w=m==="y"?pt:mt,N=m==="y"?At:Nt,L=o.rects.reference[g]+o.rects.reference[m]-p[m]-o.rects.popper[g],O=p[m]-o.rects.reference[m],R=_i(d),M=R?m==="y"?R.clientHeight||0:R.clientWidth||0:0,z=L/2-O/2,I=y[w],B=M-b[g]-y[N],j=M/2-b[g]/2+z,X=ui(I,j,B),K=m;o.modifiersData[l]=(i={},i[K]=X,i.centerOffset=X-j,i)}}function cx(t){var i=t.state,o=t.options,l=o.element,c=l===void 0?"[data-popper-arrow]":l;c!=null&&(typeof c=="string"&&(c=i.elements.popper.querySelector(c),!c)||Gv(i.elements.popper,c)&&(i.elements.arrow=c))}const ux={name:"arrow",enabled:!0,phase:"main",fn:sx,effect:cx,requires:["popperOffsets"],requiresIfExists:["preventOverflow"]};function ao(t){return t.split("-")[1]}var dx={top:"auto",right:"auto",bottom:"auto",left:"auto"};function fx(t,i){var o=t.x,l=t.y,c=i.devicePixelRatio||1;return{x:oo(o*c)/c||0,y:oo(l*c)/c||0}}function xm(t){var i,o=t.popper,l=t.popperRect,c=t.placement,d=t.variation,p=t.offsets,f=t.position,m=t.gpuAcceleration,h=t.adaptive,g=t.roundOffsets,y=t.isFixed,b=p.x,w=b===void 0?0:b,N=p.y,L=N===void 0?0:N,O=typeof g=="function"?g({x:w,y:L}):{x:w,y:L};w=O.x,L=O.y;var R=p.hasOwnProperty("x"),M=p.hasOwnProperty("y"),z=mt,I=pt,B=window;if(h){var j=_i(o),X="clientHeight",K="clientWidth";if(j===bt(o)&&(j=Un(o),mn(j).position!=="static"&&f==="absolute"&&(X="scrollHeight",K="scrollWidth")),j=j,c===pt||(c===mt||c===Nt)&&d===mi){I=At;var ce=y&&j===B&&B.visualViewport?B.visualViewport.height:j[X];L-=ce-l.height,L*=m?1:-1}if(c===mt||(c===pt||c===At)&&d===mi){z=Nt;var Q=y&&j===B&&B.visualViewport?B.visualViewport.width:j[K];w-=Q-l.width,w*=m?1:-1}}var Z=Object.assign({position:f},h&&dx),le=g===!0?fx({x:w,y:L},bt(o)):{x:w,y:L};if(w=le.x,L=le.y,m){var de;return Object.assign({},Z,(de={},de[I]=M?"0":"",de[z]=R?"0":"",de.transform=(B.devicePixelRatio||1)<=1?"translate("+w+"px, "+L+"px)":"translate3d("+w+"px, "+L+"px, 0)",de))}return Object.assign({},Z,(i={},i[I]=M?L+"px":"",i[z]=R?w+"px":"",i.transform="",i))}function px(t){var i=t.state,o=t.options,l=o.gpuAcceleration,c=l===void 0?!0:l,d=o.adaptive,p=d===void 0?!0:d,f=o.roundOffsets,m=f===void 0?!0:f,h={placement:Zt(i.placement),variation:ao(i.placement),popper:i.elements.popper,popperRect:i.rects.popper,gpuAcceleration:c,isFixed:i.options.strategy==="fixed"};i.modifiersData.popperOffsets!=null&&(i.styles.popper=Object.assign({},i.styles.popper,xm(Object.assign({},h,{offsets:i.modifiersData.popperOffsets,position:i.options.strategy,adaptive:p,roundOffsets:m})))),i.modifiersData.arrow!=null&&(i.styles.arrow=Object.assign({},i.styles.arrow,xm(Object.assign({},h,{offsets:i.modifiersData.arrow,position:"absolute",adaptive:!1,roundOffsets:m})))),i.attributes.popper=Object.assign({},i.attributes.popper,{"data-popper-placement":i.placement})}const mx={name:"computeStyles",enabled:!0,phase:"beforeWrite",fn:px,data:{}};var La={passive:!0};function vx(t){var i=t.state,o=t.instance,l=t.options,c=l.scroll,d=c===void 0?!0:c,p=l.resize,f=p===void 0?!0:p,m=bt(i.elements.popper),h=[].concat(i.scrollParents.reference,i.scrollParents.popper);return d&&h.forEach(function(g){g.addEventListener("scroll",o.update,La)}),f&&m.addEventListener("resize",o.update,La),function(){d&&h.forEach(function(g){g.removeEventListener("scroll",o.update,La)}),f&&m.removeEventListener("resize",o.update,La)}}const hx={name:"eventListeners",enabled:!0,phase:"write",fn:function(){},effect:vx,data:{}};var gx={left:"right",right:"left",bottom:"top",top:"bottom"};function za(t){return t.replace(/left|right|bottom|top/g,function(i){return gx[i]})}var yx={start:"end",end:"start"};function km(t){return t.replace(/start|end/g,function(i){return yx[i]})}function Ru(t){var i=bt(t),o=i.pageXOffset,l=i.pageYOffset;return{scrollLeft:o,scrollTop:l}}function Pu(t){return io(Un(t)).left+Ru(t).scrollLeft}function _x(t,i){var o=bt(t),l=Un(t),c=o.visualViewport,d=l.clientWidth,p=l.clientHeight,f=0,m=0;if(c){d=c.width,p=c.height;var h=Vv();(h||!h&&i==="fixed")&&(f=c.offsetLeft,m=c.offsetTop)}return{width:d,height:p,x:f+Pu(t),y:m}}function bx(t){var i,o=Un(t),l=Ru(t),c=(i=t.ownerDocument)==null?void 0:i.body,d=cr(o.scrollWidth,o.clientWidth,c?c.scrollWidth:0,c?c.clientWidth:0),p=cr(o.scrollHeight,o.clientHeight,c?c.scrollHeight:0,c?c.clientHeight:0),f=-l.scrollLeft+Pu(t),m=-l.scrollTop;return mn(c||o).direction==="rtl"&&(f+=cr(o.clientWidth,c?c.clientWidth:0)-d),{width:d,height:p,x:f,y:m}}function Du(t){var i=mn(t),o=i.overflow,l=i.overflowX,c=i.overflowY;return/auto|scroll|overlay|hidden/.test(o+c+l)}function Qv(t){return["html","body","#document"].indexOf(Jt(t))>=0?t.ownerDocument.body:Ot(t)&&Du(t)?t:Qv(sl(t))}function di(t,i){var o;i===void 0&&(i=[]);var l=Qv(t),c=l===((o=t.ownerDocument)==null?void 0:o.body),d=bt(l),p=c?[d].concat(d.visualViewport||[],Du(l)?l:[]):l,f=i.concat(p);return c?f:f.concat(di(sl(p)))}function Pc(t){return Object.assign({},t,{left:t.x,top:t.y,right:t.x+t.width,bottom:t.y+t.height})}function xx(t,i){var o=io(t,!1,i==="fixed");return o.top=o.top+t.clientTop,o.left=o.left+t.clientLeft,o.bottom=o.top+t.clientHeight,o.right=o.left+t.clientWidth,o.width=t.clientWidth,o.height=t.clientHeight,o.x=o.left,o.y=o.top,o}function Em(t,i,o){return i===Hv?Pc(_x(t,o)):hr(i)?xx(i,o):Pc(bx(Un(t)))}function kx(t){var i=di(sl(t)),o=["absolute","fixed"].indexOf(mn(t).position)>=0,l=o&&Ot(t)?_i(t):t;return hr(l)?i.filter(function(c){return hr(c)&&Gv(c,l)&&Jt(c)!=="body"}):[]}function Ex(t,i,o,l){var c=i==="clippingParents"?kx(t):[].concat(i),d=[].concat(c,[o]),p=d[0],f=d.reduce(function(m,h){var g=Em(t,h,l);return m.top=cr(g.top,m.top),m.right=Ka(g.right,m.right),m.bottom=Ka(g.bottom,m.bottom),m.left=cr(g.left,m.left),m},Em(t,p,l));return f.width=f.right-f.left,f.height=f.bottom-f.top,f.x=f.left,f.y=f.top,f}function Zv(t){var i=t.reference,o=t.element,l=t.placement,c=l?Zt(l):null,d=l?ao(l):null,p=i.x+i.width/2-o.width/2,f=i.y+i.height/2-o.height/2,m;switch(c){case pt:m={x:p,y:i.y-o.height};break;case At:m={x:p,y:i.y+i.height};break;case Nt:m={x:i.x+i.width,y:f};break;case mt:m={x:i.x-o.width,y:f};break;default:m={x:i.x,y:i.y}}var h=c?Lu(c):null;if(h!=null){var g=h==="y"?"height":"width";switch(d){case ro:m[h]=m[h]-(i[g]/2-o[g]/2);break;case mi:m[h]=m[h]+(i[g]/2-o[g]/2);break}}return m}function vi(t,i){i===void 0&&(i={});var o=i,l=o.placement,c=l===void 0?t.placement:l,d=o.strategy,p=d===void 0?t.strategy:d,f=o.boundary,m=f===void 0?Ub:f,h=o.rootBoundary,g=h===void 0?Hv:h,y=o.elementContext,b=y===void 0?ti:y,w=o.altBoundary,N=w===void 0?!1:w,L=o.padding,O=L===void 0?0:L,R=Yv(typeof O!="number"?O:qv(O,yi)),M=b===ti?Hb:ti,z=t.rects.popper,I=t.elements[N?M:b],B=Ex(hr(I)?I:I.contextElement||Un(t.elements.popper),m,g,p),j=io(t.elements.reference),X=Zv({reference:j,element:z,placement:c}),K=Pc(Object.assign({},z,X)),ce=b===ti?K:j,Q={top:B.top-ce.top+R.top,bottom:ce.bottom-B.bottom+R.bottom,left:B.left-ce.left+R.left,right:ce.right-B.right+R.right},Z=t.modifiersData.offset;if(b===ti&&Z){var le=Z[c];Object.keys(Q).forEach(function(de){var oe=[Nt,At].indexOf(de)>=0?1:-1,ve=[pt,At].indexOf(de)>=0?"y":"x";Q[de]+=le[ve]*oe})}return Q}function Sx(t,i){i===void 0&&(i={});var o=i,l=o.placement,c=o.boundary,d=o.rootBoundary,p=o.padding,f=o.flipVariations,m=o.allowedAutoPlacements,h=m===void 0?Wv:m,g=ao(l),y=g?f?_m:_m.filter(function(N){return ao(N)===g}):yi,b=y.filter(function(N){return h.indexOf(N)>=0});b.length===0&&(b=y);var w=b.reduce(function(N,L){return N[L]=vi(t,{placement:L,boundary:c,rootBoundary:d,padding:p})[Zt(L)],N},{});return Object.keys(w).sort(function(N,L){return w[N]-w[L]})}function wx(t){if(Zt(t)===Ou)return[];var i=za(t);return[km(t),i,km(i)]}function Cx(t){var i=t.state,o=t.options,l=t.name;if(!i.modifiersData[l]._skip){for(var c=o.mainAxis,d=c===void 0?!0:c,p=o.altAxis,f=p===void 0?!0:p,m=o.fallbackPlacements,h=o.padding,g=o.boundary,y=o.rootBoundary,b=o.altBoundary,w=o.flipVariations,N=w===void 0?!0:w,L=o.allowedAutoPlacements,O=i.options.placement,R=Zt(O),M=R===O,z=m||(M||!N?[za(O)]:wx(O)),I=[O].concat(z).reduce(function(ie,ye){return ie.concat(Zt(ye)===Ou?Sx(i,{placement:ye,boundary:g,rootBoundary:y,padding:h,flipVariations:N,allowedAutoPlacements:L}):ye)},[]),B=i.rects.reference,j=i.rects.popper,X=new Map,K=!0,ce=I[0],Q=0;Q<I.length;Q++){var Z=I[Q],le=Zt(Z),de=ao(Z)===ro,oe=[pt,At].indexOf(le)>=0,ve=oe?"width":"height",re=vi(i,{placement:Z,boundary:g,rootBoundary:y,altBoundary:b,padding:h}),fe=oe?de?Nt:mt:de?At:pt;B[ve]>j[ve]&&(fe=za(fe));var H=za(fe),V=[];if(d&&V.push(re[le]<=0),f&&V.push(re[fe]<=0,re[H]<=0),V.every(function(ie){return ie})){ce=Z,K=!1;break}X.set(Z,V)}if(K)for(var x=N?3:1,P=function(ye){var _e=I.find(function(be){var Y=X.get(be);if(Y)return Y.slice(0,ye).every(function(Se){return Se})});if(_e)return ce=_e,"break"},G=x;G>0;G--){var te=P(G);if(te==="break")break}i.placement!==ce&&(i.modifiersData[l]._skip=!0,i.placement=ce,i.reset=!0)}}const Tx={name:"flip",enabled:!0,phase:"main",fn:Cx,requiresIfExists:["offset"],data:{_skip:!1}};function Sm(t,i,o){return o===void 0&&(o={x:0,y:0}),{top:t.top-i.height-o.y,right:t.right-i.width+o.x,bottom:t.bottom-i.height+o.y,left:t.left-i.width-o.x}}function wm(t){return[pt,Nt,At,mt].some(function(i){return t[i]>=0})}function Ox(t){var i=t.state,o=t.name,l=i.rects.reference,c=i.rects.popper,d=i.modifiersData.preventOverflow,p=vi(i,{elementContext:"reference"}),f=vi(i,{altBoundary:!0}),m=Sm(p,l),h=Sm(f,c,d),g=wm(m),y=wm(h);i.modifiersData[o]={referenceClippingOffsets:m,popperEscapeOffsets:h,isReferenceHidden:g,hasPopperEscaped:y},i.attributes.popper=Object.assign({},i.attributes.popper,{"data-popper-reference-hidden":g,"data-popper-escaped":y})}const Ax={name:"hide",enabled:!0,phase:"main",requiresIfExists:["preventOverflow"],fn:Ox};function Nx(t,i,o){var l=Zt(t),c=[mt,pt].indexOf(l)>=0?-1:1,d=typeof o=="function"?o(Object.assign({},i,{placement:t})):o,p=d[0],f=d[1];return p=p||0,f=(f||0)*c,[mt,Nt].indexOf(l)>=0?{x:f,y:p}:{x:p,y:f}}function Lx(t){var i=t.state,o=t.options,l=t.name,c=o.offset,d=c===void 0?[0,0]:c,p=Wv.reduce(function(g,y){return g[y]=Nx(y,i.rects,d),g},{}),f=p[i.placement],m=f.x,h=f.y;i.modifiersData.popperOffsets!=null&&(i.modifiersData.popperOffsets.x+=m,i.modifiersData.popperOffsets.y+=h),i.modifiersData[l]=p}const Rx={name:"offset",enabled:!0,phase:"main",requires:["popperOffsets"],fn:Lx};function Px(t){var i=t.state,o=t.name;i.modifiersData[o]=Zv({reference:i.rects.reference,element:i.rects.popper,placement:i.placement})}const Dx={name:"popperOffsets",enabled:!0,phase:"read",fn:Px,data:{}};function Ix(t){return t==="x"?"y":"x"}function Mx(t){var i=t.state,o=t.options,l=t.name,c=o.mainAxis,d=c===void 0?!0:c,p=o.altAxis,f=p===void 0?!1:p,m=o.boundary,h=o.rootBoundary,g=o.altBoundary,y=o.padding,b=o.tether,w=b===void 0?!0:b,N=o.tetherOffset,L=N===void 0?0:N,O=vi(i,{boundary:m,rootBoundary:h,padding:y,altBoundary:g}),R=Zt(i.placement),M=ao(i.placement),z=!M,I=Lu(R),B=Ix(I),j=i.modifiersData.popperOffsets,X=i.rects.reference,K=i.rects.popper,ce=typeof L=="function"?L(Object.assign({},i.rects,{placement:i.placement})):L,Q=typeof ce=="number"?{mainAxis:ce,altAxis:ce}:Object.assign({mainAxis:0,altAxis:0},ce),Z=i.modifiersData.offset?i.modifiersData.offset[i.placement]:null,le={x:0,y:0};if(j){if(d){var de,oe=I==="y"?pt:mt,ve=I==="y"?At:Nt,re=I==="y"?"height":"width",fe=j[I],H=fe+O[oe],V=fe-O[ve],x=w?-K[re]/2:0,P=M===ro?X[re]:K[re],G=M===ro?-K[re]:-X[re],te=i.elements.arrow,ie=w&&te?Nu(te):{width:0,height:0},ye=i.modifiersData["arrow#persistent"]?i.modifiersData["arrow#persistent"].padding:Kv(),_e=ye[oe],be=ye[ve],Y=ui(0,X[re],ie[re]),Se=z?X[re]/2-x-Y-_e-Q.mainAxis:P-Y-_e-Q.mainAxis,Ne=z?-X[re]/2+x+Y+be+Q.mainAxis:G+Y+be+Q.mainAxis,Ue=i.elements.arrow&&_i(i.elements.arrow),Ft=Ue?I==="y"?Ue.clientTop||0:Ue.clientLeft||0:0,vt=(de=Z==null?void 0:Z[I])!=null?de:0,hn=fe+Se-vt-Ft,gn=fe+Ne-vt,Xt=ui(w?Ka(H,hn):H,fe,w?cr(V,gn):V);j[I]=Xt,le[I]=Xt-fe}if(f){var Ut,yn=I==="x"?pt:mt,Ie=I==="x"?At:Nt,Je=j[B],Lt=B==="y"?"height":"width",yr=Je+O[yn],fo=Je-O[Ie],_r=[pt,mt].indexOf(R)!==-1,po=(Ut=Z==null?void 0:Z[B])!=null?Ut:0,mo=_r?yr:Je-X[Lt]-K[Lt]-po+Q.altAxis,br=_r?Je+X[Lt]+K[Lt]-po-Q.altAxis:fo,Hn=w&&_r?ax(mo,Je,br):ui(w?mo:yr,Je,w?br:fo);j[B]=Hn,le[B]=Hn-Je}i.modifiersData[l]=le}}const Bx={name:"preventOverflow",enabled:!0,phase:"main",fn:Mx,requiresIfExists:["offset"]};function jx(t){return{scrollLeft:t.scrollLeft,scrollTop:t.scrollTop}}function $x(t){return t===bt(t)||!Ot(t)?Ru(t):jx(t)}function zx(t){var i=t.getBoundingClientRect(),o=oo(i.width)/t.offsetWidth||1,l=oo(i.height)/t.offsetHeight||1;return o!==1||l!==1}function Fx(t,i,o){o===void 0&&(o=!1);var l=Ot(i),c=Ot(i)&&zx(i),d=Un(i),p=io(t,c,o),f={scrollLeft:0,scrollTop:0},m={x:0,y:0};return(l||!l&&!o)&&((Jt(i)!=="body"||Du(d))&&(f=$x(i)),Ot(i)?(m=io(i,!0),m.x+=i.clientLeft,m.y+=i.clientTop):d&&(m.x=Pu(d))),{x:p.left+f.scrollLeft-m.x,y:p.top+f.scrollTop-m.y,width:p.width,height:p.height}}function Xx(t){var i=new Map,o=new Set,l=[];t.forEach(function(d){i.set(d.name,d)});function c(d){o.add(d.name);var p=[].concat(d.requires||[],d.requiresIfExists||[]);p.forEach(function(f){if(!o.has(f)){var m=i.get(f);m&&c(m)}}),l.push(d)}return t.forEach(function(d){o.has(d.name)||c(d)}),l}function Ux(t){var i=Xx(t);return ex.reduce(function(o,l){return o.concat(i.filter(function(c){return c.phase===l}))},[])}function Hx(t){var i;return function(){return i||(i=new Promise(function(o){Promise.resolve().then(function(){i=void 0,o(t())})})),i}}function Wx(t){var i=t.reduce(function(o,l){var c=o[l.name];return o[l.name]=c?Object.assign({},c,l,{options:Object.assign({},c.options,l.options),data:Object.assign({},c.data,l.data)}):l,o},{});return Object.keys(i).map(function(o){return i[o]})}var Cm={placement:"bottom",modifiers:[],strategy:"absolute"};function Tm(){for(var t=arguments.length,i=new Array(t),o=0;o<t;o++)i[o]=arguments[o];return!i.some(function(l){return!(l&&typeof l.getBoundingClientRect=="function")})}function Vx(t){t===void 0&&(t={});var i=t,o=i.defaultModifiers,l=o===void 0?[]:o,c=i.defaultOptions,d=c===void 0?Cm:c;return function(f,m,h){h===void 0&&(h=d);var g={placement:"bottom",orderedModifiers:[],options:Object.assign({},Cm,d),modifiersData:{},elements:{reference:f,popper:m},attributes:{},styles:{}},y=[],b=!1,w={state:g,setOptions:function(R){var M=typeof R=="function"?R(g.options):R;L(),g.options=Object.assign({},d,g.options,M),g.scrollParents={reference:hr(f)?di(f):f.contextElement?di(f.contextElement):[],popper:di(m)};var z=Ux(Wx([].concat(l,g.options.modifiers)));return g.orderedModifiers=z.filter(function(I){return I.enabled}),N(),w.update()},forceUpdate:function(){if(!b){var R=g.elements,M=R.reference,z=R.popper;if(Tm(M,z)){g.rects={reference:Fx(M,_i(z),g.options.strategy==="fixed"),popper:Nu(z)},g.reset=!1,g.placement=g.options.placement,g.orderedModifiers.forEach(function(Q){return g.modifiersData[Q.name]=Object.assign({},Q.data)});for(var I=0;I<g.orderedModifiers.length;I++){if(g.reset===!0){g.reset=!1,I=-1;continue}var B=g.orderedModifiers[I],j=B.fn,X=B.options,K=X===void 0?{}:X,ce=B.name;typeof j=="function"&&(g=j({state:g,options:K,name:ce,instance:w})||g)}}}},update:Hx(function(){return new Promise(function(O){w.forceUpdate(),O(g)})}),destroy:function(){L(),b=!0}};if(!Tm(f,m))return w;w.setOptions(h).then(function(O){!b&&h.onFirstUpdate&&h.onFirstUpdate(O)});function N(){g.orderedModifiers.forEach(function(O){var R=O.name,M=O.options,z=M===void 0?{}:M,I=O.effect;if(typeof I=="function"){var B=I({state:g,name:R,instance:w,options:z}),j=function(){};y.push(B||j)}})}function L(){y.forEach(function(O){return O()}),y=[]}return w}}var Gx=[hx,Dx,mx,rx,Rx,Tx,Bx,ux,Ax],Kx=Vx({defaultModifiers:Gx}),yc,Om;function Yx(){if(Om)return yc;Om=1;var t=typeof Element<"u",i=typeof Map=="function",o=typeof Set=="function",l=typeof ArrayBuffer=="function"&&!!ArrayBuffer.isView;function c(d,p){if(d===p)return!0;if(d&&p&&typeof d=="object"&&typeof p=="object"){if(d.constructor!==p.constructor)return!1;var f,m,h;if(Array.isArray(d)){if(f=d.length,f!=p.length)return!1;for(m=f;m--!==0;)if(!c(d[m],p[m]))return!1;return!0}var g;if(i&&d instanceof Map&&p instanceof Map){if(d.size!==p.size)return!1;for(g=d.entries();!(m=g.next()).done;)if(!p.has(m.value[0]))return!1;for(g=d.entries();!(m=g.next()).done;)if(!c(m.value[1],p.get(m.value[0])))return!1;return!0}if(o&&d instanceof Set&&p instanceof Set){if(d.size!==p.size)return!1;for(g=d.entries();!(m=g.next()).done;)if(!p.has(m.value[0]))return!1;return!0}if(l&&ArrayBuffer.isView(d)&&ArrayBuffer.isView(p)){if(f=d.length,f!=p.length)return!1;for(m=f;m--!==0;)if(d[m]!==p[m])return!1;return!0}if(d.constructor===RegExp)return d.source===p.source&&d.flags===p.flags;if(d.valueOf!==Object.prototype.valueOf)return d.valueOf()===p.valueOf();if(d.toString!==Object.prototype.toString)return d.toString()===p.toString();if(h=Object.keys(d),f=h.length,f!==Object.keys(p).length)return!1;for(m=f;m--!==0;)if(!Object.prototype.hasOwnProperty.call(p,h[m]))return!1;if(t&&d instanceof Element)return!1;for(m=f;m--!==0;)if(!((h[m]==="_owner"||h[m]==="__v"||h[m]==="__o")&&d.$$typeof)&&!c(d[h[m]],p[h[m]]))return!1;return!0}return d!==d&&p!==p}return yc=function(p,f){try{return c(p,f)}catch(m){if((m.message||"").match(/stack|recursion/i))return console.warn("react-fast-compare cannot handle circular refs"),!1;throw m}},yc}var qx=Yx();const Qx=lo(qx);var Zx=[],Jx=function(i,o,l){l===void 0&&(l={});var c=k.useRef(null),d={onFirstUpdate:l.onFirstUpdate,placement:l.placement||"bottom",strategy:l.strategy||"absolute",modifiers:l.modifiers||Zx},p=k.useState({styles:{popper:{position:d.strategy,left:"0",top:"0"},arrow:{position:"absolute"}},attributes:{}}),f=p[0],m=p[1],h=k.useMemo(function(){return{name:"updateState",enabled:!0,phase:"write",fn:function(w){var N=w.state,L=Object.keys(N.elements);Tu.flushSync(function(){m({styles:gm(L.map(function(O){return[O,N.styles[O]||{}]})),attributes:gm(L.map(function(O){return[O,N.attributes[O]]}))})})},requires:["computeStyles"]}},[]),g=k.useMemo(function(){var b={onFirstUpdate:d.onFirstUpdate,placement:d.placement,strategy:d.strategy,modifiers:[].concat(d.modifiers,[h,{name:"applyStyles",enabled:!1}])};return Qx(c.current,b)?c.current||b:(c.current=b,b)},[d.onFirstUpdate,d.placement,d.strategy,d.modifiers,h]),y=k.useRef();return ym(function(){y.current&&y.current.setOptions(g)},[g]),ym(function(){if(!(i==null||o==null)){var b=l.createPopper||Kx,w=b(i,o,g);return y.current=w,function(){w.destroy(),y.current=null}}},[i,o,l.createPopper]),{state:y.current?y.current.state:null,styles:f.styles,attributes:f.attributes,update:y.current?y.current.update:null,forceUpdate:y.current?y.current.forceUpdate:null}},e2=function(){},t2=function(){return Promise.resolve(null)},n2=[];function r2(t){var i=t.placement,o=i===void 0?"bottom":i,l=t.strategy,c=l===void 0?"absolute":l,d=t.modifiers,p=d===void 0?n2:d,f=t.referenceElement,m=t.onFirstUpdate,h=t.innerRef,g=t.children,y=k.useContext(zv),b=k.useState(null),w=b[0],N=b[1],L=k.useState(null),O=L[0],R=L[1];k.useEffect(function(){Lc(h,w)},[h,w]);var M=k.useMemo(function(){return{placement:o,strategy:c,onFirstUpdate:m,modifiers:[].concat(p,[{name:"arrow",enabled:O!=null,options:{element:O}}])}},[o,c,m,p,O]),z=Jx(f||y,w,M),I=z.state,B=z.styles,j=z.forceUpdate,X=z.update,K=k.useMemo(function(){return{ref:N,style:B.popper,placement:I?I.placement:o,hasPopperEscaped:I&&I.modifiersData.hide?I.modifiersData.hide.hasPopperEscaped:null,isReferenceHidden:I&&I.modifiersData.hide?I.modifiersData.hide.isReferenceHidden:null,arrowProps:{style:B.arrow,ref:R},forceUpdate:j||e2,update:X||t2}},[N,R,o,I,B,X,j]);return Xv(g)(K)}var _c,Am;function o2(){if(Am)return _c;Am=1;var t=function(){};return _c=t,_c}var i2=o2();const a2=lo(i2);function l2(t){var i=t.children,o=t.innerRef,l=k.useContext(Fv),c=k.useCallback(function(d){Lc(o,d),Uv(l,d)},[o,l]);return k.useEffect(function(){return function(){return Lc(o,null)}},[]),k.useEffect(function(){a2(!!l,"`Reference` should not be used outside of a `Manager` component.")},[l]),Xv(i)({ref:c})}function s2(t){var i=arguments.length>1&&arguments[1]!==void 0&&arguments[1];return function(o){for(var l=0;t.length>l;l++){var c=t[l];try{var d=void 0;if(rl(c)?d=c(o):c&&(c.current=o),d===!1&&i)return}catch(p){return void console.error(p)}}}}function Ya(t){var i=arguments.length>1&&arguments[1]!==void 0&&arguments[1];return function(o){for(var l=0;t.length>l;l++){var c=t[l];try{if((c&&c(o))===!1&&i)return}catch(d){return void console.error(d)}}}}function Nm(t){return mv(t)?t:[t]}function Fe(){}function Dc(){return Dc=Object.assign?Object.assign.bind():function(t){for(var i=1;i<arguments.length;i++){var o=arguments[i];for(var l in o)({}).hasOwnProperty.call(o,l)&&(t[l]=o[l])}return t},Dc.apply(null,arguments)}function Jv(t,i){if(t==null)return{};var o={};for(var l in t)if({}.hasOwnProperty.call(t,l)){if(i.indexOf(l)!==-1)continue;o[l]=t[l]}return o}function Ic(t,i){return Ic=Object.setPrototypeOf?Object.setPrototypeOf.bind():function(o,l){return o.__proto__=l,o},Ic(t,i)}function eh(t,i){t.prototype=Object.create(i.prototype),t.prototype.constructor=t,Ic(t,i)}function c2(t,i){return t.classList?!!i&&t.classList.contains(i):(" "+(t.className.baseVal||t.className)+" ").indexOf(" "+i+" ")!==-1}function u2(t,i){t.classList?t.classList.add(i):c2(t,i)||(typeof t.className=="string"?t.className=t.className+" "+i:t.setAttribute("class",(t.className&&t.className.baseVal||"")+" "+i))}function Lm(t,i){return t.replace(new RegExp("(^|\\s)"+i+"(?:\\s|$)","g"),"$1").replace(/\s+/g," ").replace(/^\s*|\s*$/g,"")}function d2(t,i){t.classList?t.classList.remove(i):typeof t.className=="string"?t.className=Lm(t.className,i):t.setAttribute("class",Lm(t.className&&t.className.baseVal||"",i))}const Rm={disabled:!1},th=D.createContext(null);var nh=function(i){return i.scrollTop},ai="unmounted",ar="exited",lr="entering",Yr="entered",Mc="exiting",vn=function(t){eh(i,t);function i(l,c){var d;d=t.call(this,l,c)||this;var p=c,f=p&&!p.isMounting?l.enter:l.appear,m;return d.appearStatus=null,l.in?f?(m=ar,d.appearStatus=lr):m=Yr:l.unmountOnExit||l.mountOnEnter?m=ai:m=ar,d.state={status:m},d.nextCallback=null,d}i.getDerivedStateFromProps=function(c,d){var p=c.in;return p&&d.status===ai?{status:ar}:null};var o=i.prototype;return o.componentDidMount=function(){this.updateStatus(!0,this.appearStatus)},o.componentDidUpdate=function(c){var d=null;if(c!==this.props){var p=this.state.status;this.props.in?p!==lr&&p!==Yr&&(d=lr):(p===lr||p===Yr)&&(d=Mc)}this.updateStatus(!1,d)},o.componentWillUnmount=function(){this.cancelNextCallback()},o.getTimeouts=function(){var c=this.props.timeout,d,p,f;return d=p=f=c,c!=null&&typeof c!="number"&&(d=c.exit,p=c.enter,f=c.appear!==void 0?c.appear:p),{exit:d,enter:p,appear:f}},o.updateStatus=function(c,d){if(c===void 0&&(c=!1),d!==null)if(this.cancelNextCallback(),d===lr){if(this.props.unmountOnExit||this.props.mountOnEnter){var p=this.props.nodeRef?this.props.nodeRef.current:Na.findDOMNode(this);p&&nh(p)}this.performEnter(c)}else this.performExit();else this.props.unmountOnExit&&this.state.status===ar&&this.setState({status:ai})},o.performEnter=function(c){var d=this,p=this.props.enter,f=this.context?this.context.isMounting:c,m=this.props.nodeRef?[f]:[Na.findDOMNode(this),f],h=m[0],g=m[1],y=this.getTimeouts(),b=f?y.appear:y.enter;if(!c&&!p||Rm.disabled){this.safeSetState({status:Yr},function(){d.props.onEntered(h)});return}this.props.onEnter(h,g),this.safeSetState({status:lr},function(){d.props.onEntering(h,g),d.onTransitionEnd(b,function(){d.safeSetState({status:Yr},function(){d.props.onEntered(h,g)})})})},o.performExit=function(){var c=this,d=this.props.exit,p=this.getTimeouts(),f=this.props.nodeRef?void 0:Na.findDOMNode(this);if(!d||Rm.disabled){this.safeSetState({status:ar},function(){c.props.onExited(f)});return}this.props.onExit(f),this.safeSetState({status:Mc},function(){c.props.onExiting(f),c.onTransitionEnd(p.exit,function(){c.safeSetState({status:ar},function(){c.props.onExited(f)})})})},o.cancelNextCallback=function(){this.nextCallback!==null&&(this.nextCallback.cancel(),this.nextCallback=null)},o.safeSetState=function(c,d){d=this.setNextCallback(d),this.setState(c,d)},o.setNextCallback=function(c){var d=this,p=!0;return this.nextCallback=function(f){p&&(p=!1,d.nextCallback=null,c(f))},this.nextCallback.cancel=function(){p=!1},this.nextCallback},o.onTransitionEnd=function(c,d){this.setNextCallback(d);var p=this.props.nodeRef?this.props.nodeRef.current:Na.findDOMNode(this),f=c==null&&!this.props.addEndListener;if(!p||f){setTimeout(this.nextCallback,0);return}if(this.props.addEndListener){var m=this.props.nodeRef?[this.nextCallback]:[p,this.nextCallback],h=m[0],g=m[1];this.props.addEndListener(h,g)}c!=null&&setTimeout(this.nextCallback,c)},o.render=function(){var c=this.state.status;if(c===ai)return null;var d=this.props,p=d.children;d.in,d.mountOnEnter,d.unmountOnExit,d.appear,d.enter,d.exit,d.timeout,d.addEndListener,d.onEnter,d.onEntering,d.onEntered,d.onExit,d.onExiting,d.onExited,d.nodeRef;var f=Jv(d,["children","in","mountOnEnter","unmountOnExit","appear","enter","exit","timeout","addEndListener","onEnter","onEntering","onEntered","onExit","onExiting","onExited","nodeRef"]);return D.createElement(th.Provider,{value:null},typeof p=="function"?p(c,f):D.cloneElement(D.Children.only(p),f))},i}(D.Component);vn.contextType=th;vn.propTypes={};function Wr(){}vn.defaultProps={in:!1,mountOnEnter:!1,unmountOnExit:!1,appear:!1,enter:!0,exit:!0,onEnter:Wr,onEntering:Wr,onEntered:Wr,onExit:Wr,onExiting:Wr,onExited:Wr};vn.UNMOUNTED=ai;vn.EXITED=ar;vn.ENTERING=lr;vn.ENTERED=Yr;vn.EXITING=Mc;var f2=function(i,o){return i&&o&&o.split(" ").forEach(function(l){return u2(i,l)})},bc=function(i,o){return i&&o&&o.split(" ").forEach(function(l){return d2(i,l)})},Iu=function(t){eh(i,t);function i(){for(var l,c=arguments.length,d=new Array(c),p=0;p<c;p++)d[p]=arguments[p];return l=t.call.apply(t,[this].concat(d))||this,l.appliedClasses={appear:{},enter:{},exit:{}},l.onEnter=function(f,m){var h=l.resolveArguments(f,m),g=h[0],y=h[1];l.removeClasses(g,"exit"),l.addClass(g,y?"appear":"enter","base"),l.props.onEnter&&l.props.onEnter(f,m)},l.onEntering=function(f,m){var h=l.resolveArguments(f,m),g=h[0],y=h[1],b=y?"appear":"enter";l.addClass(g,b,"active"),l.props.onEntering&&l.props.onEntering(f,m)},l.onEntered=function(f,m){var h=l.resolveArguments(f,m),g=h[0],y=h[1],b=y?"appear":"enter";l.removeClasses(g,b),l.addClass(g,b,"done"),l.props.onEntered&&l.props.onEntered(f,m)},l.onExit=function(f){var m=l.resolveArguments(f),h=m[0];l.removeClasses(h,"appear"),l.removeClasses(h,"enter"),l.addClass(h,"exit","base"),l.props.onExit&&l.props.onExit(f)},l.onExiting=function(f){var m=l.resolveArguments(f),h=m[0];l.addClass(h,"exit","active"),l.props.onExiting&&l.props.onExiting(f)},l.onExited=function(f){var m=l.resolveArguments(f),h=m[0];l.removeClasses(h,"exit"),l.addClass(h,"exit","done"),l.props.onExited&&l.props.onExited(f)},l.resolveArguments=function(f,m){return l.props.nodeRef?[l.props.nodeRef.current,f]:[f,m]},l.getClassNames=function(f){var m=l.props.classNames,h=typeof m=="string",g=h&&m?m+"-":"",y=h?""+g+f:m[f],b=h?y+"-active":m[f+"Active"],w=h?y+"-done":m[f+"Done"];return{baseClassName:y,activeClassName:b,doneClassName:w}},l}var o=i.prototype;return o.addClass=function(c,d,p){var f=this.getClassNames(d)[p+"ClassName"],m=this.getClassNames("enter"),h=m.doneClassName;d==="appear"&&p==="done"&&h&&(f+=" "+h),p==="active"&&c&&nh(c),f&&(this.appliedClasses[d][p]=f,f2(c,f))},o.removeClasses=function(c,d){var p=this.appliedClasses[d],f=p.base,m=p.active,h=p.done;this.appliedClasses[d]={},f&&bc(c,f),m&&bc(c,m),h&&bc(c,h)},o.render=function(){var c=this.props;c.classNames;var d=Jv(c,["classNames"]);return D.createElement(vn,Dc({},d,{onEnter:this.onEnter,onEntered:this.onEntered,onEntering:this.onEntering,onExit:this.onExit,onExiting:this.onExiting,onExited:this.onExited}))},i}(D.Component);Iu.defaultProps={classNames:""};Iu.propTypes={};function Pm(t){var i=t.ref,o=t.callback,l=t.ignoreClasses,c=t.eventName,d=c===void 0?"click":c,p=k.useCallback(function(m){i&&i.current&&!i.current.contains(m.target)&&(l&&m.target instanceof HTMLElement&&m.target.closest(l.join(","))||o(m))},[i,o,l]),f=k.useRef(Jr()?document.body:null);Ha({eventName:d,ref:f,callback:p,capture:!0}),Ha({eventName:"touchend",ref:f,callback:p,capture:!0})}var Dm,Im,p2={SMALL:"small",MEDIUM:"medium",LARGE:"large"},qr=Object.assign({XXS:"xxs",XS:"xs"},p2);(function(t){t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"})(Dm||(Dm={})),function(t){t.XXS="xxs",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"}(Im||(Im={}));var Yt={contentWrapper:"contentWrapper_f78ad0f219",top:"top_a41112a94e",right:"right_c775d95911",left:"left_95b6d7cc6d",bottom:"bottom_6b1836d67c",bottomStart:"bottomStart_a412fa5bfd",topStart:"topStart_c528d155de",bottomEnd:"bottomEnd_885c7a3d1e",topEnd:"topEnd_e338b0c0a8",leftStart:"leftStart_c1b48cdf8a",rightStart:"rightStart_5bee00f7f7",leftEnd:"leftEnd_56c34d1b69",rightEnd:"rightEnd_defa97b6dc",contentComponent:"contentComponent_f78ad0f219",hasTooltip:"hasTooltip_1394e28360",opacitySlideAppear:"opacitySlideAppear_068fa3a818",opacitySlideAppearActive:"opacitySlideAppearActive_a9d4409ae5",expandAppear:"expandAppear_2b7894e295",expandExit:"expandExit_85f09b9e78",edgeBottom:"edgeBottom_a952559229",edgeTop:"edgeTop_503813c757",expandAppearActive:"expandAppearActive_7e8e8d5c0a"};(function(t){const i="s_id-ca4097b848ab_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.contentWrapper_f78ad0f219 {
  outline: 0;
}
.contentWrapper_f78ad0f219.top_a41112a94e, .contentWrapper_f78ad0f219.right_c775d95911, .contentWrapper_f78ad0f219.left_95b6d7cc6d, .contentWrapper_f78ad0f219.bottom_6b1836d67c {
  padding: var(--spacing-xs);
}
.contentWrapper_f78ad0f219.bottomStart_a412fa5bfd, .contentWrapper_f78ad0f219.topStart_c528d155de, .contentWrapper_f78ad0f219.bottomEnd_885c7a3d1e, .contentWrapper_f78ad0f219.topEnd_e338b0c0a8 {
  padding-block: var(--spacing-xs);
}
.contentWrapper_f78ad0f219.bottomStart_a412fa5bfd, .contentWrapper_f78ad0f219.topStart_c528d155de {
  padding-inline-end: var(--spacing-xs);
}
.contentWrapper_f78ad0f219.bottomEnd_885c7a3d1e, .contentWrapper_f78ad0f219.topEnd_e338b0c0a8 {
  padding-inline-start: var(--spacing-xs);
}
.contentWrapper_f78ad0f219.leftStart_c1b48cdf8a, .contentWrapper_f78ad0f219.rightStart_5bee00f7f7, .contentWrapper_f78ad0f219.leftEnd_56c34d1b69, .contentWrapper_f78ad0f219.rightEnd_defa97b6dc {
  padding-inline: var(--spacing-xs);
}
.contentWrapper_f78ad0f219.leftStart_c1b48cdf8a, .contentWrapper_f78ad0f219.rightStart_5bee00f7f7 {
  padding-block-end: var(--spacing-xs);
}
.contentWrapper_f78ad0f219.leftEnd_56c34d1b69, .contentWrapper_f78ad0f219.rightEnd_defa97b6dc {
  padding-block-start: var(--spacing-xs);
}
.contentWrapper_f78ad0f219[data-popper-reference-hidden=true] {
  visibility: hidden;
  pointer-events: none;
}
.contentComponent_f78ad0f219:focus {
  outline: none;
}
.contentComponent_f78ad0f219.hasTooltip_1394e28360 {
  padding: 6px;
}
.opacitySlideAppear_068fa3a818 {
  opacity: 0;
}
.opacitySlideAppear_068fa3a818.top_a41112a94e {
  transform: translateY(var(--spacing-medium));
}
.opacitySlideAppear_068fa3a818.right_c775d95911 {
  transform: translateX(calc(var(--spacing-medium) * -1));
}
.opacitySlideAppear_068fa3a818.bottom_6b1836d67c {
  transform: translateY(calc(var(--spacing-medium) * -1));
}
.opacitySlideAppear_068fa3a818.left_95b6d7cc6d {
  transform: translateX(var(--spacing-medium));
}
.opacitySlideAppearActive_a9d4409ae5 {
  transition: opacity 0.2s ease, transform 0.2s ease-out;
  opacity: 1;
  pointer-events: none;
}
.opacitySlideAppearActive_a9d4409ae5.top_a41112a94e, .opacitySlideAppearActive_a9d4409ae5.bottom_6b1836d67c {
  transform: translateY(0);
}
.opacitySlideAppearActive_a9d4409ae5.right_c775d95911, .opacitySlideAppearActive_a9d4409ae5.left_95b6d7cc6d {
  transform: translateX(0);
}
.expandAppear_2b7894e295,
.expandExit_85f09b9e78 {
  transition: transform 0.1s cubic-bezier(0, 0, 0.35, 1);
}
.expandAppear_2b7894e295.top_a41112a94e, .expandAppear_2b7894e295.topStart_c528d155de, .expandAppear_2b7894e295.topEnd_e338b0c0a8,
.expandExit_85f09b9e78.top_a41112a94e,
.expandExit_85f09b9e78.topStart_c528d155de,
.expandExit_85f09b9e78.topEnd_e338b0c0a8 {
  transform-origin: bottom center;
  transform: scale(0.8);
}
.expandAppear_2b7894e295.top_a41112a94e.edgeBottom_a952559229, .expandAppear_2b7894e295.topStart_c528d155de.edgeBottom_a952559229, .expandAppear_2b7894e295.topEnd_e338b0c0a8.edgeBottom_a952559229,
.expandExit_85f09b9e78.top_a41112a94e.edgeBottom_a952559229,
.expandExit_85f09b9e78.topStart_c528d155de.edgeBottom_a952559229,
.expandExit_85f09b9e78.topEnd_e338b0c0a8.edgeBottom_a952559229 {
  transform-origin: bottom left;
}
.expandAppear_2b7894e295.top_a41112a94e.edgeTop_503813c757, .expandAppear_2b7894e295.topStart_c528d155de.edgeTop_503813c757, .expandAppear_2b7894e295.topEnd_e338b0c0a8.edgeTop_503813c757,
.expandExit_85f09b9e78.top_a41112a94e.edgeTop_503813c757,
.expandExit_85f09b9e78.topStart_c528d155de.edgeTop_503813c757,
.expandExit_85f09b9e78.topEnd_e338b0c0a8.edgeTop_503813c757 {
  transform-origin: bottom right;
}
.expandAppear_2b7894e295.right_c775d95911, .expandAppear_2b7894e295.rightStart_5bee00f7f7, .expandAppear_2b7894e295.rightEnd_defa97b6dc,
.expandExit_85f09b9e78.right_c775d95911,
.expandExit_85f09b9e78.rightStart_5bee00f7f7,
.expandExit_85f09b9e78.rightEnd_defa97b6dc {
  transform-origin: left;
  transform: scale(0.8);
}
.expandAppear_2b7894e295.right_c775d95911.edgeBottom_a952559229, .expandAppear_2b7894e295.rightStart_5bee00f7f7.edgeBottom_a952559229, .expandAppear_2b7894e295.rightEnd_defa97b6dc.edgeBottom_a952559229,
.expandExit_85f09b9e78.right_c775d95911.edgeBottom_a952559229,
.expandExit_85f09b9e78.rightStart_5bee00f7f7.edgeBottom_a952559229,
.expandExit_85f09b9e78.rightEnd_defa97b6dc.edgeBottom_a952559229 {
  transform-origin: top left;
}
.expandAppear_2b7894e295.right_c775d95911.edgeTop_503813c757, .expandAppear_2b7894e295.rightStart_5bee00f7f7.edgeTop_503813c757, .expandAppear_2b7894e295.rightEnd_defa97b6dc.edgeTop_503813c757,
.expandExit_85f09b9e78.right_c775d95911.edgeTop_503813c757,
.expandExit_85f09b9e78.rightStart_5bee00f7f7.edgeTop_503813c757,
.expandExit_85f09b9e78.rightEnd_defa97b6dc.edgeTop_503813c757 {
  transform-origin: bottom left;
}
.expandAppear_2b7894e295.bottom_6b1836d67c, .expandAppear_2b7894e295.bottomStart_a412fa5bfd, .expandAppear_2b7894e295.bottomEnd_885c7a3d1e,
.expandExit_85f09b9e78.bottom_6b1836d67c,
.expandExit_85f09b9e78.bottomStart_a412fa5bfd,
.expandExit_85f09b9e78.bottomEnd_885c7a3d1e {
  transform-origin: top;
  transform: scale(0.8);
}
.expandAppear_2b7894e295.bottom_6b1836d67c.edgeBottom_a952559229, .expandAppear_2b7894e295.bottomStart_a412fa5bfd.edgeBottom_a952559229, .expandAppear_2b7894e295.bottomEnd_885c7a3d1e.edgeBottom_a952559229,
.expandExit_85f09b9e78.bottom_6b1836d67c.edgeBottom_a952559229,
.expandExit_85f09b9e78.bottomStart_a412fa5bfd.edgeBottom_a952559229,
.expandExit_85f09b9e78.bottomEnd_885c7a3d1e.edgeBottom_a952559229 {
  transform-origin: top left;
}
.expandAppear_2b7894e295.bottom_6b1836d67c.edgeTop_503813c757, .expandAppear_2b7894e295.bottomStart_a412fa5bfd.edgeTop_503813c757, .expandAppear_2b7894e295.bottomEnd_885c7a3d1e.edgeTop_503813c757,
.expandExit_85f09b9e78.bottom_6b1836d67c.edgeTop_503813c757,
.expandExit_85f09b9e78.bottomStart_a412fa5bfd.edgeTop_503813c757,
.expandExit_85f09b9e78.bottomEnd_885c7a3d1e.edgeTop_503813c757 {
  transform-origin: top right;
}
.expandAppear_2b7894e295.left_95b6d7cc6d, .expandAppear_2b7894e295.leftStart_c1b48cdf8a, .expandAppear_2b7894e295.leftEnd_56c34d1b69,
.expandExit_85f09b9e78.left_95b6d7cc6d,
.expandExit_85f09b9e78.leftStart_c1b48cdf8a,
.expandExit_85f09b9e78.leftEnd_56c34d1b69 {
  transform-origin: right;
  transform: scale(0.8);
}
.expandAppear_2b7894e295.left_95b6d7cc6d.edgeBottom_a952559229, .expandAppear_2b7894e295.leftStart_c1b48cdf8a.edgeBottom_a952559229, .expandAppear_2b7894e295.leftEnd_56c34d1b69.edgeBottom_a952559229,
.expandExit_85f09b9e78.left_95b6d7cc6d.edgeBottom_a952559229,
.expandExit_85f09b9e78.leftStart_c1b48cdf8a.edgeBottom_a952559229,
.expandExit_85f09b9e78.leftEnd_56c34d1b69.edgeBottom_a952559229 {
  transform-origin: top right;
}
.expandAppear_2b7894e295.left_95b6d7cc6d.edgeTop_503813c757, .expandAppear_2b7894e295.leftStart_c1b48cdf8a.edgeTop_503813c757, .expandAppear_2b7894e295.leftEnd_56c34d1b69.edgeTop_503813c757,
.expandExit_85f09b9e78.left_95b6d7cc6d.edgeTop_503813c757,
.expandExit_85f09b9e78.leftStart_c1b48cdf8a.edgeTop_503813c757,
.expandExit_85f09b9e78.leftEnd_56c34d1b69.edgeTop_503813c757 {
  transform-origin: bottom right;
}
.expandExit_85f09b9e78 {
  transition: transform 0.1s cubic-bezier(0, 0, 0.35, 1);
}
.expandAppearActive_7e8e8d5c0a {
  transition: transform 0.1s cubic-bezier(0, 0, 0.35, 1);
  pointer-events: none;
}
.expandAppearActive_7e8e8d5c0a.top_a41112a94e, .expandAppearActive_7e8e8d5c0a.topStart_c528d155de, .expandAppearActive_7e8e8d5c0a.topEnd_e338b0c0a8, .expandAppearActive_7e8e8d5c0a.bottom_6b1836d67c, .expandAppearActive_7e8e8d5c0a.bottomStart_a412fa5bfd, .expandAppearActive_7e8e8d5c0a.bottomEnd_885c7a3d1e, .expandAppearActive_7e8e8d5c0a.right_c775d95911, .expandAppearActive_7e8e8d5c0a.rightStart_5bee00f7f7, .expandAppearActive_7e8e8d5c0a.rightEnd_defa97b6dc, .expandAppearActive_7e8e8d5c0a.left_95b6d7cc6d, .expandAppearActive_7e8e8d5c0a.leftStart_c1b48cdf8a, .expandAppearActive_7e8e8d5c0a.leftEnd_56c34d1b69 {
  transform: scale(1);
}`);var m2=function(t){var i=k.useCallback(function(c){return c.preventDefault(),c.stopPropagation(),!1},[]),o=k.useCallback(function(){(t==null?void 0:t.length)>0&&document.querySelectorAll(t).forEach(function(c){c.addEventListener("wheel",i)})},[i,t]),l=k.useCallback(function(){(t==null?void 0:t.length)>0&&document.querySelectorAll(t).forEach(function(c){c.removeEventListener("wheel",i)})},[i,t]);return k.useEffect(function(){return l},[l]),{disableScroll:o,enableScroll:l}},v2={},h2=[vr.ESCAPE],g2=k.forwardRef(function(t,i){var o=t.onEsc,l=o===void 0?Fe:o,c=t.children,d=t.position,p=t.wrapperClassName,f=t.isOpen,m=f!==void 0&&f,h=t.startingEdge,g=t.animationType,y=g===void 0?"expand":g,b=t.onMouseEnter,w=b===void 0?Fe:b,N=t.onMouseLeave,L=N===void 0?Fe:N,O=t.onClickOutside,R=O===void 0?Fe:O,M=t.onClick,z=M===void 0?Fe:M,I=t.onContextMenu,B=I===void 0?Fe:I,j=t.showDelay,X=t.styleObject,K=X===void 0?v2:X,ce=t.isReferenceHidden,Q=t.hasTooltip,Z=Q!==void 0&&Q,le=t.containerSelector,de=t.disableContainerScroll,oe=de!==void 0&&de,ve=t["data-testid"],re=k.useRef(null),fe=k.useCallback(function(te){if(m)return R(te,"clickoutside")},[m,R]),H=k.useCallback(function(te){m&&B(te)},[m,B]);ll({keys:h2,callback:l}),Pm({callback:fe,ref:re}),Pm({eventName:"contextmenu",callback:H,ref:re});var V=m2(typeof oe=="string"?oe:le),x=V.disableScroll,P=V.enableScroll;k.useEffect(function(){oe&&(m?x():P())},[oe,x,P,m]);var G={classNames:void 0};switch(y){case"expand":G.classNames={appear:Yt.expandAppear,appearActive:Yt.expandAppearActive,exit:Yt.expandExit};break;case"opacity-and-slide":G.classNames={appear:Yt.opacitySlideAppear,appearActive:Yt.opacitySlideAppearActive}}return D.createElement("span",{className:ue("monday-style-dialog-content-wrapper",Yt.contentWrapper,p),ref:i,"data-testid":ve,style:K,onClickCapture:z,"data-popper-reference-hidden":ce},D.createElement(Iu,Object.assign({},G,{in:m,appear:!!y,timeout:j}),D.createElement("div",{className:ue(Yt.contentComponent,Xe(Yt,Qe(d)),se(se({},Xe(Yt,Qe("edge-"+h)),h),Yt.hasTooltip,Z)),ref:re},D.Children.toArray(c).map(function(te){return k.cloneElement(te,{onMouseEnter:Ya([te.props.onMouseEnter,w]),onMouseLeave:Ya([te.props.onMouseLeave,L])})}))))});function Mm(t,i){return!!i&&(o=Array.isArray(i)?i.map(function(l){return".".concat(l)}).join(","):".".concat(i),!!t.parentElement.closest(o));var o}Cu(function(t){if(!t)return null;for(;t.parentElement;){if(y2(t.parentElement))return t.parentElement;t=t.parentElement}return document.body},function(t){return t.outerHTML});var y2=function(t){return["auto","scroll"].includes(getComputedStyle(t).getPropertyValue("overflow-y"))},_2=D.forwardRef(function(t,i){var o=t.children,l=co(t,["children"]);return D.Children.map(o,function(c){return D.isValidElement(c)?typeof c.type!="string"?D.createElement("span",Object.assign({ref:i},l),D.cloneElement(c,Object.assign({},c.props))):D.cloneElement(c,Object.assign(Object.assign(Object.assign({},l),c.props),{onClick:Vr("onClick",c.props,l),onBlur:Vr("onBlur",c.props,l),onMouseEnter:Vr("onMouseEnter",c.props,l),onMouseLeave:Vr("onMouseLeave",c.props,l),onMouseDown:Vr("onMouseDown",c.props,l),onFocus:Vr("onFocus",c.props,l),ref:s2([c.ref,i])})):null})});function Vr(t,i,o){return Ya([i[t],o[t]],!0)}var ur,hi,Bm,jm,Bc;(function(t){t.CLICK="click",t.CLICK_OUTSIDE="clickoutside",t.ESCAPE_KEY="esckey",t.TAB_KEY="tab",t.MOUSE_ENTER="mouseenter",t.MOUSE_LEAVE="mouseleave",t.ENTER="enter",t.MOUSE_DOWN="mousedown",t.FOCUS="focus",t.BLUR="blur",t.CONTENT_CLICK="onContentClick",t.CONTEXT_MENU="contextmenu"})(ur||(ur={})),function(t){t.OPACITY_AND_SLIDE="opacity-and-slide",t.EXPAND="expand"}(hi||(hi={})),function(t){t.MODAL="modal",t.POPOVER="popover"}(Bm||(Bm={})),function(t){t.NONE="none",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"}(jm||(jm={})),function(t){t.LEFT="left",t.LEFT_START="left-start",t.LEFT_END="left-end",t.RIGHT="right",t.RIGHT_START="right-start",t.RIGHT_END="right-end",t.TOP="top",t.TOP_START="top-start",t.TOP_END="top-end",t.BOTTOM="bottom",t.BOTTOM_START="bottom-start",t.BOTTOM_END="bottom-end"}(Bc||(Bc={}));var b2={arrow:"arrow_914a6b0d28"};(function(t){const i="s_id-3fb64cda561a_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.arrow_914a6b0d28 {
  width: 12px;
  height: 12px;
  position: absolute;
  border-radius: 2px;
  background-color: var(--secondary-background-color);
}
.dark-app-theme .arrow_914a6b0d28[data-placement*=right], .black-app-theme .arrow_914a6b0d28[data-placement*=right], .hacker-app-theme .arrow_914a6b0d28[data-placement*=right] {
  box-shadow: -1px 1px 0px 0px var(--layout-border-color);
}
.dark-app-theme .arrow_914a6b0d28[data-placement*=left], .black-app-theme .arrow_914a6b0d28[data-placement*=left], .hacker-app-theme .arrow_914a6b0d28[data-placement*=left] {
  box-shadow: 1px -1px 0px 0px var(--layout-border-color);
}
.dark-app-theme .arrow_914a6b0d28[data-placement*=bottom], .black-app-theme .arrow_914a6b0d28[data-placement*=bottom], .hacker-app-theme .arrow_914a6b0d28[data-placement*=bottom] {
  box-shadow: -1px -1px 0px 0px var(--layout-border-color);
}
.dark-app-theme .arrow_914a6b0d28[data-placement*=top], .black-app-theme .arrow_914a6b0d28[data-placement*=top], .hacker-app-theme .arrow_914a6b0d28[data-placement*=top] {
  box-shadow: 1px 1px 0px 0px var(--layout-border-color);
}
.arrow_914a6b0d28[data-placement*=bottom] {
  top: 1px;
}
.arrow_914a6b0d28[data-placement*=top] {
  bottom: 1px;
}
.arrow_914a6b0d28[data-placement*=left] {
  right: 1px;
}
.arrow_914a6b0d28[data-placement*=right] {
  left: 1px;
}`);var x2=D.createContext({layerRef:null}),k2=function(){return{name:"observeContentResize",enabled:arguments.length>0&&arguments[0]!==void 0&&arguments[0],phase:"beforeWrite",fn:function(){},effect:function(t){var i=t.state,o=t.instance,l=new ResizeObserver(function(){o.update()});return l.observe(i.elements.popper),function(){l.disconnect()}}}},un=function(t){function i(o){var l;return ov(this,i),(l=tv(this,i,[o])).state={shouldUseDerivedStateFromProps:o.useDerivedStateFromProps,isOpen:o.shouldShowOnMount},l.onMouseEnter=l.onMouseEnter.bind(l),l.onMouseLeave=l.onMouseLeave.bind(l),l.onMouseDown=l.onMouseDown.bind(l),l.onClick=l.onClick.bind(l),l.onFocus=l.onFocus.bind(l),l.onBlur=l.onBlur.bind(l),l.isShown=l.isShown.bind(l),l.onEsc=l.onEsc.bind(l),l.onClickOutside=l.onClickOutside.bind(l),l.onDialogEnter=l.onDialogEnter.bind(l),l.onDialogLeave=l.onDialogLeave.bind(l),l.getContainer=l.getContainer.bind(l),l.onContentClick=l.onContentClick.bind(l),l.onKeyDown=l.onKeyDown.bind(l),l.closeDialogOnEscape=l.closeDialogOnEscape.bind(l),l.onContextMenu=l.onContextMenu.bind(l),l.hideTimeout=null,l.showTimeout=null,l}return av(i,k.PureComponent),iv(i,[{key:"closeDialogOnEscape",value:function(o){if(this.state.isOpen)switch(o.key){case"Escape":this.hideDialogIfNeeded(o,ur.ESCAPE_KEY);break;case"Tab":this.handleEvent(ur.TAB_KEY,o.target,o);break;case"Enter":this.handleEvent(ur.ENTER,o.target,o)}}},{key:"componentDidMount",value:function(){var o=this.props,l=o.shouldCallbackOnMount,c=o.onDialogDidShow,d=this.state.isOpen;Jr()&&document.addEventListener("keyup",this.closeDialogOnEscape),l&&d&&c&&c()}},{key:"componentWillUnmount",value:function(){Jr()&&document.removeEventListener("keyup",this.closeDialogOnEscape),this.showTimeout&&(clearTimeout(this.showTimeout),this.showTimeout=null),this.hideTimeout&&(clearTimeout(this.hideTimeout),this.hideTimeout=null)}},{key:"getContainer",value:function(){var o=document.querySelector(this.props.containerSelector);if(!(o&&o instanceof Element)){var l=this.context.layerRef;return l!=null&&l.current?l.current:document.body}return o}},{key:"showDialog",value:function(o,l){var c=this,d=this.props,p=d.instantShowAndHide,f=d.getDynamicShowDelay,m=d.showDelay,h=(arguments.length>2&&arguments[2]!==void 0?arguments[2]:{}).preventAnimation;if(f){var g=f();m=g.showDelay||0,h=h||g.preventAnimation}p?(this.onShowDialog(o,l),this.setState({isOpen:!0,preventAnimation:h}),this.showTimeout=null):this.showTimeout=setTimeout(function(){c.onShowDialog(o,l),c.showTimeout=null,c.setState({isOpen:!0,preventAnimation:h})},m)}},{key:"onShowDialog",value:function(o,l){this.isShown()||(0,this.props.onDialogDidShow)(o,l)}},{key:"showDialogIfNeeded",value:function(o,l){var c=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};this.props.disable||(this.hideTimeout&&(clearTimeout(this.hideTimeout),this.hideTimeout=null),this.showTimeout||this.showDialog(o,l,c))}},{key:"hideDialog",value:function(o,l){var c=this,d=this.props,p=d.hideDelay;d.instantShowAndHide?(this.onHideDialog(o,l),this.setState({isOpen:!1}),this.hideTimeout=null):this.hideTimeout=setTimeout(function(){c.onHideDialog(o,l),c.setState({isOpen:!1}),c.hideTimeout=null},p)}},{key:"onHideDialog",value:function(o,l){var c=this.props.onDialogDidHide;c&&c(o,l)}},{key:"hideDialogIfNeeded",value:function(o,l){this.showTimeout&&(clearTimeout(this.showTimeout),this.showTimeout=null),this.hideTimeout||this.hideDialog(o,l)}},{key:"handleEvent",value:function(o,l,c){var d=this.props,p=d.showTriggerIgnoreClass,f=d.hideTriggerIgnoreClass;return!this.isShowTrigger(o)||this.isShown()||Mm(l,p)?this.isHideTrigger(o)&&!Mm(l,f)?this.hideDialogIfNeeded(c,o):void 0:this.showDialogIfNeeded(c,o)}},{key:"isShown",value:function(){return this.state.isOpen||this.props.open}},{key:"isShowTrigger",value:function(o){var l=this.props,c=l.addKeyboardHideShowTriggersByDefault,d=Nm(l.showTrigger);return!(!c||o!=="focus"||-1>=d.indexOf("mouseenter"))||d.indexOf(o)>-1}},{key:"isHideTrigger",value:function(o){var l=this.props,c=l.addKeyboardHideShowTriggersByDefault,d=Nm(l.hideTrigger);return!(!c||o!=="blur"||-1>=d.indexOf("mouseleave"))||d.indexOf(o)>-1}},{key:"onMouseEnter",value:function(o){this.handleEvent("mouseenter",o.target,o)}},{key:"onMouseLeave",value:function(o){this.handleEvent("mouseleave",o.target,o)}},{key:"onClick",value:function(o){o.button||this.handleEvent("click",o.target,o)}},{key:"onKeyDown",value:function(o){o.key==="Enter"&&this.handleEvent("enter",o.target,o),o.key==="Tab"&&this.handleEvent("tab",o.target,o)}},{key:"onMouseDown",value:function(o){o.button||this.handleEvent("mousedown",o.target,o)}},{key:"onFocus",value:function(o){this.handleEvent("focus",o.target,o)}},{key:"onBlur",value:function(o){this.handleEvent("blur",o.relatedTarget,o)}},{key:"onEsc",value:function(o){this.handleEvent("esckey",o.target,o)}},{key:"onContextMenu",value:function(o){var l=this.isShown();(this.isShowTrigger("contextmenu")&&!l||this.isHideTrigger("contextmenu")&&l)&&o.preventDefault(),this.handleEvent("contextmenu",o.target,o)}},{key:"onClickOutside",value:function(o){var l=this.props.onClickOutside;this.handleEvent("clickoutside",o.target,o),l(o)}},{key:"onDialogEnter",value:function(o){this.props.showOnDialogEnter&&this.showDialogIfNeeded(o,"DialogEnter")}},{key:"onDialogLeave",value:function(o){this.props.showOnDialogEnter&&this.hideDialogIfNeeded(o,"DialogLeave")}},{key:"onContentClick",value:function(o){var l=this.props.onContentClick;this.handleEvent("onContentClick",o.target,o),l(o)}},{key:"render",value:function(){var o=this,l=this.props,c=l.wrapperClassName,d=l.content,p=l.startingEdge,f=l.children,m=l.preventAnimationOnMount,h=l.animationType,g=l.position,y=l.showDelay,b=l.moveBy,w=l.modifiers,N=l.tooltip,L=l.tooltipClassName,O=l.referenceWrapperClassName,R=l.zIndex,M=l.hideWhenReferenceHidden,z=l.disableContainerScroll,I=l.containerSelector,B=l.observeContentResize,j=this.state.preventAnimation,X=l["data-testid"]||De(pn.DIALOG,l.id),K=m||j?void 0:h,ce=rl(d)?d():d;return ce?D.createElement(Xb,null,D.createElement(l2,null,function(Q){var Z=Q.ref;return D.createElement(_2,{className:ue(O),ref:Z,onBlur:jn("onBlur",o,o.props),onKeyDown:jn("onKeyDown",o,o.props),onClick:jn("onClick",o,o.props),onFocus:jn("onFocus",o,o.props),onMouseDown:jn("onMouseDown",o,o.props),onMouseEnter:jn("onMouseEnter",o,o.props),onMouseLeave:jn("onMouseLeave",o,o.props),onContextMenu:jn("onContextMenu",o,o.props)},f)}),Jr()&&Tu.createPortal(D.createElement(r2,{placement:g,modifiers:[{name:"offset",options:{offset:[b.secondary,b.main]}},{name:"zIndex",enabled:!0,phase:"write",fn:function(Q){var Z=Q.state;return R&&(Z.styles.popper.zIndex=R+""),Z}},{name:"rotator",enabled:!0,phase:"write",fn:function(Q){var Z=Q.state;return Z.styles.arrow&&(Z.styles.arrow.transform="".concat(Z.styles.arrow.transform," rotate(45deg)")),Z}},k2(B)].concat(wu(w))},function(Q){var Z=Q.placement,le=Q.style,de=Q.ref,oe=Q.arrowProps,ve=Q.isReferenceHidden;if(!o.isShown()&&Z)return null;if(M&&ve){var re=new CustomEvent("onReferenceHidden");o.hideDialog(re,"onReferenceHidden")}return D.createElement(g2,{"data-testid":X,isReferenceHidden:M&&ve,onMouseEnter:o.onDialogEnter,onMouseLeave:o.onDialogLeave,onClickOutside:o.onClickOutside,onContextMenu:o.onContextMenu,onEsc:o.onEsc,animationType:K,position:Z,wrapperClassName:c,startingEdge:p,isOpen:o.isShown(),showDelay:y,styleObject:le,ref:de,onClick:o.onContentClick,hasTooltip:!!N,containerSelector:I,disableContainerScroll:z},ce,N&&D.createElement("div",{style:oe.style,ref:oe.ref,className:ue(b2.arrow,L),"data-placement":Z}))}),this.getContainer())):f}}],[{key:"getDerivedStateFromProps",value:function(o,l){return l.shouldUseDerivedStateFromProps?{isOpen:o.isOpen}:null}}])}();function jn(t,i,o){return Ya([o[t],i[t]],!0)}un.hideShowTriggers=ur,un.positions=Bc,un.animationTypes=hi,un.defaultProps={position:"top",modifiers:[],moveBy:{main:0,secondary:0},showDelay:100,hideDelay:100,showTrigger:un.hideShowTriggers.MOUSE_ENTER,hideTrigger:un.hideShowTriggers.MOUSE_LEAVE,showOnDialogEnter:!1,shouldShowOnMount:!1,disable:!1,open:!1,animationType:un.animationTypes.EXPAND,preventAnimationOnMount:!1,tooltip:!1,onDialogDidShow:Fe,onDialogDidHide:Fe,onClickOutside:Fe,onContentClick:Fe,useDerivedStateFromProps:!1,hideWhenReferenceHidden:!1,shouldCallbackOnMount:!1,instantShowAndHide:!1,addKeyboardHideShowTriggersByDefault:!1,observeContentResize:!1},un.contextType=x2;var jc,$c;(function(t){t.TOP="top",t.RIGHT="right",t.BOTTOM="bottom",t.LEFT="left"})(jc||(jc={})),function(t){t.Dark="dark",t.Primary="primary"}($c||($c={}));var or={tooltip:"tooltip_35f6fc5122",image:"image_73611190e4",title:"title_6e3e14ff64",content:"content_08061ddab8",paddingSizeMd:"paddingSizeMd_596b322f7c",tooltipWhiteLink:"tooltipWhiteLink_e8f195e45c",arrow:"arrow_d18d56b5d4",dark:"dark_4eec8346ce",primary:"primary_0cc593fc97"};(function(t){const i="s_id-6a6e92472798_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tooltip_35f6fc5122 {
  position: relative;
  display: inline-block;
  border-radius: var(--tooltip-border-radius, var(--border-radius-small));
  box-shadow: var(--box-shadow-medium);
  font: var(--font-text2-normal);
  max-width: var(--tooltip-max-width, 50vw);
  word-break: break-word;
  background-color: var(--inverted-color-background);
  color: var(--text-color-on-inverted);
  --tooltip-max-width: 240px;
  white-space: pre-wrap;
}
.tooltip_35f6fc5122 .image_73611190e4 {
  display: block;
  position: relative;
  border-top-right-radius: 2px;
  border-top-left-radius: 2px;
  padding: 2px 2px 0 2px;
  object-fit: cover;
  width: 100%;
  height: 100%;
  min-width: var(--tooltip-max-width);
  z-index: 1;
}
.tooltip_35f6fc5122 .title_6e3e14ff64 {
  font: var(--font-text2-bold);
}
.tooltip_35f6fc5122 .content_08061ddab8 {
  word-break: break-word;
  display: inline-block;
  padding: var(--tooltip-padding, var(--spacing-small) var(--spacing-medium));
}
.tooltip_35f6fc5122.paddingSizeMd_596b322f7c {
  border-radius: var(--border-radius-medium);
  padding: var(--spacing-medium);
  font: var(--font-text2-normal);
}
.tooltip_35f6fc5122 a.tooltipWhiteLink_e8f195e45c {
  color: #fff;
}
.arrow_d18d56b5d4,
.dark_4eec8346ce,
.arrow_d18d56b5d4.dark_4eec8346ce {
  background-color: var(--inverted-color-background);
  color: var(--text-color-on-inverted);
}
.dark-app-theme .arrow_d18d56b5d4.arrow_d18d56b5d4.dark_4eec8346ce, .black-app-theme .arrow_d18d56b5d4.arrow_d18d56b5d4.dark_4eec8346ce, .hacker-app-theme .arrow_d18d56b5d4.arrow_d18d56b5d4.dark_4eec8346ce,
.dark-app-theme .arrow_d18d56b5d4.arrow_d18d56b5d4.primary_0cc593fc97,
.black-app-theme .arrow_d18d56b5d4.arrow_d18d56b5d4.primary_0cc593fc97,
.hacker-app-theme .arrow_d18d56b5d4.arrow_d18d56b5d4.primary_0cc593fc97 {
  box-shadow: none;
}
.primary_0cc593fc97,
.arrow_d18d56b5d4.primary_0cc593fc97 {
  background-color: var(--primary-color);
  color: var(--text-color-on-primary);
}`);function rh(t){return k.useCallback(function(i){i.key!==vr.SPACE&&i.key!==vr.ENTER||t(i)},[t])}function E2(t,i){var o=t.onClick,l=o===void 0?Fe:o,c=t.onMouseDown,d=c===void 0?Fe:c,p=t.onMouseEnter,f=p===void 0?Fe:p,m=t.onMouseLeave,h=m===void 0?Fe:m,g=t.disabled,y=g!==void 0&&g,b=t.id,w=t["data-testid"],N=t.role,L=N===void 0?"button":N,O=t.tabIndex,R=O===void 0?0:O,M=t.ariaLabel,z=t.ariaHidden,I=t.ariaHasPopup,B=t.ariaExpanded,j=rh(l),X=k.useRef(null),K=I===void 0?void 0:!!I;return{ref:$t(i,X),id:b,"data-testid":w||De(Ze.CLICKABLE,b),onClick:y?void 0:l,onKeyDown:y?void 0:j,onMouseDown:d,onMouseEnter:f,onMouseLeave:h,tabIndex:y?-1:Number(R),role:L,"aria-label":M,"aria-hidden":z,"aria-haspopup":K,"aria-expanded":B}}var xc={clickable:"clickable_a02d56f501",disabled:"disabled_4fa676c362",disableTextSelection:"disableTextSelection_4de40c5810"};(function(t){const i="s_id-8d33a9ee9e1f_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.clickable_a02d56f501 {
  cursor: pointer;
}
.clickable_a02d56f501:focus-visible, .clickable_a02d56f501.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px hsla(209, 100%, 50%, 0.5), 0 0 0 1px var(--primary-hover-color) inset;
}
.clickable_a02d56f501:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.clickable_a02d56f501.disabled_4fa676c362 {
  cursor: default;
}
.disableTextSelection_4de40c5810 {
  -webkit-touch-callout: none; /* iOS Safari */ /* Safari */ /* Konqueror HTML */ /* Old versions of Firefox */ /* Internet Explorer/Edge */
  user-select: none; /* Non-prefixed version, currently supported by Chrome, Edge, Opera and Firefox */
}`);var S2=k.forwardRef(function(t,i){var o=t.elementType,l=o===void 0?"div":o,c=t.className,d=c===void 0?"":c,p=t.children,f=t.role,m=t.onClick,h=t.enableTextSelection,g=h!==void 0&&h,y=t.onMouseDown,b=t.onMouseEnter,w=t.onMouseLeave,N=t.tabIndex,L=t.disabled,O=L!==void 0&&L,R=t.style,M=E2({onClick:m===void 0?Zr:m,onMouseDown:y===void 0?Zr:y,onMouseEnter:b===void 0?Zr:b,onMouseLeave:w===void 0?Zr:w,disabled:O,id:t.id,"data-testid":t["data-testid"],role:f===void 0?"button":f,tabIndex:N===void 0?"0":N,ariaLabel:t.ariaLabel,ariaHidden:t.ariaHidden,ariaHasPopup:t.ariaHasPopup,ariaExpanded:t.ariaExpanded},i),z=ue(xc.clickable,d,se(se({},xc.disabled,O),xc.disableTextSelection,!g));return D.createElement(l,Object.assign(Object.assign({},M),{className:z,style:R}),p)}),zc,Fc,Xc,Uc;(function(t){t.START="start",t.CENTER="center",t.END="end",t.STRETCH="stretch",t.BASELINE="baseline",t.INITIAL="initial"})(zc||(zc={})),function(t){t.START="start",t.CENTER="center",t.END="end",t.STRETCH="stretch",t.SPACE_AROUND="space-around",t.SPACE_BETWEEN="space-between",t.INITIAL="initial"}(Fc||(Fc={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"}(Xc||(Xc={})),function(t){t.ROW="row",t.COLUMN="column"}(Uc||(Uc={}));var ni={container:"container_c4387f8d23",justifyStart:"justifyStart_47ecae744f",justifyEnd:"justifyEnd_cdd667668f",justifyCenter:"justifyCenter_d07dd6ace5",justifySpaceBetween:"justifySpaceBetween_02caeabcbc",justifySpaceAround:"justifySpaceAround_f6db42193c",justifyInital:"justifyInital_d0e7446b29",alignStart:"alignStart_56774cf1d9",alignEnd:"alignEnd_fd4ce75565",alignCenter:"alignCenter_3da6c9f81e",alignStretch:"alignStretch_9ed16b1b82",alignBaseline:"alignBaseline_886e5916c1",alignInitial:"alignInitial_05b412f7ba",directionColumn:"directionColumn_9f72e2abb7",wrap:"wrap_af3f9bed79"};(function(t){const i="s_id-3ad7193e0a34_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.container_c4387f8d23 {
  display: flex;
  flex-direction: row;
}
.container_c4387f8d23.justifyStart_47ecae744f {
  justify-content: flex-start;
}
.container_c4387f8d23.justifyEnd_cdd667668f {
  justify-content: flex-end;
}
.container_c4387f8d23.justifyCenter_d07dd6ace5 {
  justify-content: center;
}
.container_c4387f8d23.justifySpaceBetween_02caeabcbc {
  justify-content: space-between;
}
.container_c4387f8d23.justifySpaceAround_f6db42193c {
  justify-content: space-around;
}
.container_c4387f8d23.justifyInital_d0e7446b29 {
  justify-content: initial;
}
.container_c4387f8d23.alignStart_56774cf1d9 {
  align-items: flex-start;
}
.container_c4387f8d23.alignEnd_fd4ce75565 {
  align-items: flex-end;
}
.container_c4387f8d23.alignCenter_3da6c9f81e {
  align-items: center;
}
.container_c4387f8d23.alignStretch_9ed16b1b82 {
  align-items: stretch;
}
.container_c4387f8d23.alignBaseline_886e5916c1 {
  align-items: baseline;
}
.container_c4387f8d23.alignInitial_05b412f7ba {
  align-items: initial;
}
.container_c4387f8d23.directionColumn_9f72e2abb7 {
  flex-direction: column;
}
.container_c4387f8d23.wrap_af3f9bed79 {
  flex-wrap: wrap;
}`);var Hc=zt(k.forwardRef(function(t,i){var o=t.className,l=t.id,c=t.elementType,d=c===void 0?"div":c,p=t.direction,f=p===void 0?"row":p,m=t.wrap,h=m!==void 0&&m,g=t.children,y=t.justify,b=y===void 0?"start":y,w=t.align,N=w===void 0?"center":w,L=t.flex,O=t.gap,R=t.onClick,M=t.style,z=t.ariaLabelledby,I=t.ariaLabel,B=t.tabIndex,j=t["data-testid"],X=k.useRef(null),K=$t(i,X),ce=k.useMemo(function(){if(O)return typeof O=="number"?{gap:"".concat(O,"px")}:{gap:"var(--spacing-".concat(O,")")}},[O]),Q=k.useMemo(function(){return L?["string","number"].includes(fr(L))?{flex:L}:fr(L)==="object"?{flexGrow:L.grow,flexShrink:L.shrink,flexBasis:L.basis}:{}:{}},[L]),Z=k.useMemo(function(){return Object.assign(Object.assign(Object.assign({},M),ce),Q)},[M,ce,Q]),le=k.useMemo(function(){return R?{elementType:d,ariaLabelledby:z}:{"aria-labelledby":z}},[R,d,z]);return D.createElement(R?S2:d,Object.assign({id:l,"data-testid":j},le,{ref:K,className:ue(ni.container,Xe(ni,Qe("direction-".concat(f))),Xe(ni,Qe("justify-".concat(b))),Xe(ni,Qe("align-".concat(N))),o,se({},ni.wrap,h)),tabIndex:B,onClick:R,style:Z,"aria-label":I}),g)}),{justify:Fc,align:zc,gaps:Xc,directions:Uc}),Gr={lastTooltipHideTS:null,openTooltipsCount:0},at=function(t){function i(o){var l;return ov(this,i),(l=tv(this,i,[o])).renderTooltipContent=l.renderTooltipContent.bind(l),l.getShowDelay=l.getShowDelay.bind(l),l.onTooltipShow=l.onTooltipShow.bind(l),l.onTooltipHide=l.onTooltipHide.bind(l),l.wasShown=!1,l}return av(i,k.PureComponent),iv(i,[{key:"renderTooltipContent",value:function(){var o,l=this.props,c=l.theme,d=l.content,p=l.className,f=l.style,m=l.maxWidth,h=l.title,g=l.image,y=l.icon,b=l.dir;return d?(rl(d)?o=d():(k.isValidElement(d)||typeof d=="string"&&d||Array.isArray(d)&&d.length>0)&&(o=d),o?D.createElement("div",{style:m?Object.assign(Object.assign({},f),{"--tooltip-max-width":"".concat(m,"px")}):f,className:ue(or.tooltip,Xe(or,Qe(c)),p),dir:b},g&&D.createElement("img",{className:or.image,src:g,alt:""}),D.createElement("div",{className:ue(or.content)},h&&D.createElement(Hc,{gap:"xs"},y&&D.createElement(Qt,{iconSize:"20",icon:y}),D.createElement("div",{className:or.title},h)),o)):null):null}},{key:"onTooltipShow",value:function(){if(!this.wasShown){var o=this.props.onTooltipShow;Gr.openTooltipsCount++,this.wasShown=!0,o&&o()}}},{key:"onTooltipHide",value:function(){if(this.wasShown){var o=this.props.onTooltipHide;Gr.lastTooltipHideTS=Date.now(),Gr.openTooltipsCount--,this.wasShown=!1,o&&o()}}},{key:"getTimeSinceLastTooltip",value:function(){return Gr.openTooltipsCount>0?0:Gr.lastTooltipHideTS?Date.now()-Gr.lastTooltipHideTS:1/0}},{key:"getShowDelay",value:function(){var o=this.props,l=o.showDelay,c=o.immediateShowDelay,d=this.getTimeSinceLastTooltip();return(c===0||c)&&1500>d?{showDelay:c,preventAnimation:!0}:{showDelay:l,preventAnimation:!1}}},{key:"render",value:function(){var o=this.props,l=o.children,c=o.theme,d=o.tip,p=o.arrowClassName,f=o.id,m=o["data-testid"],h=o.position;if(!l&&!o.forceRenderWithoutChildren)return null;if(o.withoutDialog)return this.renderTooltipContent();var g=this.renderTooltipContent,y=Object.assign(Object.assign({},this.props),{position:h,"data-testid":m||De(pn.TOOLTIP,f),tooltip:d,content:g,tooltipClassName:ue(or.arrow,Xe(or,c),p),onDialogDidHide:this.onTooltipHide,onDialogDidShow:this.onTooltipShow,getDynamicShowDelay:this.getShowDelay});return D.createElement(un,Object.assign({},y,{animationType:"expand"}),l)}}])}();at.positions=jc,at.hideShowTriggers=ur,at.themes=$c,at.animationTypes=hi,at.defaultProps={moveBy:{main:4,secondary:0},theme:"dark",position:"top",hideDelay:100,showDelay:300,disableDialogSlide:!0,animationType:hi.EXPAND,withoutDialog:!1,tip:!0,hideWhenReferenceHidden:!1,modifiers:[],showTrigger:at.hideShowTriggers.MOUSE_ENTER,hideTrigger:at.hideShowTriggers.MOUSE_LEAVE,showOnDialogEnter:!0,referenceWrapperClassName:"",addKeyboardHideShowTriggersByDefault:!0,open:!1};var w2=D.createContext({overflowTolerance:0}),C2=k.forwardRef(function(t,i){var o=t.className,l=t.id,c=t.children,d=t.tooltipProps,p=t["data-testid"],f=p===void 0?De(Ze.TEXT,l):p,m=t.element,h=m===void 0?"span":m,g=t.color,y=g===void 0?"primary":g,b=t.align,w=b===void 0?"start":b,N=t.ellipsis,L=N===void 0||N,O=t.maxLines,R=O===void 0?1:O,M=t.withoutTooltip,z=M!==void 0&&M,I=t.role,B=co(t,["className","id","children","tooltipProps","data-testid","element","color","align","ellipsis","maxLines","withoutTooltip","role"]),j=k.useContext(w2).overflowTolerance,X=k.useRef(null),K=$t(i,X),ce=R===1,Q=zb(L,R),Z=Q.class,le=Q.style,de=Fb(X,z,L,d,c,ce,j),oe=w==="inherit"?"alignInherit":w;return D.createElement(at,Object.assign({},de),D.createElement(h,Object.assign({id:l,style:le,"data-testid":f,className:ue(ci.typography,ci[y],ci[oe],Z,o),ref:K,role:I},B),c))}),Wc,Vc;(function(t){t.PRIMARY="primary",t.SECONDARY="secondary",t.ON_PRIMARY="onPrimary",t.ON_INVERTED="onInverted",t.FIXED_LIGHT="fixedLight",t.FIXED_DARK="fixedDark",t.INHERIT="inherit",t.NEGATIVE="negative"})(Wc||(Wc={})),function(t){t.START="start",t.CENTER="center",t.END="end",t.INHERIT="inherit"}(Vc||(Vc={}));var $m={text1Bold:"text1Bold_55da83707c",text1Medium:"text1Medium_48b000a595",text1Normal:"text1Normal_3057fa2a8b",text2Bold:"text2Bold_6e3e14ff64",text2Medium:"text2Medium_3602a7ed9d",text2Normal:"text2Normal_2aa41ff154",text3Bold:"text3Bold_8377677634",text3Medium:"text3Medium_47f94d2806",text3Normal:"text3Normal_5a064de678",text:"text_d10f128325"};(function(t){const i="s_id-0b8dab5fe88c_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.text1Bold_55da83707c {
  font: var(--font-text1-bold);
}

.text1Medium_48b000a595 {
  font: var(--font-text1-medium);
}

.text1Normal_3057fa2a8b {
  font: var(--font-text1-normal);
}

.text2Bold_6e3e14ff64 {
  font: var(--font-text2-bold);
}

.text2Medium_3602a7ed9d {
  font: var(--font-text2-medium);
}

.text2Normal_2aa41ff154 {
  font: var(--font-text2-normal);
}

.text3Bold_8377677634 {
  font: var(--font-text3-bold);
}

.text3Medium_47f94d2806 {
  font: var(--font-text3-medium);
}

.text3Normal_5a064de678 {
  font: var(--font-text3-normal);
}

p:first-of-type.text_d10f128325 {
  margin-block: 0;
}

p.text_d10f128325 + p {
  margin-block-start: var(--spacing-large);
  margin-block-end: 0;
}`);var cl=zt(k.forwardRef(function(t,i){var o=t.className,l=t.type,c=l===void 0?"text2":l,d=t.weight,p=d===void 0?"normal":d,f=t.ellipsis,m=t.element,h=m===void 0?"div":m,g=t.children,y=co(t,["className","type","weight","ellipsis","element","children"]),b=f??h!=="p";return D.createElement(C2,Object.assign({ref:i,className:ue($m.text,Xe($m,Qe(c+"-"+p)),o),ellipsis:b,element:h},y),g)}),{types:Va,weights:Ga,colors:Wc,align:Vc});function uo(t,i){var o={};for(var l in t)Object.prototype.hasOwnProperty.call(t,l)&&0>i.indexOf(l)&&(o[l]=t[l]);if(t!=null&&typeof Object.getOwnPropertySymbols=="function"){var c=0;for(l=Object.getOwnPropertySymbols(t);l.length>c;c++)0>i.indexOf(l[c])&&Object.prototype.propertyIsEnumerable.call(t,l[c])&&(o[l[c]]=t[l[c]])}return o}var zm=se(se(se(se(se({},qr.XXS,16),qr.XS,24),qr.SMALL,32),qr.MEDIUM,40),qr.LARGE,48);function T2(t){return{width:"".concat(zm[t],"px"),height:"".concat(zm[t],"px")}}var Gc,Kc;(function(t){t.PRIMARY="primary",t.SECONDARY="secondary",t.ON_PRIMARY="onPrimary",t.DARK="dark"})(Gc||(Gc={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"}(Kc||(Kc={}));var Ra={loaderContainer:"loaderContainer_11a9599e6a",circleLoaderSpinnerBackground:"circleLoaderSpinnerBackground_f33a73fad4",circleLoaderSpinner:"circleLoaderSpinner_1b3ec5f80f",circleLoaderSpinnerPath:"circleLoaderSpinnerPath_eb8a0279c6"};(function(t){const i="s_id-dcd4d8f866fa_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.loaderContainer_11a9599e6a {
  position: relative;
  height: 100%;
  width: 100%;
}
.loaderContainer_11a9599e6a .circleLoaderSpinnerBackground_f33a73fad4 {
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -50%;
  margin-left: -50%;
  stroke: var(--ui-background-color);
}
.loaderContainer_11a9599e6a .circleLoaderSpinner_1b3ec5f80f {
  animation: rotate_0582aa6bdd 1s linear infinite;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -50%;
  margin-left: -50%;
  stroke: currentColor;
  stroke-linecap: round;
}
.loaderContainer_11a9599e6a .circleLoaderSpinner_1b3ec5f80f .circleLoaderSpinnerPath_eb8a0279c6 {
  animation: dash_dbfa4566ae 1s infinite;
}
@keyframes rotate_0582aa6bdd {
  100% {
    transform: rotate(360deg);
  }
}
@keyframes dash_dbfa4566ae {
  0% {
    stroke-dasharray: 1, 150;
    stroke-dashoffset: 0;
  }
  50% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -35;
  }
  100% {
    stroke-dasharray: 90, 150;
    stroke-dashoffset: -124;
  }
}`);var O2={xs:16,small:24,medium:40,large:64},Fm={primary:"primary-color",secondary:"secondary-text-color",onPrimary:"text-color-on-inverted",dark:"primary-text-color"},A2=zt(k.forwardRef(function(t,i){var o=t.className,l=t.wrapperClassName,c=t.size,d=t.color,p=t.hasBackground,f=p!==void 0&&p,m=t.id,h=t["data-testid"],g=k.useMemo(function(){var b=typeof c=="string"?O2[c]:c;if(typeof b=="number")return{width:b,height:b}},[c]),y=k.useMemo(function(){if(Fm[d])return"var(--".concat(Fm[d],")")},[d]);return D.createElement("div",{className:ue(Ra.loaderContainer,l),ref:i,role:"alert",title:"loading",style:g,id:m,"data-testid":h||De(Ze.LOADER,m)},D.createElement("svg",{className:ue(Ra.circleLoaderSpinner,o),viewBox:"0 0 50 50",color:y,"aria-hidden":!0},f&&D.createElement("circle",{className:Ra.circleLoaderSpinnerBackground,cx:"25",cy:"25",r:"20",fill:"none",strokeWidth:"5"}),D.createElement("circle",{className:Ra.circleLoaderSpinnerPath,cx:"25",cy:"25",r:"20",fill:"none",strokeWidth:"5"})))}),{sizes:Kc,colors:Gc}),Yc,qc;(function(t){t.PRIMARY="primary",t.SECONDARY="secondary",t.TERTIARY="tertiary"})(Yc||(Yc={})),function(t){t.PRIMARY="primary",t.POSITIVE="positive",t.NEGATIVE="negative",t.INVERTED="inverted",t.ON_PRIMARY_COLOR="on-primary-color",t.ON_INVERTED_BACKGROUND="on-inverted-background",t.BRAND="brand",t.FIXED_LIGHT="fixed-light",t.FIXED_DARK="fixed-dark"}(qc||(qc={}));var qa,oh=16,ih=20;(function(t){t.BUTTON="button",t.SUBMIT="submit",t.RESET="reset"})(qa||(qa={}));var ah="rgba(0, 0, 0, 0)";function lh(t,i){var o=t.parentElement;if(t===t.parentElement)return t?window.getComputedStyle(t).backgroundColor:i;if(!o)return i;var l=window.getComputedStyle(o).backgroundColor;return l&&l!==i?l===ah?i:l:lh(o,i)}var Be={button:"button_843ba7af12","focus-visible":"focus-visible_b0a5cd5036",loader:"loader_bdc5443a80",loaderSvg:"loaderSvg_e2b836a808",textPlaceholder:"textPlaceholder_f70e5dfed7",success:"success_f010d30c98",successContent:"successContent_f885b866b2",marginRight:"marginRight_9c92793f4c",marginLeft:"marginLeft_8370ecdf48",rightFlat:"rightFlat_204f8159a0",leftFlat:"leftFlat_ca94a2766a",preventClickAnimation:"preventClickAnimation_9219b53093",leftIcon:"leftIcon_9c92793f4c",rightIcon:"rightIcon_8370ecdf48",sizeXxs:"sizeXxs_c5f4314fd8",sizeXs:"sizeXs_ff605da52d",sizeSmall:"sizeSmall_c00c6dce7d",sizeMedium:"sizeMedium_c0b6e12605",sizeLarge:"sizeLarge_deb09333c0",kindPrimary:"kindPrimary_e3d5c4d9dc",colorPrimary:"colorPrimary_00e85329cd",colorBrand:"colorBrand_b3846f317f",colorPrimaryActive:"colorPrimaryActive_dac512a074",colorBrandActive:"colorBrandActive_51db81a8db",colorPositive:"colorPositive_b65ebb4abb",colorPositiveActive:"colorPositiveActive_e3b3f36f50",colorNegative:"colorNegative_a4392aa3ab",colorNegativeActive:"colorNegativeActive_e3b3f36f50",colorInverted:"colorInverted_359f0a3190",colorInvertedActive:"colorInvertedActive_e3b3f36f50",disabled:"disabled_4ceaae39df",colorOnPrimaryColor:"colorOnPrimaryColor_01cc64e466",colorOnPrimaryColorActive:"colorOnPrimaryColorActive_a060ee344b",colorFixedLight:"colorFixedLight_bd1adf1622",colorFixedLightActive:"colorFixedLightActive_9219b53093",colorFixedDark:"colorFixedDark_fbb12152e0",colorFixedDarkActive:"colorFixedDarkActive_45a060b248",colorOnInvertedBackground:"colorOnInvertedBackground_a44b9ff663",colorOnInvertedBackgroundActive:"colorOnInvertedBackgroundActive_7211b59360",kindSecondary:"kindSecondary_ddd7192eb4",kindTertiary:"kindTertiary_44f3875933",noSidePadding:"noSidePadding_14f8fde724",insetFocusStyle:"insetFocusStyle_64a94ab4ab"};(function(t){const i="s_id-f5db469b1a79_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.button_843ba7af12 {
  --loader-padding: 8px;
  outline: none;
  border: none;
  height: auto;
  border-radius: var(--border-radius-small);
  cursor: pointer;
  white-space: nowrap;
  transition: var(--motion-productive-short) transform, var(--motion-productive-medium) var(--motion-timing-transition) min-width;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  /* Prevent text selection */
  user-select: none;
  min-width: auto;
}
.button_843ba7af12:focus-visible, .button_843ba7af12.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px hsla(209, 100%, 50%, 0.5), 0 0 0 1px var(--primary-hover-color) inset;
}
.button_843ba7af12:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.button_843ba7af12 .loader_bdc5443a80 {
  height: 100%;
}
.button_843ba7af12 .loader_bdc5443a80 .loaderSvg_e2b836a808 {
  position: static;
  height: 100%;
  margin: 0;
}
.button_843ba7af12 .textPlaceholder_f70e5dfed7 {
  display: inline-block;
  opacity: 0;
  height: 0;
  visibility: hidden;
  white-space: pre;
}
.button_843ba7af12.success_f010d30c98 {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.button_843ba7af12.success_f010d30c98 .successContent_f885b866b2 {
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
.marginRight_9c92793f4c {
  margin-right: var(--spacing-small);
}
.marginLeft_8370ecdf48 {
  margin-left: var(--spacing-small);
}
.rightFlat_204f8159a0 {
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
}
.leftFlat_ca94a2766a {
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.button_843ba7af12:active:not(.preventClickAnimation_9219b53093) {
  transform: scale(0.95) translate3d(0, 0, 0);
}
.button_843ba7af12 .leftIcon_9c92793f4c {
  margin-right: var(--spacing-small);
}
.button_843ba7af12 .rightIcon_8370ecdf48 {
  margin-left: var(--spacing-small);
}
.sizeXxs_c5f4314fd8 {
  -webkit-font-smoothing: var(--font-smoothing-webkit);
  -moz-osx-font-smoothing: var(--font-smoothing-moz);
  font: var(--font-text2-normal);
  padding: 2px var(--spacing-xs);
  height: 16px;
  line-height: 16px;
}
.sizeXs_ff605da52d {
  -webkit-font-smoothing: var(--font-smoothing-webkit);
  -moz-osx-font-smoothing: var(--font-smoothing-moz);
  font: var(--font-text2-normal);
  padding: var(--spacing-xs) var(--spacing-small);
  height: 24px;
  line-height: 21px;
}
.sizeSmall_c00c6dce7d {
  -webkit-font-smoothing: var(--font-smoothing-webkit);
  -moz-osx-font-smoothing: var(--font-smoothing-moz);
  font: var(--font-text2-normal);
  padding: var(--spacing-xs) var(--spacing-small);
  height: 32px;
  line-height: 24px;
}
.sizeSmall_c00c6dce7d .loader_bdc5443a80 {
  top: 7px;
}
.sizeMedium_c0b6e12605 {
  -webkit-font-smoothing: var(--font-smoothing-webkit);
  -moz-osx-font-smoothing: var(--font-smoothing-moz);
  font: var(--font-text1-normal);
  padding: var(--spacing-small) var(--spacing-medium);
  height: 40px;
}
.sizeLarge_deb09333c0 {
  -webkit-font-smoothing: var(--font-smoothing-webkit);
  -moz-osx-font-smoothing: var(--font-smoothing-moz);
  font: var(--font-text1-normal);
  padding: 12px var(--spacing-large);
  height: 48px;
}
.kindPrimary_e3d5c4d9dc {
  color: var(--text-color-on-primary);
}
.kindPrimary_e3d5c4d9dc.colorPrimary_00e85329cd {
  background: var(--primary-color);
}
.kindPrimary_e3d5c4d9dc.colorBrand_b3846f317f {
  background: var(--brand-color);
  color: var(--text-color-on-brand);
}
.kindPrimary_e3d5c4d9dc.colorPrimaryActive_dac512a074,
.kindPrimary_e3d5c4d9dc.colorPrimary_00e85329cd:hover,
.kindPrimary_e3d5c4d9dc.colorPrimary_00e85329cd:focus {
  background: var(--primary-hover-color);
}
.kindPrimary_e3d5c4d9dc.colorBrandActive_51db81a8db,
.kindPrimary_e3d5c4d9dc.colorBrand_b3846f317f:hover,
.kindPrimary_e3d5c4d9dc.colorBrand_b3846f317f:focus {
  background: var(--brand-hover-color);
}
.kindPrimary_e3d5c4d9dc.colorPositive_b65ebb4abb {
  background: var(--positive-color);
}
.kindPrimary_e3d5c4d9dc.colorPositiveActive_e3b3f36f50,
.kindPrimary_e3d5c4d9dc.colorPositive_b65ebb4abb:hover,
.kindPrimary_e3d5c4d9dc.colorPositive_b65ebb4abb:focus {
  background: var(--positive-color-hover);
}
.kindPrimary_e3d5c4d9dc.colorNegative_a4392aa3ab {
  background: var(--negative-color);
}
.kindPrimary_e3d5c4d9dc.colorNegativeActive_e3b3f36f50,
.kindPrimary_e3d5c4d9dc.colorNegative_a4392aa3ab:hover,
.kindPrimary_e3d5c4d9dc.colorNegative_a4392aa3ab:focus {
  background: var(--negative-color-hover);
}
.kindPrimary_e3d5c4d9dc.colorInverted_359f0a3190 {
  background: var(--inverted-color-background);
  color: var(--text-color-on-inverted);
}
.kindPrimary_e3d5c4d9dc.colorInvertedActive_e3b3f36f50,
.kindPrimary_e3d5c4d9dc.colorInverted_359f0a3190:hover,
.kindPrimary_e3d5c4d9dc.colorInverted_359f0a3190:focus {
  background: var(--placeholder-color);
}
.kindPrimary_e3d5c4d9dc.button_843ba7af12.colorInverted_359f0a3190.disabled_4ceaae39df {
  background: var(--disabled-text-color);
  color: var(--disabled-background-color);
}
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466 {
  background: var(--text-color-on-primary);
}
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColorActive_a060ee344b,
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:hover,
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:focus {
  background-color: #e6e9ef;
  backdrop-filter: brightness(85%);
}
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColorActive_a060ee344b:focus-visible, .kindPrimary_e3d5c4d9dc.colorOnPrimaryColorActive_a060ee344b.focus-visible_b0a5cd5036,
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:hover:focus-visible,
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:hover.focus-visible_b0a5cd5036,
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:focus:focus-visible,
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColorActive_a060ee344b:focus:not(.focus-visible_b0a5cd5036),
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:hover:focus:not(.focus-visible_b0a5cd5036),
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindPrimary_e3d5c4d9dc.colorOnPrimaryColor_01cc64e466.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--text-color-on-primary);
}
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622 {
  background: var(--fixed-light-color);
}
.kindPrimary_e3d5c4d9dc.colorFixedLightActive_9219b53093,
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:hover,
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:focus {
  background-color: #e6e9ef;
  backdrop-filter: brightness(85%);
}
.kindPrimary_e3d5c4d9dc.colorFixedLightActive_9219b53093:focus-visible, .kindPrimary_e3d5c4d9dc.colorFixedLightActive_9219b53093.focus-visible_b0a5cd5036,
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:hover:focus-visible,
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:hover.focus-visible_b0a5cd5036,
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:focus:focus-visible,
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindPrimary_e3d5c4d9dc.colorFixedLightActive_9219b53093:focus:not(.focus-visible_b0a5cd5036),
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:hover:focus:not(.focus-visible_b0a5cd5036),
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindPrimary_e3d5c4d9dc.colorFixedLight_bd1adf1622.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--fixed-light-color);
}
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0 {
  background: var(--fixed-dark-color);
  color: var(--fixed-light-color);
}
.kindPrimary_e3d5c4d9dc.colorFixedDarkActive_45a060b248,
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:hover,
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:focus {
  filter: brightness(125%);
}
.kindPrimary_e3d5c4d9dc.colorFixedDarkActive_45a060b248:focus-visible, .kindPrimary_e3d5c4d9dc.colorFixedDarkActive_45a060b248.focus-visible_b0a5cd5036,
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:hover:focus-visible,
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:hover.focus-visible_b0a5cd5036,
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:focus:focus-visible,
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindPrimary_e3d5c4d9dc.colorFixedDarkActive_45a060b248:focus:not(.focus-visible_b0a5cd5036),
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:hover:focus:not(.focus-visible_b0a5cd5036),
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindPrimary_e3d5c4d9dc.colorFixedDark_fbb12152e0.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--fixed-dark-color);
}
.kindPrimary_e3d5c4d9dc.colorOnInvertedBackground_a44b9ff663 {
  background: var(--primary-background-color);
  color: var(--primary-text-color);
}
.kindPrimary_e3d5c4d9dc.colorOnInvertedBackgroundActive_7211b59360,
.kindPrimary_e3d5c4d9dc.colorOnInvertedBackground_a44b9ff663:hover,
.kindPrimary_e3d5c4d9dc.colorOnInvertedBackground_a44b9ff663:focus {
  background: var(--ui-background-color);
}
.kindPrimary_e3d5c4d9dc.button_843ba7af12.colorOnInvertedBackground_a44b9ff663.disabled_4ceaae39df {
  background: var(--ui-background-color);
  color: var(--primary-text-color);
  opacity: 0.5;
}
.kindPrimary_e3d5c4d9dc.button_843ba7af12.disabled_4ceaae39df {
  background: var(--disabled-background-color);
  color: var(--disabled-text-color);
  cursor: not-allowed;
  pointer-events: none;
}
.kindSecondary_ddd7192eb4 {
  border: 1px solid;
  border-color: var(--ui-border-color);
  color: var(--primary-text-color);
  background-color: transparent;
}
.kindSecondary_ddd7192eb4.sizeSmall_c00c6dce7d {
  line-height: 22px;
}
.kindSecondary_ddd7192eb4.sizeMedium_c0b6e12605 {
  line-height: 22px;
}
.kindSecondary_ddd7192eb4.sizeLarge_deb09333c0 {
  line-height: 22px;
}
.kindSecondary_ddd7192eb4.colorPrimaryActive_dac512a074 {
  background-color: var(--primary-selected-color);
  border-color: var(--primary-color);
}
.kindSecondary_ddd7192eb4.colorPrimaryActive_dac512a074:hover {
  background-color: var(--primary-selected-hover-color);
  border-color: var(--primary-color);
}
.kindSecondary_ddd7192eb4.colorBrandActive_51db81a8db {
  color: var(--text-color-on-brand);
}
.kindSecondary_ddd7192eb4.colorBrandActive_51db81a8db,
.kindSecondary_ddd7192eb4.colorBrandActive_51db81a8db:hover {
  background-color: var(--brand-selected-color);
  border-color: var(--brand-color);
}
.kindSecondary_ddd7192eb4.colorPrimary_00e85329cd:hover:not(.colorPrimaryActive_dac512a074),
.kindSecondary_ddd7192eb4.colorPrimary_00e85329cd:focus:not(.colorPrimaryActive_dac512a074) {
  background: var(--primary-background-hover-color);
}
.kindSecondary_ddd7192eb4.colorBrand_b3846f317f:hover:not(.colorBrandActive_51db81a8db),
.kindSecondary_ddd7192eb4.colorBrand_b3846f317f:focus:not(.colorBrandActive_51db81a8db) {
  background: var(--primary-background-hover-color);
}
.kindSecondary_ddd7192eb4.colorPositive_b65ebb4abb {
  color: var(--positive-color);
  border-color: var(--positive-color);
}
.kindSecondary_ddd7192eb4.colorPositiveActive_e3b3f36f50,
.kindSecondary_ddd7192eb4.colorPositive_b65ebb4abb:hover,
.kindSecondary_ddd7192eb4.colorPositive_b65ebb4abb:focus {
  background: var(--positive-color-selected);
}
.kindSecondary_ddd7192eb4.colorNegative_a4392aa3ab {
  color: var(--negative-color);
  border-color: var(--negative-color);
}
.kindSecondary_ddd7192eb4.colorNegativeActive_e3b3f36f50,
.kindSecondary_ddd7192eb4.colorNegative_a4392aa3ab:hover,
.kindSecondary_ddd7192eb4.colorNegative_a4392aa3ab:focus {
  background: var(--negative-color-selected);
}
.kindSecondary_ddd7192eb4.colorInverted_359f0a3190 {
  color: var(--primary-text-color);
  border-color: var(--primary-text-color);
}
.kindSecondary_ddd7192eb4.colorInvertedActive_e3b3f36f50,
.kindSecondary_ddd7192eb4.colorInverted_359f0a3190:hover,
.kindSecondary_ddd7192eb4.colorInverted_359f0a3190:focus {
  background: var(--primary-background-hover-color);
}
.kindSecondary_ddd7192eb4.colorInverted_359f0a3190.disabled_4ceaae39df {
  border-color: var(--disabled-text-color);
  color: var(--disabled-text-color);
}
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466 {
  color: var(--text-color-on-primary);
  border-color: var(--text-color-on-primary);
}
.kindSecondary_ddd7192eb4.colorOnPrimaryColorActive_a060ee344b,
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:hover,
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:focus {
  backdrop-filter: brightness(85%);
}
.kindSecondary_ddd7192eb4.colorOnPrimaryColorActive_a060ee344b:focus-visible, .kindSecondary_ddd7192eb4.colorOnPrimaryColorActive_a060ee344b.focus-visible_b0a5cd5036,
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:hover:focus-visible,
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:hover.focus-visible_b0a5cd5036,
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:focus:focus-visible,
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindSecondary_ddd7192eb4.colorOnPrimaryColorActive_a060ee344b:focus:not(.focus-visible_b0a5cd5036),
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:hover:focus:not(.focus-visible_b0a5cd5036),
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindSecondary_ddd7192eb4.colorOnPrimaryColor_01cc64e466.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--text-color-on-primary);
}
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622 {
  border-color: var(--fixed-light-color);
  color: var(--fixed-light-color);
}
.kindSecondary_ddd7192eb4.colorFixedLightActive_9219b53093,
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:hover,
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:focus {
  backdrop-filter: brightness(85%);
}
.kindSecondary_ddd7192eb4.colorFixedLightActive_9219b53093:focus-visible, .kindSecondary_ddd7192eb4.colorFixedLightActive_9219b53093.focus-visible_b0a5cd5036,
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:hover:focus-visible,
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:hover.focus-visible_b0a5cd5036,
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:focus:focus-visible,
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindSecondary_ddd7192eb4.colorFixedLightActive_9219b53093:focus:not(.focus-visible_b0a5cd5036),
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:hover:focus:not(.focus-visible_b0a5cd5036),
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0 {
  border-color: var(--fixed-dark-color);
  color: var(--fixed-dark-color);
}
.kindSecondary_ddd7192eb4.colorFixedDarkActive_45a060b248,
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:hover,
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:focus {
  background-color: var(--primary-background-hover-color);
}
.kindSecondary_ddd7192eb4.colorFixedDarkActive_45a060b248:focus-visible, .kindSecondary_ddd7192eb4.colorFixedDarkActive_45a060b248.focus-visible_b0a5cd5036,
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:hover:focus-visible,
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:hover.focus-visible_b0a5cd5036,
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:focus:focus-visible,
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindSecondary_ddd7192eb4.colorFixedDarkActive_45a060b248:focus:not(.focus-visible_b0a5cd5036),
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:hover:focus:not(.focus-visible_b0a5cd5036),
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindSecondary_ddd7192eb4.colorOnInvertedBackground_a44b9ff663 {
  border-color: var(--text-color-on-inverted);
  color: var(--text-color-on-inverted);
}
.kindSecondary_ddd7192eb4.colorOnInvertedBackgroundActive_7211b59360,
.kindSecondary_ddd7192eb4.colorOnInvertedBackground_a44b9ff663:hover,
.kindSecondary_ddd7192eb4.colorOnInvertedBackground_a44b9ff663:focus {
  background: var(--icon-color);
}
.kindSecondary_ddd7192eb4.colorOnInvertedBackground_a44b9ff663.disabled_4ceaae39df {
  border-color: var(--text-color-on-inverted);
  color: var(--text-color-on-inverted);
  opacity: 0.5;
}
.kindSecondary_ddd7192eb4.colorFixedLight_bd1adf1622.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--fixed-light-color);
}
.kindSecondary_ddd7192eb4.colorFixedDark_fbb12152e0.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--fixed-dark-color);
}
.kindSecondary_ddd7192eb4.disabled_4ceaae39df {
  border-color: var(--disabled-text-color);
  color: var(--disabled-text-color);
  cursor: not-allowed;
  pointer-events: none;
}
.kindSecondary_ddd7192eb4.disabled_4ceaae39df:hover {
  background-color: transparent;
}
.kindTertiary_44f3875933 {
  color: var(--primary-text-color);
  background-color: transparent;
}
.kindTertiary_44f3875933.colorPrimaryActive_dac512a074 {
  background-color: var(--primary-selected-color);
}
.kindTertiary_44f3875933.colorPrimaryActive_dac512a074:hover {
  background-color: var(--primary-selected-hover-color);
}
.kindTertiary_44f3875933.colorBrandActive_51db81a8db {
  color: var(--text-color-on-brand);
}
.kindTertiary_44f3875933.colorBrandActive_51db81a8db,
.kindTertiary_44f3875933.colorBrandActive_51db81a8db:hover {
  background-color: var(--brand-selected-color);
}
.kindTertiary_44f3875933.colorPrimary_00e85329cd:hover:not(.colorPrimaryActive_dac512a074),
.kindTertiary_44f3875933.colorPrimary_00e85329cd:focus:not(.colorPrimaryActive_dac512a074) {
  background: var(--primary-background-hover-color);
}
.kindTertiary_44f3875933.colorBrand_b3846f317f:hover:not(.colorBrandActive_51db81a8db),
.kindTertiary_44f3875933.colorBrand_b3846f317f:focus:not(.colorBrandActive_51db81a8db) {
  background: var(--primary-background-hover-color);
}
.kindTertiary_44f3875933.colorPositive_b65ebb4abb {
  color: var(--positive-color);
}
.kindTertiary_44f3875933.colorPositiveActive_e3b3f36f50,
.kindTertiary_44f3875933.colorPositive_b65ebb4abb:hover,
.kindTertiary_44f3875933.colorPositive_b65ebb4abb:focus {
  background: var(--positive-color-selected);
}
.kindTertiary_44f3875933.colorNegative_a4392aa3ab {
  color: var(--negative-color);
}
.kindTertiary_44f3875933.colorNegativeActive_e3b3f36f50,
.kindTertiary_44f3875933.colorNegative_a4392aa3ab:hover,
.kindTertiary_44f3875933.colorNegative_a4392aa3ab:focus {
  background: var(--negative-color-selected);
}
.kindTertiary_44f3875933.colorInverted_359f0a3190 {
  color: var(--primary-text-color);
}
.kindTertiary_44f3875933.colorInvertedActive_e3b3f36f50,
.kindTertiary_44f3875933.colorInverted_359f0a3190:hover,
.kindTertiary_44f3875933.colorInverted_359f0a3190:focus {
  background: var(--primary-background-hover-color);
}
.kindTertiary_44f3875933.colorInverted_359f0a3190.disabled_4ceaae39df {
  color: var(--disabled-text-color);
}
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466 {
  color: var(--text-color-on-primary);
}
.kindTertiary_44f3875933.colorOnPrimaryColorActive_a060ee344b,
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:hover,
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:focus {
  backdrop-filter: brightness(85%);
}
.kindTertiary_44f3875933.colorOnPrimaryColorActive_a060ee344b:focus-visible, .kindTertiary_44f3875933.colorOnPrimaryColorActive_a060ee344b.focus-visible_b0a5cd5036,
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:hover:focus-visible,
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:hover.focus-visible_b0a5cd5036,
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:focus:focus-visible,
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindTertiary_44f3875933.colorOnPrimaryColorActive_a060ee344b:focus:not(.focus-visible_b0a5cd5036),
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:hover:focus:not(.focus-visible_b0a5cd5036),
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindTertiary_44f3875933.colorOnPrimaryColor_01cc64e466.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--text-color-on-primary);
}
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622 {
  color: var(--fixed-light-color);
}
.kindTertiary_44f3875933.colorFixedLightActive_9219b53093,
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:hover,
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:focus {
  backdrop-filter: brightness(85%);
}
.kindTertiary_44f3875933.colorFixedLightActive_9219b53093:focus-visible, .kindTertiary_44f3875933.colorFixedLightActive_9219b53093.focus-visible_b0a5cd5036,
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:hover:focus-visible,
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:hover.focus-visible_b0a5cd5036,
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:focus:focus-visible,
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindTertiary_44f3875933.colorFixedLightActive_9219b53093:focus:not(.focus-visible_b0a5cd5036),
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:hover:focus:not(.focus-visible_b0a5cd5036),
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindTertiary_44f3875933.colorFixedLight_bd1adf1622.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--fixed-light-color);
}
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0 {
  color: var(--fixed-dark-color);
}
.kindTertiary_44f3875933.colorFixedDarkActive_45a060b248,
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:hover,
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:focus {
  background-color: var(--primary-background-hover-color);
}
.kindTertiary_44f3875933.colorFixedDarkActive_45a060b248:focus-visible, .kindTertiary_44f3875933.colorFixedDarkActive_45a060b248.focus-visible_b0a5cd5036,
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:hover:focus-visible,
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:hover.focus-visible_b0a5cd5036,
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:focus:focus-visible,
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:focus.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px var(--text-color-on-primary-with-opacity), 0 0 0 1px var(--text-color-on-primary) inset;
}
.kindTertiary_44f3875933.colorFixedDarkActive_45a060b248:focus:not(.focus-visible_b0a5cd5036),
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:hover:focus:not(.focus-visible_b0a5cd5036),
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0:focus:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.kindTertiary_44f3875933.colorFixedDark_fbb12152e0.disabled_4ceaae39df {
  opacity: 0.5;
  color: var(--fixed-dark-color);
}
.kindTertiary_44f3875933.colorOnInvertedBackground_a44b9ff663 {
  color: var(--text-color-on-inverted);
}
.kindTertiary_44f3875933.colorOnInvertedBackgroundActive_7211b59360,
.kindTertiary_44f3875933.colorOnInvertedBackground_a44b9ff663:hover,
.kindTertiary_44f3875933.colorOnInvertedBackground_a44b9ff663:focus {
  background: var(--icon-color);
}
.kindTertiary_44f3875933.colorOnInvertedBackground_a44b9ff663.disabled_4ceaae39df {
  background: var(--icon-color);
  opacity: 0.5;
  color: var(--text-color-on-inverted);
}
.kindTertiary_44f3875933.disabled_4ceaae39df {
  color: var(--disabled-text-color);
  cursor: not-allowed;
  pointer-events: none;
}
.kindTertiary_44f3875933.disabled_4ceaae39df:hover {
  background-color: transparent;
}
.noSidePadding_14f8fde724 {
  padding-right: 0;
  padding-left: 0;
}
.button_843ba7af12.insetFocusStyle_64a94ab4ab:focus-visible, .button_843ba7af12.insetFocusStyle_64a94ab4ab.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px hsla(209, 100%, 50%, 0.5) inset, 0 0 0 1px var(--primary-hover-color) inset;
}
.button_843ba7af12.insetFocusStyle_64a94ab4ab:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}`);function N2(t){var i=t.isLoading,o=k.useState(i),l=Tt(o,2),c=l[0],d=l[1];return k.useEffect(function(){var p=window.requestAnimationFrame(function(){d(i)});return function(){window.cancelAnimationFrame(p)}},[i]),{loading:c}}var sh=k.forwardRef(function(t,i){var o=t.className,l=t.children,c=t.kind,d=t.onClick,p=t.name,f=t.size,m=t.color,h=t.disabled,g=t.rightIcon,y=t.leftIcon,b=t.success,w=t.successText,N=t.successIcon,L=t.style,O=t.loading,R=t.loaderClassName,M=t.active,z=t.activeButtonClassName,I=t.id,B=t.marginRight,j=t.marginLeft,X=t.type,K=t.onMouseDown,ce=t.ariaLabel,Q=t.rightFlat,Z=t.leftFlat,le=t.preventClickAnimation,de=t.noSidePadding,oe=t.onFocus,ve=t.onBlur,re=t.ariaLabeledBy,fe=t.defaultTextColorOnPrimaryColor,H=t.ariaHasPopup,V=t.ariaExpanded,x=t.ariaControls,P=t["aria-describedby"],G=t["aria-hidden"],te=t["aria-pressed"],ie=t.blurOnMouseUp,ye=t["data-testid"],_e=t.insetFocus,be=t.tabIndex,Y=k.useRef(null),Se=$t(i,Y),Ne=N2({isLoading:O}).loading;k.useEffect(function(){if((m==="on-primary-color"||m==="fixed-light")&&c==="primary"&&Y.current){var Ie=Y.current;Ie.style.color=lh(Ie,fe)}},[c,Y,m,fe]);var Ue=k.useCallback(function(){var Ie=Y.current;!h&&Ie&&ie&&Ie.blur()},[h,Y,ie]),Ft=k.useCallback(function(Ie){h||Ne||b?Ie.preventDefault():d&&d(Ie)},[d,h,Ne,b]),vt=k.useCallback(function(Ie){h||Ne||b?Ie.preventDefault():K&&K(Ie)},[K,h,Ne,b]),hn=k.useMemo(function(){var Ie,Je=b?"positive":m;return ue(o,Be.button,Xe(Be,Qe("size-"+f)),Xe(Be,Qe("kind-"+c)),Xe(Be,Qe("color-"+Je)),(se(se(se(se(se(se(se(se(se(se(Ie={},Be.success,b),Xe(Be,Qe("color-"+Je+"-active")),M),z,M),Be.marginRight,B),Be.marginLeft,j),Be.rightFlat,Q),Be.leftFlat,Z),Be.preventClickAnimation,le),Be.noSidePadding,de),Be.disabled,h),se(Ie,Be.insetFocusStyle,_e)))},[b,m,o,f,c,M,z,B,j,Q,Z,le,de,h,_e]),gn=k.useMemo(function(){return{ref:Se,type:X,className:hn,name:p,onMouseUp:Ue,style:L,onClick:Ft,id:I,onFocus:oe,onBlur:ve,tabIndex:h||G?-1:be,"data-testid":ye||De(Ze.BUTTON,I),"data-vibe":pr.BUTTON,onMouseDown:vt,"aria-disabled":h,"aria-busy":Ne,"aria-labelledby":re,"aria-label":ce,"aria-haspopup":H,"aria-expanded":V,"aria-controls":x,"aria-describedby":P,"aria-hidden":G,"aria-pressed":te}},[Se,X,hn,p,Ue,L,Ft,I,oe,ve,be,ye,vt,h,Ne,re,ce,H,V,x,P,G,te]),Xt=k.useCallback(function(Ie){if(typeof Ie=="function")switch(f){case"xxs":case"xs":return oh;default:return ih}},[f]),Ut=k.useMemo(function(){return D.Children.toArray(l).some(Boolean)},[l]),yn=k.useMemo(function(){return D.createElement(D.Fragment,null,y?D.createElement(Qt,{iconType:"font",icon:y,iconSize:Xt(y),className:ue(se({},Be.leftIcon,Ut)),ignoreFocusStyle:!0}):null,l,g?D.createElement(Qt,{iconType:"font",icon:g,iconSize:Xt(g),className:ue(se({},Be.rightIcon,Ut)),ignoreFocusStyle:!0}):null)},[l,Ut,Xt,y,g]);return Ne?D.createElement("button",Object.assign({},gn,{key:"".concat(I,"-loading")}),D.createElement("span",{className:ue(Be.loader,R)},D.createElement(A2,{className:Be.loaderSvg}),D.createElement("span",{"aria-hidden":!0,className:Be.textPlaceholder},yn))):b?D.createElement("button",Object.assign({},gn,{key:"".concat(I,"-success")}),D.createElement("span",{className:Be.successContent},N?D.createElement(Qt,{iconType:"font",icon:N,iconSize:Xt(N),className:ue(se({},Be.leftIcon,!!w)),ignoreFocusStyle:!0}):null,w),D.createElement("span",{"aria-hidden":"true",className:Be.textPlaceholder},yn)):D.createElement("button",Object.assign({},gn,{key:"".concat(I,"-button")}),yn)});sh.defaultProps={name:void 0,style:void 0,kind:"primary",onClick:Fe,size:"medium",color:"primary",disabled:!1,rightIcon:null,leftIcon:null,success:!1,successText:"",successIcon:null,loading:!1,loaderClassName:void 0,active:!1,marginRight:!1,marginLeft:!1,type:"button",onMouseDown:Fe,rightFlat:!1,leftFlat:!1,preventClickAnimation:!1,noSidePadding:!1,onFocus:Fe,onBlur:Fe,defaultTextColorOnPrimaryColor:ah,ariaHasPopup:void 0,blurOnMouseUp:!0,ariaExpanded:void 0,ariaControls:void 0,ariaLabel:void 0,ariaLabeledBy:void 0,insetFocus:!1};var sr=zt(sh,{sizes:qr,colors:qc,kinds:Yc,types:qa,inputTags:qa}),Pa={wrapper:"wrapper_f445e98501",referenceWrapper:"referenceWrapper_fa2bf28443",loader:"loader_8f26746a2e",xxs:"xxs_09e0d54292"};(function(t){const i="s_id-8d1605f1f87b_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.wrapper_f445e98501 {
  width: fit-content;
  height: fit-content;
  display: inline-flex;
}

.referenceWrapper_fa2bf28443 {
  display: inline-flex;
}

.referenceWrapper_fa2bf28443 button .loader_8f26746a2e {
  width: 16px;
  height: 16px;
}

.referenceWrapper_fa2bf28443 button .loader_8f26746a2e.xxs_09e0d54292 {
  width: 10px;
  height: 10px;
}

.referenceWrapper_fa2bf28443 button .loader_8f26746a2e.xxs_09e0d54292 svg {
  display: block;
}`);var ch=function(t){var i=t.size,o=uo(t,["size"]);return k.createElement("svg",Object.assign({viewBox:"0 0 20 20",fill:"currentColor",width:i||"20",height:i||"20"},o),k.createElement("path",{d:"M10.75 6C10.75 5.58579 10.4142 5.25 10 5.25C9.58579 5.25 9.25 5.58579 9.25 6V9.25H6C5.58579 9.25 5.25 9.58579 5.25 10C5.25 10.4142 5.58579 10.75 6 10.75H9.25V14C9.25 14.4142 9.58579 14.75 10 14.75C10.4142 14.75 10.75 14.4142 10.75 14V10.75H14C14.4142 10.75 14.75 10.4142 14.75 10C14.75 9.58579 14.4142 9.25 14 9.25H10.75V6Z",fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd"}))};ch.displayName="AddSmall";var Mu=zt(k.forwardRef(function(t,i){var o=t.className,l=t.wrapperClassName,c=t.iconClassName,d=t.id,p=t.icon,f=p===void 0?ch:p,m=t.size,h=m===void 0?"medium":m,g=t.tooltipProps,y=g===void 0?{}:g,b=t.tooltipContent,w=t.ariaLabeledBy,N=t.ariaLabel,L=t.ariaHasPopup,O=t.ariaExpanded,R=t.ariaControls,M=t["aria-describedby"],z=t["aria-hidden"],I=t["aria-pressed"],B=t.hideTooltip,j=B!==void 0&&B,X=t.kind,K=X===void 0?"tertiary":X,ce=t.active,Q=t.disabled,Z=Q!==void 0&&Q,le=t.disabledReason,de=t.onClick,oe=de===void 0?Zr:de,ve=t.color,re=t["data-testid"],fe=t.insetFocus,H=fe!==void 0&&fe,V=t.tabIndex,x=t.loading,P=x!==void 0&&x,G=k.useRef(null),te=$t(i,G),ie=k.useMemo(function(){return(y==null?void 0:y.content)||b},[y==null?void 0:y.content,b]),ye=k.useMemo(function(){return N||(typeof ie=="string"?ie:void 0)},[N,ie]),_e=k.useMemo(function(){switch(h){case"xxs":case"xs":return oh;case"small":case"medium":case"large":return ih;default:return 24}},[h]),be=k.useMemo(function(){var Ue={justifyContent:"center",alignItems:"center",padding:0};return h&&(Ue=Object.assign(Object.assign({},Ue),T2(h))),Ue},[h]),Y=k.useMemo(function(){return j?null:Z&&le?le:ie||N},[j,Z,le,ie,N]),Se=l?"div":k.Fragment,Ne=k.useMemo(function(){return l?{className:ue(l,Pa.wrapper)}:{}},[l]);return D.createElement(Se,Object.assign({},Ne),D.createElement(at,Object.assign({},y,{content:Y,referenceWrapperClassName:Pa.referenceWrapper}),D.createElement(sr,{onClick:oe,disabled:Z,color:ve,kind:K,ariaLabeledBy:w,ariaLabel:ye,ariaHasPopup:L,ariaExpanded:O,ariaControls:R,"aria-describedby":M,"aria-hidden":z,"aria-pressed":I,ref:te,id:d,"data-testid":re||De(Ze.ICON_BUTTON,d),"data-vibe":pr.ICON_BUTTON,noSidePadding:!0,active:ce,className:o,style:be,insetFocus:H,tabIndex:V,loading:P,loaderClassName:ue(Pa.loader,Xe(Pa,h))},D.createElement(Qt,{icon:f,iconType:"svg",iconSize:_e,ignoreFocusStyle:!0,className:c}))))}),{sizes:sr.sizes,kinds:sr.kinds,colors:sr.colors}),Qc;(function(t){t.PRIMARY="primary",t.POSITIVE="positive",t.NEGATIVE="negative",t.DARK="dark",t.WARNING="warning"})(Qc||(Qc={}));var $n={alertBanner:"alertBanner_41f97faa78",primary:"primary_624aefd09c",positive:"positive_16f11f9456",negative:"negative_702f92bf99",dark:"dark_cf6fbe58b6",warning:"warning_06fbacb68f",closeBtn:"closeBtn_f8eaa9a0c2",content:"content_8b902ac60d",closeButtonWrapper:"closeButtonWrapper_baa9b12ea0",ellipsis:"ellipsis_560458d360",contentItem:"contentItem_6ce81a47d9",contentItemText:"contentItemText_88fddde7d0"};(function(t){const i="s_id-2b16d36a7fd0_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.alertBanner_41f97faa78 {
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
}

.primary_624aefd09c {
  background-color: var(--primary-color);
}

.positive_16f11f9456 {
  background-color: var(--positive-color);
}

.negative_702f92bf99 {
  background-color: var(--negative-color);
}

.dark_cf6fbe58b6 {
  background-color: var(--inverted-color-background);
}

.warning_06fbacb68f {
  background-color: var(--warning-color);
  color: var(--fixed-dark-color);
}

.warning_06fbacb68f .closeBtn_f8eaa9a0c2 {
  color: var(--fixed-dark-color);
}

.content_8b902ac60d {
  flex: 1 1 auto;
  display: flex;
  height: 100%;
  min-width: 0;
  align-items: center;
  justify-content: center;
  padding-left: var(--spacing-medium);
}

.closeButtonWrapper_baa9b12ea0 {
  flex: 0 0 40px;
  position: relative;
  height: 100%;
  min-width: 0;
}

.closeBtn_f8eaa9a0c2 {
  position: absolute;
  right: 4px;
  top: 4px;
}

.ellipsis_560458d360 {
  flex: 0 1 auto;
}

.contentItem_6ce81a47d9 {
  flex: 0 0 auto;
  min-width: 0;
}

.contentItemText_88fddde7d0 {
  flex: 0 1 auto;
  min-width: 0;
}`);var uh=D.createContext({textColor:"onPrimary"}),dh=function(t){var i=t.size,o=uo(t,["size"]);return k.createElement("svg",Object.assign({viewBox:"0 0 20 20",fill:"currentColor",width:i||"20",height:i||"20"},o),k.createElement("path",{d:"M6.331 5.27a.75.75 0 0 0-1.06 1.06L8.94 10l-3.67 3.668a.75.75 0 1 0 1.06 1.06L10 11.06l3.668 3.669a.75.75 0 0 0 1.06-1.06l-3.668-3.67 3.67-3.669a.75.75 0 0 0-1.061-1.06L10 8.939l-3.669-3.67Z"}))};dh.displayName="CloseSmall";var Da=zt(k.forwardRef(function(t,i){var o=t.children,l=t.className,c=t.backgroundColor,d=c===void 0?"primary":c,p=t.onClose,f=p===void 0?Fe:p,m=t.ariaLabel,h=m===void 0?"":m,g=t.closeButtonAriaLabel,y=g===void 0?"Close":g,b=t.isCloseHidden,w=b!==void 0&&b,N=t.id,L=t["data-testid"],O=k.useMemo(function(){return ue(l,$n.alertBanner,Xe($n,d))},[l,d]),R=d==="dark",M=d==="warning",z=k.useMemo(function(){return M?"fixedDark":R?"onInverted":"onPrimary"},[R,M]),I=k.useMemo(function(){return D.Children.toArray(o).filter(function(B){return!(!B.type.isAlertBannerItem&&B.type.displayName!=="MDXCreateElement")||(console.error("Alert banner child is not supported. Please use AlertBannerText, AlertBannerLink or AlertBannerButton.",B),!1)}).map(function(B,j){return D.cloneElement(B,Object.assign(Object.assign({},B==null?void 0:B.props),{marginLeft:j>0,isDarkBackground:R}))})},[o,R]);return D.createElement(cl,{type:"text2",color:z,ref:i,className:O,role:"banner","aria-label":h||"banner",id:N,"data-testid":L||De(Ze.ALERT_BANNER,N)},D.createElement(uh.Provider,{value:{textColor:z}},D.createElement("div",{className:ue($n.content)},I.map(function(B,j){var X=B.type.isAlertBannerText;return D.createElement("div",{key:j,className:ue($n.contentItem,se({},$n.contentItemText,X))},X?D.createElement("div",{className:ue($n.ellipsis)},B):B)}))),D.createElement("div",{className:ue($n.closeButtonWrapper)},w?null:D.createElement(Mu,{"data-testid":"alert-banner-close-button",icon:dh,className:ue($n.closeBtn),hideTooltip:!0,onClick:f,size:"small",kind:"tertiary",color:R?"on-inverted-background":"on-primary-color",ariaLabel:y})))}),{backgroundColors:Qc}),Zc,Qa;(function(t){t.NEW_WINDOW="_blank",t.SELF="_self",t.PARENT="_parent",t.TOP="_top"})(Zc||(Zc={})),function(t){t.START="start",t.END="end"}(Qa||(Qa={}));var ir={link:"link_8825c17a97","focus-visible":"focus-visible_b0a5cd5036",colorOnPrimary:"colorOnPrimary_e3d5c4d9dc",colorOnInverted:"colorOnInverted_b227ee6f36",text:"text_4f75bb4c3e",inlineText:"inlineText_f8b99ae05d",inheritFontSize:"inheritFontSize_6f608b57f2",iconStart:"iconStart_dffa83ad91",iconEnd:"iconEnd_28a59c2cf6"};(function(t){const i="s_id-6fcc93dacbaa_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.link_8825c17a97 {
  display: flex;
  align-items: center;
  color: var(--link-color);
  font: var(--font-text2-normal);
  -webkit-font-smoothing: var(--font-smoothing-webkit);
  -moz-osx-font-smoothing: var(--font-smoothing-moz);
  text-decoration: none;
  writing-mode: horizontal-tb;
}
.link_8825c17a97:focus-visible, .link_8825c17a97.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px hsla(209, 100%, 50%, 0.5), 0 0 0 1px var(--primary-hover-color) inset;
}
.link_8825c17a97:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.link_8825c17a97.colorOnPrimary_e3d5c4d9dc {
  color: var(--text-color-on-primary);
}
.link_8825c17a97.colorOnInverted_b227ee6f36 {
  color: var(--text-color-on-inverted);
}
.link_8825c17a97:hover .text_4f75bb4c3e {
  text-decoration: underline;
  color: inherit;
}
.link_8825c17a97.inlineText_f8b99ae05d {
  display: inline-flex;
  align-items: unset;
}
.link_8825c17a97.inheritFontSize_6f608b57f2 {
  font-size: inherit;
  line-height: inherit;
}
.iconStart_dffa83ad91 {
  line-height: 24px;
  margin-right: var(--spacing-small);
}
.iconEnd_28a59c2cf6 {
  line-height: 24px;
  margin-left: var(--spacing-small);
}
@supports (margin-inline-start: initial) {
  .iconStart_dffa83ad91 {
    line-height: 24px;
    margin-right: 0;
    margin-inline-end: var(--spacing-xs);
  }
  .iconEnd_28a59c2cf6 {
    line-height: 24px;
    margin-left: 0;
    margin-inline-start: var(--spacing-xs);
  }
}`);function Xm(t,i,o){if(t)return D.createElement(Qt,{className:o,icon:i,iconType:"font"})}var L2=zt(k.forwardRef(function(t,i){var o=t.className,l=t.textClassName,c=t.href,d=c===void 0?"":c,p=t.text,f=p===void 0?"":p,m=t.rel,h=m===void 0?"noreferrer":m,g=t.onClick,y=g===void 0?Fe:g,b=t.target,w=b===void 0?"_blank":b,N=t.ariaLabelDescription,L=N===void 0?"":N,O=t.color,R=O===void 0?"primary":O,M=t.ariaDescribedby,z=M===void 0?"":M,I=t.icon,B=I===void 0?"":I,j=t.iconPosition,X=t.id,K=X===void 0?"":X,ce=t.ariaLabeledBy,Q=ce===void 0?"":ce,Z=t.disableNavigation,le=Z!==void 0&&Z,de=t.inheritFontSize,oe=de!==void 0&&de,ve=t.inlineText,re=ve!==void 0&&ve,fe=t["data-testid"],H=(j===void 0?"start":j)==="start",V=k.useCallback(function(x){le&&x.preventDefault(),y&&y(x)},[le,y]);return D.createElement("a",{"data-testid":fe||De(pn.LINK,K),id:K,href:d,rel:h,ref:i,onClick:V,target:w,className:ue(ir.link,o,Xe(ir,Qe("color-"+R)),se(se({},ir.inheritFontSize,oe),ir.inlineText,re)),"aria-label":L,"aria-describedby":z,"aria-labelledby":Q},Xm(H,B,ue(ir.iconStart)),D.createElement("span",{className:ue(ir.text,l)},f),Xm(!H,B,ue(ir.iconEnd)))}),{position:Qa,iconPositions:Qa,targets:Zc}),Ia={bannerLink:"bannerLink_c816ee1ab9",bannerLinkTextColorOnPrimary:"bannerLinkTextColorOnPrimary_e3d5c4d9dc",bannerLinkTextColorOnInverted:"bannerLinkTextColorOnInverted_b227ee6f36",marginLeft:"marginLeft_8370ecdf48"};(function(t){const i="s_id-59c5b2cdc5e5_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.bannerLink_c816ee1ab9 {
  text-decoration: underline;
  -webkit-font-smoothing: auto;
  -moz-osx-font-smoothing: auto;
}

.bannerLinkTextColorOnPrimary_e3d5c4d9dc {
  color: var(--text-color-on-primary);
}

.bannerLinkTextColorOnInverted_b227ee6f36 {
  color: var(--text-color-on-inverted);
}

.marginLeft_8370ecdf48 {
  margin-left: var(--spacing-small);
}`);var li=function(t){var i=t.marginLeft,o=i!==void 0&&i,l=t.id,c=t["data-testid"],d=co(t,["marginLeft","id","data-testid"]),p=k.useContext(uh).textColor,f=ue(se({},Ia.marginLeft,o));return D.createElement("div",{className:f,"data-testid":c||De(pn.ALERT_BANNER_LINK,l),id:l},D.createElement(L2,Object.assign({},d,{textClassName:ue(Ia.bannerLink,se(se({},Ia.bannerLinkTextColorOnPrimary,p==="onPrimary"),Ia.bannerLinkTextColorOnInverted,p==="onInverted"))})))};Object.assign(li,{isAlertBannerItem:!0});var Um={bannerText:"bannerText_f577135df2",marginLeft:"marginLeft_8370ecdf48"};(function(t){const i="s_id-35d8b4a93255_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.bannerText_f577135df2 {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.marginLeft_8370ecdf48 {
  margin-left: var(--spacing-small);
}`);var si=function(t){var i=t.text,o=t.marginLeft,l=o!==void 0&&o,c=t.id,d=t["data-testid"],p=k.useRef(null),f=ue(Um.bannerText,se({},Um.marginLeft,l)),m=$v({ref:p});return D.createElement(at,{position:"bottom",content:m&&i,showTrigger:["mouseenter"],hideTrigger:["mouseleave"]},D.createElement("div",{ref:p,className:f,id:c,"data-testid":d||De(pn.ALERT_BANNER_TEXT,c)},D.createElement("span",null,i)))};Object.assign(si,{isAlertBannerItem:!0,isAlertBannerText:!0});var fh=function(t){var i=t.size,o=uo(t,["size"]);return k.createElement("svg",Object.assign({viewBox:"0 0 20 20",fill:"currentColor",width:i||"20",height:i||"20"},o),k.createElement("path",{d:"M4.5559 4.55593C5.99976 3.11206 7.95806 2.3009 10 2.3009C12.0419 2.3009 14.0002 3.11206 15.4441 4.55593C16.888 5.99979 17.6991 7.9581 17.6991 10C17.6991 12.042 16.888 14.0003 15.4441 15.4441C14.0002 16.888 12.0419 17.6992 10 17.6992C7.95806 17.6992 5.99976 16.888 4.5559 15.4441C3.11203 14.0003 2.30087 12.042 2.30087 10C2.30087 7.9581 3.11203 5.99979 4.5559 4.55593ZM10 3.8009C8.35589 3.8009 6.77912 4.45402 5.61656 5.61659C4.45399 6.77915 3.80087 8.35592 3.80087 10C3.80087 11.6441 4.45399 13.2209 5.61656 14.3835C6.77912 15.546 8.35589 16.1992 10 16.1992C11.6441 16.1992 13.2209 15.546 14.3834 14.3835C15.546 13.2209 16.1991 11.6441 16.1991 10C16.1991 8.35592 15.546 6.77915 14.3834 5.61659C13.2209 4.45402 11.6441 3.8009 10 3.8009ZM10 9.25006C10.4142 9.25006 10.75 9.58585 10.75 10.0001V13.4746C10.75 13.8888 10.4142 14.2246 10 14.2246C9.58579 14.2246 9.25 13.8888 9.25 13.4746V10.0001C9.25 9.58585 9.58579 9.25006 10 9.25006ZM9.54135 6.21669C9.7058 6.10681 9.89914 6.04816 10.0969 6.04816C10.3621 6.04816 10.6165 6.15351 10.804 6.34105C10.9916 6.52859 11.0969 6.78294 11.0969 7.04816C11.0969 7.24593 11.0383 7.43927 10.9284 7.60373C10.8185 7.76818 10.6623 7.89635 10.4796 7.97204C10.2969 8.04772 10.0958 8.06753 9.90183 8.02894C9.70786 7.99036 9.52967 7.89512 9.38982 7.75526C9.24996 7.61541 9.15472 7.43722 9.11614 7.24325C9.07755 7.04927 9.09736 6.8482 9.17304 6.66547C9.24873 6.48275 9.3769 6.32657 9.54135 6.21669Z",fill:"currentColor",fillRule:"evenodd",clipRule:"evenodd"}))};fh.displayName="Info";function R2(t){var i=k.useRef(void 0);return tl(function(){i.current=t}),i.current}var Hm,Wm,Jc,eu,tu,nu,ru,ou,iu,au,lu,su,cu,uu,du,fu,pu,mu,vu,hu,gu;(function(t){t.DISABLED="opacityDisabled"})(Hm||(Hm={})),function(t){t.DEFAULT="border"}(Wm||(Wm={})),function(t){t.UI_BORDER_COLOR="uiBorderColor",t.LAYOUT_BORDER_COLOR="layoutBorderColor"}(Jc||(Jc={})),function(t){t.SMALL="small",t.MEDIUM="medium",t.BIG="big"}(eu||(eu={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"}(tu||(tu={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(nu||(nu={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(ru||(ru={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(ou||(ou={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(iu||(iu={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(au||(au={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(lu||(lu={})),function(t){t.AUTO="auto",t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(su||(su={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(cu||(cu={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(uu||(uu={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(du||(du={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(fu||(fu={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(pu||(pu={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(mu||(mu={})),function(t){t.XS="xs",t.SMALL="small",t.MEDIUM="medium",t.LARGE="large",t.XL="xl",t.XXL="xxl",t.XXXL="xxxl"}(vu||(vu={})),function(t){t.PRIMARY_BACKGROUND_COLOR="primaryBackgroundColor",t.SECONDARY_BACKGROUND_COLOR="secondaryBackgroundColor",t.GREY_BACKGROUND_COLOR="greyBackgroundColor",t.ALL_GREY_BACKGROUND_COLOR="allgreyBackgroundColor",t.INVERTED_COLOR_BACKGROUND="invertedColorBackground"}(hu||(hu={})),function(t){t.PRIMARY_TEXT_COLOR="primaryTextColor",t.TEXT_COLOR_ON_INVERTED="textColorOnInverted",t.SECONDARY_TEXT_COLOR="secondaryTextColor"}(gu||(gu={}));var P2={margin:"m",marginX:"mx",marginY:"my",marginTop:"mt",marginEnd:"me",marginBottom:"mb",marginStart:"ms",padding:"p",paddingX:"px",paddingY:"py",paddingTop:"pt",paddingEnd:"pe",paddingBottom:"pb",paddingStart:"ps",shadow:"shadow",rounded:"rounded",borderColor:"borderColor",backgroundColor:"bg",textColor:"text"},ri={box:"box_993e832d20",scrollable:"scrollable_89bf906ab7",opacityDisabled:"opacityDisabled_925da52e3f",border:"border_79d9ea5b46",borderColorUiBorderColor:"borderColorUiBorderColor_da8d2e9b27",borderColorLayoutBorderColor:"borderColorLayoutBorderColor_be180421b1",rounded0:"rounded0_3cbfdb2616",roundedSmall:"roundedSmall_4835f9b792",roundedMedium:"roundedMedium_69109d626a",roundedBig:"roundedBig_a4f1a03c7a",shadowXs:"shadowXs_e814716c4d",shadowSmall:"shadowSmall_b78a54d685",shadowMedium:"shadowMedium_868cf37ebc",shadowLarge:"shadowLarge_7f8e1a8a1c",m0:"m0_d7c7fa83f6",mXs:"mXs_f28ffc2f3c",mSmall:"mSmall_440ba92bfb",mMedium:"mMedium_05a09159f6",mLarge:"mLarge_3bd569a584",mXl:"mXl_9b3d447ad2",mXxl:"mXxl_729966b2f2",mXxxl:"mXxxl_5ebdf30e9f",mAuto:"mAuto_6cf59571ab",mx0:"mx0_8527fab4aa",mxXs:"mxXs_b03d337154",mxSmall:"mxSmall_c1d2c8de61",mxMedium:"mxMedium_c952fbc4d8",mxLarge:"mxLarge_0f7f69f0e6",mxXl:"mxXl_d04cc070d9",mxXxl:"mxXxl_fbd7b0ea40",mxXxxl:"mxXxxl_85c4a419b8",mxAuto:"mxAuto_764d2ef8d3",my0:"my0_7a46ceabbc",myXs:"myXs_cf373f72a9",mySmall:"mySmall_bce61a53e8",myMedium:"myMedium_eb87d22f62",myLarge:"myLarge_4df6115def",myXl:"myXl_073bdf37ea",myXxl:"myXxl_55c26363d0",myXxxl:"myXxxl_e49af6d4c5",myAuto:"myAuto_0a411e570e",mt0:"mt0_65954d56cc",mtXs:"mtXs_a1814b970a",mtSmall:"mtSmall_70a9a57031",mtMedium:"mtMedium_1b290e8073",mtLarge:"mtLarge_19831086e2",mtXl:"mtXl_b32d2b5fcb",mtXxl:"mtXxl_e6ae5f2bf9",mtXxxl:"mtXxxl_4f453e1fe2",mtAuto:"mtAuto_7b0cdb1ab0",me0:"me0_2805b79abf",meXs:"meXs_33cffc0dea",meSmall:"meSmall_09d9d45626",meMedium:"meMedium_a586c65e74",meLarge:"meLarge_b4d253acfe",meXl:"meXl_680f1e5c68",meXxl:"meXxl_a504156e91",meXxxl:"meXxxl_cbee633636",meAuto:"meAuto_50f59a072b",mb0:"mb0_4bf7013204",mbXs:"mbXs_f37c4be118",mbSmall:"mbSmall_1cc757214a",mbMedium:"mbMedium_ff377cd433",mbLarge:"mbLarge_f3b75d74c9",mbXl:"mbXl_212e8e435d",mbXxl:"mbXxl_8cce147ae7",mbXxxl:"mbXxxl_7550582727",mbAuto:"mbAuto_4034ad8a3a",ms0:"ms0_443a2a993c",msXs:"msXs_f5b17668a7",msSmall:"msSmall_74c12357af",msMedium:"msMedium_99d557b6d8",msLarge:"msLarge_5ba28a66e0",msXl:"msXl_4df76c61f1",msXxl:"msXxl_441e79e6b7",msXxxl:"msXxxl_ff863339a0",msAuto:"msAuto_a738b51f71",p0:"p0_e148d8578d",pXs:"pXs_05e0c18068",pSmall:"pSmall_805d7085b3",pMedium:"pMedium_547ef3ebd7",pLarge:"pLarge_72abef2e79",pXl:"pXl_bb02323aaa",pXxl:"pXxl_71386f6173",pXxxl:"pXxxl_f6b085e3e8",px0:"px0_6fc75985b7",pxXs:"pxXs_96dda39964",pxSmall:"pxSmall_26686bcff1",pxMedium:"pxMedium_65cb118d81",pxLarge:"pxLarge_a095465b45",pxXl:"pxXl_a50ee75892",pxXxl:"pxXxl_224691529e",pxXxxl:"pxXxxl_84a949ed0a",py0:"py0_d651bd3652",pyXs:"pyXs_e31eb40ba5",pySmall:"pySmall_3ee9ff1a69",pyMedium:"pyMedium_567036ee98",pyLarge:"pyLarge_58acd46c35",pyXl:"pyXl_1e657ddcdb",pyXxl:"pyXxl_c996f60eed",pyXxxl:"pyXxxl_b98111d6b6",pt0:"pt0_1e94f9d831",ptXs:"ptXs_4cf8813f55",ptSmall:"ptSmall_21ab999e69",ptMedium:"ptMedium_21a62ca29f",ptLarge:"ptLarge_df8d7660df",ptXl:"ptXl_248ddff733",ptXxl:"ptXxl_bd24092909",ptXxxl:"ptXxxl_04acd04ea0",pe0:"pe0_a045dfc213",peXs:"peXs_57559026b6",peSmall:"peSmall_52c3b7fdf4",peMedium:"peMedium_c7e4893e9f",peLarge:"peLarge_07536050a8",peXl:"peXl_66ff1450e5",peXxl:"peXxl_b9bdd33670",peXxxl:"peXxxl_3d77a21278",pb0:"pb0_2c7cec8a39",pbXs:"pbXs_5821a37a3b",pbSmall:"pbSmall_2346acf273",pbMedium:"pbMedium_edc4972fc1",pbLarge:"pbLarge_03dd105a56",pbXl:"pbXl_ec209caad4",pbXxl:"pbXxl_100f284c66",pbXxxl:"pbXxxl_f845b0fe05",ps0:"ps0_439261ac1b",psXs:"psXs_8bea06c8f7",psSmall:"psSmall_bac23fe8e7",psMedium:"psMedium_55d81f55ce",psLarge:"psLarge_fe1a520821",psXl:"psXl_87cce31336",psXxl:"psXxl_4899a8dfab",psXxxl:"psXxxl_84db9eb85a",textPrimaryTextColor:"textPrimaryTextColor_5548666143",textTextColorOnInverted:"textTextColorOnInverted_0bc0621834",textSecondaryTextColor:"textSecondaryTextColor_abc28821ce",bgPrimaryBackgroundColor:"bgPrimaryBackgroundColor_8cd46c4088",bgSecondaryBackgroundColor:"bgSecondaryBackgroundColor_98edbf8a8f",bgGreyBackgroundColor:"bgGreyBackgroundColor_e1b5d21301",bgAllgreyBackgroundColor:"bgAllgreyBackgroundColor_7bb2e22f0e",bgInvertedColorBackground:"bgInvertedColorBackground_3844fb43aa"};(function(t){const i="s_id-e8ebf0c89fee_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`/*  stylelint-disable scss/at-if-no-null */
/*  stylelint-enable scss/at-if-no-null */
.box_993e832d20 {
  overflow: hidden;
}
.box_993e832d20.scrollable_89bf906ab7 {
  overflow: auto;
}
.box_993e832d20.scrollable_89bf906ab7::-webkit-scrollbar {
  width: 4px;
  height: 6px;
}
.box_993e832d20.scrollable_89bf906ab7::-webkit-scrollbar-thumb {
  background-color: var(--ui-border-color);
  border-radius: 4px;
}
.opacityDisabled_925da52e3f {
  opacity: var(--disabled-component-opacity) !important;
}
.border_79d9ea5b46 {
  border: var(--border-width) var(--border-style) var(--ui-border-color) !important;
}
.borderColorUiBorderColor_da8d2e9b27 {
  border-color: var(--ui-border-color) !important;
}
.borderColorLayoutBorderColor_be180421b1 {
  border-color: var(--layout-border-color) !important;
}
.rounded0_3cbfdb2616 {
  border-radius: 0 !important;
}
.roundedSmall_4835f9b792 {
  border-radius: var(--border-radius-small) !important;
}
.roundedMedium_69109d626a {
  border-radius: var(--border-radius-medium) !important;
}
.roundedBig_a4f1a03c7a {
  border-radius: var(--border-radius-big) !important;
}
.shadowXs_e814716c4d {
  box-shadow: var(--box-shadow-xs) !important;
}
.shadowSmall_b78a54d685 {
  box-shadow: var(--box-shadow-small) !important;
}
.shadowMedium_868cf37ebc {
  box-shadow: var(--box-shadow-medium) !important;
}
.shadowLarge_7f8e1a8a1c {
  box-shadow: var(--box-shadow-large) !important;
}
.m0_d7c7fa83f6 {
  margin: 0 !important;
}
.mXs_f28ffc2f3c {
  margin: var(--spacing-xs) !important;
}
.mSmall_440ba92bfb {
  margin: var(--spacing-small) !important;
}
.mMedium_05a09159f6 {
  margin: var(--spacing-medium) !important;
}
.mLarge_3bd569a584 {
  margin: var(--spacing-large) !important;
}
.mXl_9b3d447ad2 {
  margin: var(--spacing-xl) !important;
}
.mXxl_729966b2f2 {
  margin: var(--spacing-xxl) !important;
}
.mXxxl_5ebdf30e9f {
  margin: var(--spacing-xxxl) !important;
}
.mAuto_6cf59571ab {
  margin: auto !important;
}
.mx0_8527fab4aa {
  margin-right: 0 !important;
  margin-left: 0 !important;
}
.mxXs_b03d337154 {
  margin-right: var(--spacing-xs) !important;
  margin-left: var(--spacing-xs) !important;
}
.mxSmall_c1d2c8de61 {
  margin-right: var(--spacing-small) !important;
  margin-left: var(--spacing-small) !important;
}
.mxMedium_c952fbc4d8 {
  margin-right: var(--spacing-medium) !important;
  margin-left: var(--spacing-medium) !important;
}
.mxLarge_0f7f69f0e6 {
  margin-right: var(--spacing-large) !important;
  margin-left: var(--spacing-large) !important;
}
.mxXl_d04cc070d9 {
  margin-right: var(--spacing-xl) !important;
  margin-left: var(--spacing-xl) !important;
}
.mxXxl_fbd7b0ea40 {
  margin-right: var(--spacing-xxl) !important;
  margin-left: var(--spacing-xxl) !important;
}
.mxXxxl_85c4a419b8 {
  margin-right: var(--spacing-xxxl) !important;
  margin-left: var(--spacing-xxxl) !important;
}
.mxAuto_764d2ef8d3 {
  margin-right: auto !important;
  margin-left: auto !important;
}
.my0_7a46ceabbc {
  margin-top: 0 !important;
  margin-bottom: 0 !important;
}
.myXs_cf373f72a9 {
  margin-top: var(--spacing-xs) !important;
  margin-bottom: var(--spacing-xs) !important;
}
.mySmall_bce61a53e8 {
  margin-top: var(--spacing-small) !important;
  margin-bottom: var(--spacing-small) !important;
}
.myMedium_eb87d22f62 {
  margin-top: var(--spacing-medium) !important;
  margin-bottom: var(--spacing-medium) !important;
}
.myLarge_4df6115def {
  margin-top: var(--spacing-large) !important;
  margin-bottom: var(--spacing-large) !important;
}
.myXl_073bdf37ea {
  margin-top: var(--spacing-xl) !important;
  margin-bottom: var(--spacing-xl) !important;
}
.myXxl_55c26363d0 {
  margin-top: var(--spacing-xxl) !important;
  margin-bottom: var(--spacing-xxl) !important;
}
.myXxxl_e49af6d4c5 {
  margin-top: var(--spacing-xxxl) !important;
  margin-bottom: var(--spacing-xxxl) !important;
}
.myAuto_0a411e570e {
  margin-top: auto !important;
  margin-bottom: auto !important;
}
.mt0_65954d56cc {
  margin-top: 0 !important;
}
.mtXs_a1814b970a {
  margin-top: var(--spacing-xs) !important;
}
.mtSmall_70a9a57031 {
  margin-top: var(--spacing-small) !important;
}
.mtMedium_1b290e8073 {
  margin-top: var(--spacing-medium) !important;
}
.mtLarge_19831086e2 {
  margin-top: var(--spacing-large) !important;
}
.mtXl_b32d2b5fcb {
  margin-top: var(--spacing-xl) !important;
}
.mtXxl_e6ae5f2bf9 {
  margin-top: var(--spacing-xxl) !important;
}
.mtXxxl_4f453e1fe2 {
  margin-top: var(--spacing-xxxl) !important;
}
.mtAuto_7b0cdb1ab0 {
  margin-top: auto !important;
}
.me0_2805b79abf {
  margin-inline-end: 0 !important;
}
.meXs_33cffc0dea {
  margin-inline-end: var(--spacing-xs) !important;
}
.meSmall_09d9d45626 {
  margin-inline-end: var(--spacing-small) !important;
}
.meMedium_a586c65e74 {
  margin-inline-end: var(--spacing-medium) !important;
}
.meLarge_b4d253acfe {
  margin-inline-end: var(--spacing-large) !important;
}
.meXl_680f1e5c68 {
  margin-inline-end: var(--spacing-xl) !important;
}
.meXxl_a504156e91 {
  margin-inline-end: var(--spacing-xxl) !important;
}
.meXxxl_cbee633636 {
  margin-inline-end: var(--spacing-xxxl) !important;
}
.meAuto_50f59a072b {
  margin-inline-end: auto !important;
}
.mb0_4bf7013204 {
  margin-bottom: 0 !important;
}
.mbXs_f37c4be118 {
  margin-bottom: var(--spacing-xs) !important;
}
.mbSmall_1cc757214a {
  margin-bottom: var(--spacing-small) !important;
}
.mbMedium_ff377cd433 {
  margin-bottom: var(--spacing-medium) !important;
}
.mbLarge_f3b75d74c9 {
  margin-bottom: var(--spacing-large) !important;
}
.mbXl_212e8e435d {
  margin-bottom: var(--spacing-xl) !important;
}
.mbXxl_8cce147ae7 {
  margin-bottom: var(--spacing-xxl) !important;
}
.mbXxxl_7550582727 {
  margin-bottom: var(--spacing-xxxl) !important;
}
.mbAuto_4034ad8a3a {
  margin-bottom: auto !important;
}
.ms0_443a2a993c {
  margin-inline-start: 0 !important;
}
.msXs_f5b17668a7 {
  margin-inline-start: var(--spacing-xs) !important;
}
.msSmall_74c12357af {
  margin-inline-start: var(--spacing-small) !important;
}
.msMedium_99d557b6d8 {
  margin-inline-start: var(--spacing-medium) !important;
}
.msLarge_5ba28a66e0 {
  margin-inline-start: var(--spacing-large) !important;
}
.msXl_4df76c61f1 {
  margin-inline-start: var(--spacing-xl) !important;
}
.msXxl_441e79e6b7 {
  margin-inline-start: var(--spacing-xxl) !important;
}
.msXxxl_ff863339a0 {
  margin-inline-start: var(--spacing-xxxl) !important;
}
.msAuto_a738b51f71 {
  margin-inline-start: auto !important;
}
.p0_e148d8578d {
  padding: 0 !important;
}
.pXs_05e0c18068 {
  padding: var(--spacing-xs) !important;
}
.pSmall_805d7085b3 {
  padding: var(--spacing-small) !important;
}
.pMedium_547ef3ebd7 {
  padding: var(--spacing-medium) !important;
}
.pLarge_72abef2e79 {
  padding: var(--spacing-large) !important;
}
.pXl_bb02323aaa {
  padding: var(--spacing-xl) !important;
}
.pXxl_71386f6173 {
  padding: var(--spacing-xxl) !important;
}
.pXxxl_f6b085e3e8 {
  padding: var(--spacing-xxxl) !important;
}
.px0_6fc75985b7 {
  padding-right: 0 !important;
  padding-left: 0 !important;
}
.pxXs_96dda39964 {
  padding-right: var(--spacing-xs) !important;
  padding-left: var(--spacing-xs) !important;
}
.pxSmall_26686bcff1 {
  padding-right: var(--spacing-small) !important;
  padding-left: var(--spacing-small) !important;
}
.pxMedium_65cb118d81 {
  padding-right: var(--spacing-medium) !important;
  padding-left: var(--spacing-medium) !important;
}
.pxLarge_a095465b45 {
  padding-right: var(--spacing-large) !important;
  padding-left: var(--spacing-large) !important;
}
.pxXl_a50ee75892 {
  padding-right: var(--spacing-xl) !important;
  padding-left: var(--spacing-xl) !important;
}
.pxXxl_224691529e {
  padding-right: var(--spacing-xxl) !important;
  padding-left: var(--spacing-xxl) !important;
}
.pxXxxl_84a949ed0a {
  padding-right: var(--spacing-xxxl) !important;
  padding-left: var(--spacing-xxxl) !important;
}
.py0_d651bd3652 {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}
.pyXs_e31eb40ba5 {
  padding-top: var(--spacing-xs) !important;
  padding-bottom: var(--spacing-xs) !important;
}
.pySmall_3ee9ff1a69 {
  padding-top: var(--spacing-small) !important;
  padding-bottom: var(--spacing-small) !important;
}
.pyMedium_567036ee98 {
  padding-top: var(--spacing-medium) !important;
  padding-bottom: var(--spacing-medium) !important;
}
.pyLarge_58acd46c35 {
  padding-top: var(--spacing-large) !important;
  padding-bottom: var(--spacing-large) !important;
}
.pyXl_1e657ddcdb {
  padding-top: var(--spacing-xl) !important;
  padding-bottom: var(--spacing-xl) !important;
}
.pyXxl_c996f60eed {
  padding-top: var(--spacing-xxl) !important;
  padding-bottom: var(--spacing-xxl) !important;
}
.pyXxxl_b98111d6b6 {
  padding-top: var(--spacing-xxxl) !important;
  padding-bottom: var(--spacing-xxxl) !important;
}
.pt0_1e94f9d831 {
  padding-top: 0 !important;
}
.ptXs_4cf8813f55 {
  padding-top: var(--spacing-xs) !important;
}
.ptSmall_21ab999e69 {
  padding-top: var(--spacing-small) !important;
}
.ptMedium_21a62ca29f {
  padding-top: var(--spacing-medium) !important;
}
.ptLarge_df8d7660df {
  padding-top: var(--spacing-large) !important;
}
.ptXl_248ddff733 {
  padding-top: var(--spacing-xl) !important;
}
.ptXxl_bd24092909 {
  padding-top: var(--spacing-xxl) !important;
}
.ptXxxl_04acd04ea0 {
  padding-top: var(--spacing-xxxl) !important;
}
.pe0_a045dfc213 {
  padding-inline-end: 0 !important;
}
.peXs_57559026b6 {
  padding-inline-end: var(--spacing-xs) !important;
}
.peSmall_52c3b7fdf4 {
  padding-inline-end: var(--spacing-small) !important;
}
.peMedium_c7e4893e9f {
  padding-inline-end: var(--spacing-medium) !important;
}
.peLarge_07536050a8 {
  padding-inline-end: var(--spacing-large) !important;
}
.peXl_66ff1450e5 {
  padding-inline-end: var(--spacing-xl) !important;
}
.peXxl_b9bdd33670 {
  padding-inline-end: var(--spacing-xxl) !important;
}
.peXxxl_3d77a21278 {
  padding-inline-end: var(--spacing-xxxl) !important;
}
.pb0_2c7cec8a39 {
  padding-bottom: 0 !important;
}
.pbXs_5821a37a3b {
  padding-bottom: var(--spacing-xs) !important;
}
.pbSmall_2346acf273 {
  padding-bottom: var(--spacing-small) !important;
}
.pbMedium_edc4972fc1 {
  padding-bottom: var(--spacing-medium) !important;
}
.pbLarge_03dd105a56 {
  padding-bottom: var(--spacing-large) !important;
}
.pbXl_ec209caad4 {
  padding-bottom: var(--spacing-xl) !important;
}
.pbXxl_100f284c66 {
  padding-bottom: var(--spacing-xxl) !important;
}
.pbXxxl_f845b0fe05 {
  padding-bottom: var(--spacing-xxxl) !important;
}
.ps0_439261ac1b {
  padding-inline-start: 0 !important;
}
.psXs_8bea06c8f7 {
  padding-inline-start: var(--spacing-xs) !important;
}
.psSmall_bac23fe8e7 {
  padding-inline-start: var(--spacing-small) !important;
}
.psMedium_55d81f55ce {
  padding-inline-start: var(--spacing-medium) !important;
}
.psLarge_fe1a520821 {
  padding-inline-start: var(--spacing-large) !important;
}
.psXl_87cce31336 {
  padding-inline-start: var(--spacing-xl) !important;
}
.psXxl_4899a8dfab {
  padding-inline-start: var(--spacing-xxl) !important;
}
.psXxxl_84db9eb85a {
  padding-inline-start: var(--spacing-xxxl) !important;
}
.textPrimaryTextColor_5548666143 {
  color: var(--primary-text-color) !important;
}
.textTextColorOnInverted_0bc0621834 {
  color: var(--text-color-on-inverted) !important;
}
.textSecondaryTextColor_abc28821ce {
  color: var(--secondary-text-color) !important;
}
.bgPrimaryBackgroundColor_8cd46c4088 {
  background-color: var(--primary-background-color) !important;
}
.bgSecondaryBackgroundColor_98edbf8a8f {
  background-color: var(--secondary-background-color) !important;
}
.bgGreyBackgroundColor_e1b5d21301 {
  background-color: var(--grey-background-color) !important;
}
.bgAllgreyBackgroundColor_7bb2e22f0e {
  background-color: var(--allgrey-background-color) !important;
}
.bgInvertedColorBackground_3844fb43aa {
  background-color: var(--inverted-color-background) !important;
}`);var D2=zt(k.forwardRef(function(t,i){var o=t.className,l=t.id,c=t.elementType,d=c===void 0?"div":c,p=t.children,f=t.disabled,m=t.border,h=t.scrollable,g=t.style,y=t["data-testid"],b=co(t,["className","id","elementType","children","disabled","border","scrollable","style","data-testid"]),w=k.useRef(null),N=$t(i,w);return D.createElement(d,{"data-testid":y||De(Ze.BOX,l),ref:N,className:ue.apply(void 0,[ri.box,o,se(se(se({},ri.opacityDisabled,f),ri.scrollable,h),ri.border,m)].concat(wu(function(L,O){return Object.keys(O).filter(function(R){return O[R]}).map(function(R){var M=O[R],z=P2[R];return z&&typeof M=="string"?L[Qe("".concat(z,"-").concat(M))]:L[M]}).filter(Boolean)}(ri,b)))),id:l,style:g},p)}),{borderColors:Jc,roundeds:eu,shadows:tu,margins:nu,marginXs:ru,marginYs:ou,marginTops:iu,marginEnds:au,marginBottoms:lu,marginStarts:su,paddings:cu,paddingXs:uu,paddingYs:du,paddingTops:fu,paddingEnds:pu,paddingBottoms:mu,paddingStarts:vu,backgroundColors:hu,textColors:gu}),zn={editableTypography:"editableTypography_1ed1f4ee9b",input:"input_8fd02da82c",textarea:"textarea_96ae420be2",typography:"typography_b054aca377",disabled:"disabled_ade5973c34",hidden:"hidden_56bd9204c9",placeholder:"placeholder_7bf2726c24",multiline:"multiline_31e607bf68"};(function(t){const i="s_id-34ea4bd39075_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.editableTypography_1ed1f4ee9b {
  display: inline-flex;
  min-width: 0;
  max-width: 100%;
  margin-left: -6px;
  overflow: hidden;
  position: relative;
}
.editableTypography_1ed1f4ee9b .input_8fd02da82c,
.editableTypography_1ed1f4ee9b .textarea_96ae420be2 {
  width: var(--input-width);
  display: inline-block;
  max-width: 100%;
  min-width: 64px;
  padding: 0 var(--spacing-xs);
  outline: none;
  border: 1px solid var(--primary-color);
  border-radius: var(--border-radius-small);
  color: var(--primary-text-color);
  background-color: transparent;
}
.editableTypography_1ed1f4ee9b .input_8fd02da82c:focus, .editableTypography_1ed1f4ee9b .input_8fd02da82c:active,
.editableTypography_1ed1f4ee9b .textarea_96ae420be2:focus,
.editableTypography_1ed1f4ee9b .textarea_96ae420be2:active {
  outline: none;
}
.editableTypography_1ed1f4ee9b .textarea_96ae420be2 {
  resize: none;
  overflow: hidden;
  height: var(--input-height);
}
.editableTypography_1ed1f4ee9b .typography_b054aca377 {
  border: 1px solid transparent;
  padding: 0 var(--spacing-xs);
  border-radius: var(--border-radius-small);
}
.editableTypography_1ed1f4ee9b .typography_b054aca377:hover:not(.disabled_ade5973c34) {
  border-color: var(--ui-border-color);
}
.editableTypography_1ed1f4ee9b .typography_b054aca377.hidden_56bd9204c9 {
  position: absolute;
  opacity: 0;
  height: 0;
  visibility: hidden;
  white-space: pre;
}
.editableTypography_1ed1f4ee9b .typography_b054aca377.placeholder_7bf2726c24 {
  color: var(--secondary-text-color);
}
.editableTypography_1ed1f4ee9b .typography_b054aca377.multiline_31e607bf68 {
  white-space: pre-wrap;
}`);var I2=k.forwardRef(function(t,i){var o=t.id,l=t.className,c=t["data-testid"],d=t.value,p=t.onChange,f=t.onClick,m=t.readOnly,h=m!==void 0&&m,g=t.ariaLabel,y=g===void 0?"":g,b=t.placeholder,w=t.clearable,N=t.typographyClassName,L=t.component,O=t.isEditMode,R=t.autoSelectTextOnEditMode,M=t.onEditModeChange,z=t.tooltipProps,I=t.type,B=t.weight,j=t.multiline,X=j!==void 0&&j,K=k.useRef(null),ce=$t(i,K),Q=k.useState(O||!1),Z=Tt(Q,2),le=Z[0],de=Z[1],oe=k.useState(d),ve=Tt(oe,2),re=ve[0],fe=ve[1],H=R2(d),V=k.useRef(null),x=k.useRef(null);function P(Y){h||le||(Y.preventDefault(),G(!0))}function G(Y){M==null||M(Y),de(Y)}function te(){G(!1),d!==re&&(re||w&&b?(fe(re),p==null||p(re)):fe(d))}function ie(){te()}function ye(Y){if(Y.key===vr.ENTER){if(X&&Y.shiftKey)return;Y.preventDefault(),Y.stopPropagation(),te()}Y.key===vr.ESCAPE&&(Y.preventDefault(),Y.stopPropagation(),G(!1),fe(d))}function _e(Y){fe(Y.target.value)}k.useEffect(function(){le||d===H||d===re||fe(d)},[H,le,d,re]),k.useEffect(function(){de(O)},[O]);var be=rh(P);return k.useEffect(function(){var Y,Se;le&&(function(){var Ne,Ue;if((Ue=(Ne=V.current)===null||Ne===void 0?void 0:Ne.focus)===null||Ue===void 0||Ue.call(Ne),V.current){var Ft=V.current,vt=Ft.value.length;Ft.setSelectionRange(vt,vt)}}(),R&&((Se=(Y=V.current)===null||Y===void 0?void 0:Y.select)===null||Se===void 0||Se.call(Y)))},[R,le]),tl(function(){var Y;if(x.current){var Se=x.current.getBoundingClientRect();if((Y=V==null?void 0:V.current)===null||Y===void 0||Y.style.setProperty("--input-width","".concat(Se.width,"px")),X){var Ne=V==null?void 0:V.current;Ne==null||Ne.style.setProperty("--input-height","auto"),Ne==null||Ne.style.setProperty("--input-height","".concat(Ne.scrollHeight+2,"px"))}}},[re,le]),D.createElement("div",{ref:ce,id:o,"aria-label":y,"data-testid":c,className:ue(zn.editableTypography,l),role:le?null:"button",onClick:function(Y){f==null||f(Y),P(Y)},onKeyDown:be},le&&(X?D.createElement("textarea",{ref:V,className:ue(zn.textarea,N),value:re,onChange:_e,onKeyDown:ye,onBlur:ie,"aria-label":y,placeholder:b,role:"textbox",rows:1}):D.createElement("input",{ref:V,className:ue(zn.input,N),value:re,onChange:_e,onKeyDown:ye,onBlur:ie,"aria-label":y,placeholder:b,role:"input"})),D.createElement(L,{ref:x,"aria-hidden":le,className:ue(zn.typography,N,se(se(se(se({},zn.hidden,le),zn.disabled,h),zn.placeholder,!re&&b),zn.multiline,!le&&X)),tabIndex:0,tooltipProps:z,weight:B,type:I,ellipsis:!X},re||b))}),kc={text1Bold:"text1Bold_55da83707c",text1Medium:"text1Medium_48b000a595",text1Normal:"text1Normal_3057fa2a8b",text2Bold:"text2Bold_6e3e14ff64",text2Medium:"text2Medium_3602a7ed9d",text2Normal:"text2Normal_2aa41ff154",text3Bold:"text3Bold_8377677634",text3Medium:"text3Medium_47f94d2806",text3Normal:"text3Normal_5a064de678",editableText:"editableText_5e41a6a3ab",typography:"typography_b6d16966fc"};(function(t){const i="s_id-bcdc5f69e9db_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.text1Bold_55da83707c {
  font: var(--font-text1-bold);
}

.text1Medium_48b000a595 {
  font: var(--font-text1-medium);
}

.text1Normal_3057fa2a8b {
  font: var(--font-text1-normal);
}

.text2Bold_6e3e14ff64 {
  font: var(--font-text2-bold);
}

.text2Medium_3602a7ed9d {
  font: var(--font-text2-medium);
}

.text2Normal_2aa41ff154 {
  font: var(--font-text2-normal);
}

.text3Bold_8377677634 {
  font: var(--font-text3-bold);
}

.text3Medium_47f94d2806 {
  font: var(--font-text3-medium);
}

.text3Normal_5a064de678 {
  font: var(--font-text3-normal);
}

.editableText_5e41a6a3ab .typography_b6d16966fc {
  min-width: 56px;
}`);var yu=zt(k.forwardRef(function(t,i){var o=t.type,l=o===void 0?"text2":o,c=t.weight,d=c===void 0?"normal":c,p=t["data-testid"],f=t.id,m=t.multiline,h=co(t,["type","weight","data-testid","id","multiline"]);return D.createElement(I2,Object.assign({className:kc.editableText,ref:i,"data-testid":p||De(pn.EDITABLE_TEXT,f),component:cl,typographyClassName:ue(Xe(kc,Qe(l+"-"+d)),kc.typography),clearable:!0,type:l,weight:d,multiline:m},h))}),{types:Va,weights:Ga}),dr,Za,ph="custom";(function(t){t.CIRCLE="circle",t.RECTANGLE="rectangle",t.TEXT="text"})(dr||(dr={})),function(t){t.H1="h1",t.H2="h2",t.H3="h3",t.H4="h4",t.H5="h5",t.H6="h6",t.P="p",t.SMALL="small"}(Za||(Za={}));var M2={CUSTOM:ph,CIRCLE:{},RECTANGLE:{},TEXT:Za},oi={skeleton:"skeleton_2191ba9e22",rectangle:"rectangle_a07ba88d01",shine:"shine_45141d9fda",circle:"circle_52e4f433c4",text:"text_055276871e",textH1:"textH1_f1da5085ae",textH2:"textH2_69fac2dd38",textH3:"textH3_69fac2dd38",textH4:"textH4_1bf03d6e93",textH5:"textH5_fb9e25288b",textH6:"textH6_274965b5bb",textSmall:"textSmall_50303d7605",textCustom:"textCustom_274965b5bb",fullWidth:"fullWidth_9b8e8244f7"};(function(t){const i="s_id-41cda04b2bc0_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.skeleton_2191ba9e22 {
  display: flex;
}

.rectangle_a07ba88d01 {
  height: 160px;
  background: var(--ui-background-color);
  border-radius: var(--border-radius-small);
  overflow: hidden;
  animation-duration: 0.8s;
  animation-direction: alternate;
  animation-iteration-count: infinite;
  animation-name: shine_45141d9fda;
  animation-timing-function: steps(10, end);
}

@keyframes shine_45141d9fda {
  0% {
    opacity: 0.4;
  }
  100% {
    opacity: 1;
  }
}

.circle_52e4f433c4 {
  height: 40px;
  background: var(--ui-background-color);
  border-radius: 50%;
  overflow: hidden;
  animation-duration: 0.8s;
  animation-direction: alternate;
  animation-iteration-count: infinite;
  animation-name: shine_45141d9fda;
  animation-timing-function: steps(10, end);
}

@keyframes shine_45141d9fda {
  0% {
    opacity: 0.4;
  }
  100% {
    opacity: 1;
  }
}

.text_055276871e {
  background: var(--ui-background-color);
  border-radius: var(--border-radius-small);
  overflow: hidden;
  animation-duration: 0.8s;
  animation-direction: alternate;
  animation-iteration-count: infinite;
  animation-name: shine_45141d9fda;
  animation-timing-function: steps(10, end);
}

@keyframes shine_45141d9fda {
  0% {
    opacity: 0.4;
  }
  100% {
    opacity: 1;
  }
}

.textH1_f1da5085ae {
  height: 32px;
}

.textH2_69fac2dd38 {
  height: 24px;
}

.textH3_69fac2dd38 {
  height: 24px;
}

.textH4_1bf03d6e93 {
  height: 21px;
}

.textH5_fb9e25288b {
  height: 16px;
}

.textH6_274965b5bb {
  height: 12px;
}

.textSmall_50303d7605,
.textCustom_274965b5bb {
  height: 12px;
}

.fullWidth_9b8e8244f7 {
  width: 100%;
}

.skeleton_2191ba9e22:not(.fullWidth_9b8e8244f7) .text_055276871e {
  width: 162px;
}

.skeleton_2191ba9e22:not(.fullWidth_9b8e8244f7) .circle_52e4f433c4 {
  width: 40px;
}

.skeleton_2191ba9e22:not(.fullWidth_9b8e8244f7) .rectangle_a07ba88d01 {
  width: 160px;
}`);var B2=jv(function(t){var i=t.type,o=i===void 0?"rectangle":i,l=t.size,c=l===void 0?"custom":l,d=t.className,p=t.wrapperClassName,f=t.width,m=t.height,h=t.fullWidth,g=h!==void 0&&h,y=t.id,b=t["data-testid"],w=Object.values(dr).includes(o)?o:"rectangle",N=Object.values(Za).includes(c)?c:ph;return D.createElement("div",{id:y,className:ue(oi.skeleton,p,se({},oi.fullWidth,g)),"data-testid":b||De(pn.SKELETON,y)},D.createElement("div",{className:ue(oi[w],Xe(oi,Qe(w+"-"+N)),d,se({},oi.fullWidth,g)),style:{width:f,height:m}}))},{types:dr,sizes:M2}),mh=function(t){var i=t.size,o=uo(t,["size"]);return k.createElement("svg",Object.assign({viewBox:"0 0 20 20",fill:"currentColor",width:i||"20",height:i||"20"},o),k.createElement("path",{d:"M10 2.47494C10.2086 2.47494 10.3973 2.5603 10.5331 2.69802L12.933 5.10095C13.2255 5.39384 13.2255 5.86871 12.933 6.16161C12.6404 6.4545 12.1662 6.4545 11.8736 6.16161L10.7491 5.03562V16.7753C10.7491 17.1896 10.4137 17.5253 10 17.5253C9.58633 17.5253 9.25097 17.1896 9.25097 16.7753V5.03558L8.12637 6.16161C7.83384 6.4545 7.35957 6.4545 7.06705 6.16161C6.77453 5.86871 6.77453 5.39384 7.06705 5.10095L9.47034 2.69461C9.48492 2.68001 9.50004 2.66608 9.51565 2.65283C9.64625 2.54187 9.81533 2.47494 10 2.47494Z",fill:"currentColor"}))};mh.displayName="SortAscending";var vh=function(t){var i=t.size,o=uo(t,["size"]);return k.createElement("svg",Object.assign({viewBox:"0 0 20 20",fill:"currentColor",width:i||"20",height:i||"20"},o),k.createElement("path",{d:"M10 17.5251C10.2086 17.5251 10.3973 17.4397 10.5331 17.302L12.933 14.8991C13.2255 14.6062 13.2255 14.1313 12.933 13.8384C12.6404 13.5455 12.1662 13.5455 11.8736 13.8384L10.7491 14.9644L10.7491 3.22465C10.7491 2.81044 10.4137 2.47465 10 2.47465C9.58633 2.47465 9.25097 2.81044 9.25097 3.22465L9.25097 14.9644L8.12637 13.8384C7.83384 13.5455 7.35957 13.5455 7.06705 13.8384C6.77453 14.1313 6.77453 14.6062 7.06705 14.8991L9.47034 17.3054C9.48492 17.32 9.50004 17.3339 9.51565 17.3472C9.64625 17.4581 9.81533 17.5251 10 17.5251Z",fill:"currentColor"}))};vh.displayName="SortDescending";var hh=function(t){var i=t.size,o=uo(t,["size"]);return k.createElement("svg",Object.assign({viewBox:"0 0 20 20",fill:"currentColor",width:i||"20",height:i||"20"},o),k.createElement("path",{d:"M7.13869 2.75741C7.34727 2.75741 7.53593 2.84277 7.67174 2.98049L10.0716 5.38342C10.3641 5.67631 10.3641 6.15118 10.0716 6.44408 9.7791 6.73697 9.30483 6.73697 9.0123 6.44408L7.88775 5.3181V17.0578C7.88775 17.472 7.55238 17.8078 7.13869 17.8078 6.725 17.8078 6.38964 17.472 6.38964 17.0578V5.31805L5.26504 6.44408C4.97252 6.73697 4.49824 6.73697 4.20572 6.44408 3.9132 6.15118 3.9132 5.67631 4.20572 5.38342L6.60901 2.97708C6.62359 2.96249 6.63871 2.94855 6.65432 2.9353 6.78492 2.82434 6.954 2.75741 7.13869 2.75741zM14.4434 17.8075C14.652 17.8075 14.8406 17.7222 14.9764 17.5844L17.3763 15.1815C17.6688 14.8886 17.6688 14.4138 17.3763 14.1209 17.0838 13.828 16.6095 13.828 16.317 14.1209L15.1924 15.2468V3.50712C15.1924 3.09291 14.8571 2.75712 14.4434 2.75712 14.0297 2.75712 13.6943 3.09291 13.6943 3.50712V15.2469L12.5697 14.1209C12.2772 13.828 11.8029 13.828 11.5104 14.1209 11.2179 14.4138 11.2179 14.8886 11.5104 15.1815L13.9137 17.5879C13.9283 17.6025 13.9434 17.6164 13.959 17.6296 14.0896 17.7406 14.2587 17.8075 14.4434 17.8075z",fill:"currentColor"}))};hh.displayName="Sort";function _u(t){return typeof t=="number"?"".concat(t,"px"):typeof t=="string"?/%|px|fr$/.test(t)?t:"".concat(t,"px"):t!=null&&t.min&&(t!=null&&t.max)?"minmax(".concat(_u(t.min),", ").concat(_u(t.max),")"):"minmax(112px, 1fr)"}function j2(t){return Object.assign(Object.assign({},arguments.length>1&&arguments[1]!==void 0?arguments[1]:{}),{display:"grid",gridTemplateColumns:t.map(function(i){return _u(i.width)}).join(" ")})}function $2(t){return t==="asc"?mh:t==="desc"?vh:hh}function z2(t){return t==="asc"?"desc":t==="desc"?"none":"asc"}function F2(t){return t==="asc"?"ascending":t==="desc"?"descending":"none"}function X2(t){return t==="circle"?dr.CIRCLE:t==="rectangle"?dr.RECTANGLE:dr.TEXT}function U2(t,i){return t==="long-text"?["long-text","medium-text"][i%2]:t}var eo,H2=5;(function(t){t.SMALL="small",t.MEDIUM="medium",t.LARGE="large"})(eo||(eo={}));var W2=se(se(se({},eo.SMALL,32),eo.MEDIUM,40),eo.LARGE,48),Ma={table:"table_4f032406b7",border:"border_7545c9e016",virtualized:"virtualized_993e832d20",hasScroll:"hasScroll_6f0694520c"};(function(t){const i="s_id-2b8bccf4a9c1_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.table_4f032406b7 {
  --sticky-cell-hover-background: linear-gradient(
      to right,
      var(--primary-background-hover-color),
      var(--primary-background-hover-color)
    ),
    linear-gradient(to right, var(--primary-background-color), var(--primary-background-color));
  background-color: var(--primary-background-color);
  overflow: auto;
  width: 100%;
  height: 100%;
}
.table_4f032406b7.border_7545c9e016 {
  border: 1px solid var(--layout-border-color);
  border-radius: var(--border-radius-small);
}
.table_4f032406b7 [role=rowgroup] [role=row] > [role=cell] {
  border-bottom: 1px solid var(--layout-border-color);
}
.table_4f032406b7 [role=rowgroup] > [role=row]:last-of-type > [role=cell] {
  border-bottom: none;
}
.table_4f032406b7.virtualized_993e832d20 {
  overflow: hidden;
}
.table_4f032406b7.hasScroll_6f0694520c {
  --sticky-cell-box-shadow: 3px 0 4px rgba(0, 0, 0, 0.1);
}`);var gh=k.createContext(void 0),V2=function(t){var i=t.value,o=t.children,l=i.setIsScrolled,c=k.useRef(null),d=k.useRef(null),p=k.useRef(0),f=k.useCallback(function(y,b){if(y!==p.current){b==="body"&&c.current&&(c.current.scrollLeft=y),b==="head"&&d.current&&(d.current.scrollLeft=y);var w=y>0;l(function(N){return N!==w?w:N}),p.current=y}},[l]),m=k.useCallback(function(y){f(y.target.scrollLeft,"head")},[f]),h=k.useCallback(function(y){f(y.target.scrollLeft,"body")},[f]),g=k.useMemo(function(){return Object.assign(Object.assign({},i),{headRef:c,onHeadScroll:m,virtualizedListRef:d,onVirtualizedListScroll:h})},[i,m,h]);return D.createElement(gh.Provider,{value:g},o)},yh=function(){var t=k.useContext(gh);if(t===void 0)throw Error("useTable must be used within a TableProvider");return t},_h=k.createContext(void 0),G2=function(t){var i=t.value,o=t.children,l=i.tableRootRef,c=i.hoveredRowRef,d=i.isMenuOpen,p=i.resetHoveredRow,f=i.setHoveredRowRef,m=i.setIsMenuOpen,h=k.useState(0),g=Tt(h,2),y=g[0],b=g[1],w=k.useRef(!1),N=k.useCallback(function(B){if(!d){f(B);var j=l.current.getBoundingClientRect().top,X=B.current.getBoundingClientRect().top;b(X-j)}},[d,f,l]),L=k.useCallback(function(){d||w.current||f(null)},[d,f]),O=k.useCallback(function(){w.current=!0},[]),R=k.useCallback(function(){w.current=!1,d||c!=null&&c.current||f(null)},[d,c,f]),M=k.useCallback(function(){m(!0)},[m]),z=k.useCallback(function(){m(!1)},[m]),I=k.useMemo(function(){var B;return{hoveredRowId:(B=c==null?void 0:c.current)===null||B===void 0?void 0:B.id,resetHoveredRow:p,menuButtonPosition:y,onMouseOverRow:N,onMouseLeaveRow:L,onMouseOverRowMenu:O,onMouseLeaveRowMenu:R,setTableMenuShown:M,setTableMenuHidden:z}},[c,p,y,L,R,N,O,M,z]);return D.createElement(_h.Provider,{value:I},o)},K2=function(){var t=k.useContext(_h);if(!t)throw Error("useTableRowMenuContext must be used within a TableRowMenuProvider");return t},Y2=zt(k.forwardRef(function(t,i){var o=t.id,l=t.className,c=t["data-testid"],d=t.columns,p=t.errorState,f=t.emptyState,m=t.dataState,h=t.style,g=t.children,y=t.size,b=y===void 0?"medium":y,w=t.withoutBorder,N=k.useRef(null),L=$t(i,N),O=k.useState(!1),R=Tt(O,2),M=R[0],z=R[1],I=k.useState(null),B=Tt(I,2),j=B[0],X=B[1],K=k.useCallback(function(){z(!1),X(null)},[]),ce=k.useState(!1),Q=Tt(ce,2),Z=Q[0],le=Q[1],de=k.useCallback(function(){le(!0)},[]),oe=k.useState(!1),ve=Tt(oe,2),re=ve[0],fe=ve[1],H=k.useCallback(function(te){if(K(),!Z){var ie=te.target.scrollLeft>0;fe(function(ye){return ye!==ie?ie:ye})}},[K,Z]),V=j2(d),x=Object.assign({"--table-grid-template-columns":V.gridTemplateColumns,"--table-row-size":"".concat(W2[b],"px")},h),P=k.useMemo(function(){return{columns:d,dataState:m,emptyState:f,errorState:p,size:b,tableRootRef:N,isVirtualized:Z,markTableAsVirtualized:de,isScrolled:re,setIsScrolled:function(te){return fe(te)}}},[d,m,f,p,Z,de,re,b]),G=k.useMemo(function(){return{tableRootRef:N,hoveredRowRef:j,isMenuOpen:M,resetHoveredRow:K,setHoveredRowRef:function(te){return X(te)},setIsMenuOpen:function(te){return z(te)}}},[j,M,K,X]);return D.createElement(V2,{value:P},D.createElement(G2,{value:G},D.createElement("div",{ref:L,id:o,className:ue(Ma.table,se(se(se({},Ma.border,!w),Ma.virtualized,Z),Ma.hasScroll,re),l),"data-testid":c||De(Ze.TABLE,o),role:"table",style:x,onScroll:H},g)))}),{sizes:eo}),Vm={tableHeader:"tableHeader_09b6c857a9",virtualized:"virtualized_74152aa9fe"};(function(t){const i="s_id-8e924ee64aa4_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tableHeader_09b6c857a9 {
  display: grid;
  grid-template-columns: var(--table-grid-template-columns);
  position: sticky;
  top: 0;
  z-index: 2;
  background-color: var(--primary-background-color);
  min-width: 100%;
  width: fit-content;
}
.tableHeader_09b6c857a9 > [role=columnheader] {
  background-color: inherit;
}
.tableHeader_09b6c857a9.virtualized_74152aa9fe {
  overflow: auto;
  width: auto;
  scrollbar-width: none;
}
.tableHeader_09b6c857a9.virtualized_74152aa9fe::-webkit-scrollbar {
  display: none;
}`);var q2=k.forwardRef(function(t,i){var o=t.id,l=t.className,c=t["data-testid"],d=t.children,p=yh(),f=p.onHeadScroll,m=p.isVirtualized,h=$t(p.headRef,i);return D.createElement("div",{ref:h,id:o,className:ue(Vm.tableHeader,se({},Vm.virtualized,m),l),"data-testid":c||De(Ze.TABLE_HEADER,o),role:"rowgroup",onScroll:f},d)}),qt={tableHeaderCell:"tableHeaderCell_da4e9ce39b","focus-visible":"focus-visible_b0a5cd5036",sticky:"sticky_47d3348430",sortActive:"sortActive_cc0856055b",tableHeaderCellContent:"tableHeaderCellContent_4ab8fec587",icon:"icon_3fec69f881",infoTooltip:"infoTooltip_fa2bf28443",tableHeaderCellSort:"tableHeaderCellSort_e5aa0d8cac",sort:"sort_00231b0431",asc:"asc_e54c3e6180",desc:"desc_db5589817c",show:"show_938db12255"};(function(t){const i="s_id-5b3eed132e11_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tableHeaderCell_da4e9ce39b {
  height: var(--table-row-size);
  padding: var(--spacing-small);
  padding-inline-start: var(--spacing-medium);
  color: var(--secondary-text-color);
  box-sizing: border-box;
  text-align: initial;
  border-bottom: 1px solid var(--layout-border-color);
  display: flex;
  justify-content: space-between;
  background-color: inherit;
}
.tableHeaderCell_da4e9ce39b:focus-visible, .tableHeaderCell_da4e9ce39b.focus-visible_b0a5cd5036 {
  outline: none;
  z-index: 11;
  border-radius: 4px;
  box-shadow: 0 0 0 3px hsla(209, 100%, 50%, 0.5), 0 0 0 1px var(--primary-hover-color) inset;
}
.tableHeaderCell_da4e9ce39b:focus:not(.focus-visible_b0a5cd5036) {
  outline: none;
}
.tableHeaderCell_da4e9ce39b.sticky_47d3348430 {
  z-index: 1;
  position: sticky;
  left: 0;
  box-shadow: var(--sticky-cell-box-shadow);
}
.tableHeaderCell_da4e9ce39b.sticky_47d3348430:hover {
  background: var(--sticky-cell-hover-background);
}
.tableHeaderCell_da4e9ce39b:hover, .tableHeaderCell_da4e9ce39b.sortActive_cc0856055b {
  background-color: var(--primary-background-hover-color);
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellContent_4ab8fec587 {
  min-width: 0;
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellContent_4ab8fec587 .icon_3fec69f881 {
  min-width: var(--spacing-medium);
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellContent_4ab8fec587 .infoTooltip_fa2bf28443 {
  display: inline-flex;
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellSort_e5aa0d8cac {
  padding-inline-start: var(--spacing-small);
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellSort_e5aa0d8cac .sort_00231b0431 {
  color: var(--icon-color);
  transition: opacity 0.1s;
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellSort_e5aa0d8cac .sort_00231b0431.asc_e54c3e6180, .tableHeaderCell_da4e9ce39b .tableHeaderCellSort_e5aa0d8cac .sort_00231b0431.desc_db5589817c {
  color: var(--primary-text-color);
}
.tableHeaderCell_da4e9ce39b .tableHeaderCellSort_e5aa0d8cac .sort_00231b0431:not(.show_938db12255) {
  opacity: 0;
  pointer-events: none;
}`);var Ec=k.forwardRef(function(t,i){var o=t.id,l=t.className,c=t["data-testid"],d=t.title,p=t.onSortClicked,f=t.infoContent,m=t.icon,h=t.sortState,g=h===void 0?"none":h,y=t.sortButtonAriaLabel,b=y===void 0?"Sort":y,w=t.sticky,N=k.useState(!1),L=Tt(N,2),O=L[0],R=L[1],M=F2(g),z=M!=="none"||O;return D.createElement("div",{ref:i,id:o,className:ue(qt.tableHeaderCell,se(se({},qt.sortActive,p&&M!=="none"),qt.sticky,w),l),"data-testid":c||De(Ze.TABLE_HEADER_CELL,o),role:"columnheader",onMouseOver:function(){return R(!0)},onMouseLeave:function(){return R(!1)},onFocus:function(){return R(!0)},onBlur:function(){return R(!1)},"aria-sort":p?M:void 0,tabIndex:p?0:void 0},D.createElement(Hc,{direction:"row",align:"center",className:qt.tableHeaderCellContent,gap:"xs"},m&&D.createElement(Qt,{icon:m,className:qt.icon}),typeof d=="string"?D.createElement(cl,{type:"text2",weight:"medium",color:"secondary"},d):d,f&&D.createElement(at,{content:f,referenceWrapperClassName:qt.infoTooltip},D.createElement(Qt,{icon:fh,iconLabel:f}))),p&&D.createElement(Hc,{direction:"row",align:"center",className:qt.tableHeaderCellSort},D.createElement(Mu,{icon:$2(g),kind:"tertiary",size:"xs",ariaLabel:b,"aria-hidden":!z,className:ue(qt.sort,Xe(qt,g),se({},qt.show,z)),onClick:function(){return p(z2(g))}})))}),Q2={tableRow:"tableRow_6271644618"};(function(t){const i="s_id-72a799b963ca_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tableRow_6271644618 {
  height: var(--table-row-size);
  display: grid;
  grid-template-columns: var(--table-grid-template-columns);
  min-width: 100%;
  width: fit-content;
}
.tableRow_6271644618[aria-selected=true] > [role=cell] {
  background-color: var(--primary-selected-color);
}
.tableRow_6271644618 > [role=cell] {
  background-color: var(--primary-background-color);
}
.tableRow_6271644618:hover > [role=cell] {
  background: var(--sticky-cell-hover-background);
}
.tableRow_6271644618:hover[aria-selected=true] > [role=cell] {
  background: var(--primary-selected-hover-color);
}`);var bh=k.forwardRef(function(t,i){var o=t.highlighted,l=t.children,c=t.style,d=t.id,p=t.className,f=t["data-testid"],m=k.useRef(null),h=$t(m,i),g=K2(),y=g.onMouseOverRow,b=g.onMouseLeaveRow,w=k.useCallback(function(){y(m)},[y]);return D.createElement("div",{id:d,"data-testid":f||De(Ze.TABLE_ROW,d),ref:h,role:"row","aria-selected":o||!1,className:ue(Q2.tableRow,p),style:c,onMouseEnter:w,onMouseLeave:b,tabIndex:-1},l)}),Z2={tableBody:"tableBody_bdc5443a80"};(function(t){const i="s_id-afed3a5f5737_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tableBody_bdc5443a80 {
  height: 100%;
}`);var Gm={tableCell:"tableCell_8d33346970",sticky:"sticky_47d3348430"};(function(t){const i="s_id-25789b81dac4_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tableCell_8d33346970 {
  padding: 9px 16px;
  overflow: hidden;
  display: flex;
  align-items: center;
}
.tableCell_8d33346970.sticky_47d3348430 {
  z-index: 1;
  position: sticky;
  left: 0;
  box-shadow: var(--sticky-cell-box-shadow);
}`);var Fa=k.forwardRef(function(t,i){var o=t.sticky,l=t.id,c=t.className,d=t["data-testid"],p=t.children,f=D.Children.count(p)===1,m=fr(D.Children.toArray(p)[0]),h=m==="string"||m==="number";return D.createElement("div",{ref:i,id:l,className:ue(Gm.tableCell,se({},Gm.sticky,o),c),"data-testid":d||De(Ze.TABLE_CELL,l),role:"cell"},f&&h?D.createElement(cl,{type:"text2",color:"primary"},p):p)}),Ba={tableCellSkeletonWrapper:"tableCellSkeletonWrapper_bdc5443a80",longText:"longText_58cfb763d5",mediumText:"mediumText_70a8d40a38",tableCellSkeleton:"tableCellSkeleton_bdc5443a80",circle:"circle_3ef5b0f8d0",rectangle:"rectangle_68adb71636"};(function(t){const i="s_id-18cab9319884_3_52_1";if(typeof document<"u"){const o=document.head||document.getElementsByTagName("head")[0];if(o.querySelector("#"+i))return;const l=document.createElement("style");l.id=i,o.firstChild?o.insertBefore(l,o.firstChild):o.appendChild(l),l.appendChild(document.createTextNode(t))}else globalThis.injectedStyles&&(globalThis.injectedStyles[i]=t)})(`.tableCellSkeletonWrapper_bdc5443a80 {
  height: 100%;
}
.tableCellSkeletonWrapper_bdc5443a80.longText_58cfb763d5 {
  padding-inline-end: var(--spacing-large);
}
.tableCellSkeletonWrapper_bdc5443a80.mediumText_70a8d40a38 {
  padding-inline-end: var(--spacing-xxxl);
}
.tableCellSkeletonWrapper_bdc5443a80 .tableCellSkeleton_bdc5443a80 {
  height: 100%;
}
@supports (aspect-ratio: 1/1) {
  .tableCellSkeletonWrapper_bdc5443a80 .tableCellSkeleton_bdc5443a80.circle_3ef5b0f8d0, .tableCellSkeletonWrapper_bdc5443a80 .tableCellSkeleton_bdc5443a80.rectangle_68adb71636 {
    width: auto;
    aspect-ratio: 1/1;
  }
}
@supports not (aspect-ratio: 1/1) {
  .tableCellSkeletonWrapper_bdc5443a80 .tableCellSkeleton_bdc5443a80.circle_3ef5b0f8d0, .tableCellSkeletonWrapper_bdc5443a80 .tableCellSkeleton_bdc5443a80.rectangle_68adb71636 {
    width: 21px;
  }
}`);var J2=function(t){var i=t.type,o=i===void 0?"long-text":i,l=["long-text","medium-text"].includes(o);return D.createElement(Fa,null,D.createElement(B2,{type:X2(o),wrapperClassName:ue(Ba.tableCellSkeletonWrapper,Xe(Ba,Qe(o))),className:ue(Ba.tableCellSkeleton,se({},Xe(Ba,Qe(o)),!l)),fullWidth:!0}))},e5=k.forwardRef(function(t,i){var o=t.id,l=t.className,c=t["data-testid"],d=t.children,p=yh(),f=p.emptyState,m=p.errorState,h=p.columns,g=p.dataState||{},y=g.isLoading,b=g.isError,w=wu(Array(H2)).map(function(N,L){return D.createElement(bh,{key:L},h.map(function(O,R){var M=O.loadingStateType;return D.createElement(J2,{key:"".concat(L,"-").concat(R),type:U2(M,L)})}))});return D.createElement("div",{ref:i,id:o,className:ue(Z2.tableBody,l),"data-testid":c||De(Ze.TABLE_BODY,o),role:"rowgroup"},y?w:b?m:!d||Array.isArray(d)&&d.length===0?f:d)}),to,bu;(function(t){t.LIGHT="light",t.DARK="dark",t.BLACK="black"})(to||(to={})),function(t){t.primaryColor="primary-color",t.primaryHoverColor="primary-hover-color",t.primarySelectedColor="primary-selected-color",t.primarySelectedHoverColor="primary-selected-hover-color",t.primarySelectedOnSecondaryColor="primary-selected-on-secondary-color",t.textColorOnPrimary="text-color-on-primary",t.brandColor="brand-color",t.brandHoverColor="brand-hover-color",t.brandSelectedColor="brand-selected-color",t.brandSelectedHoverColor="brand-selected-hover-color",t.textColorOnBrand="text-color-on-brand"}(bu||(bu={}));var t5=se(se(se({},to.LIGHT,"light-app-theme"),to.DARK,"dark-app-theme"),to.BLACK,"black-app-theme"),n5=function t(i,o,l){for(var c=0,d=Object.keys(i);d.length>c;c++){var p=d[c];typeof i[p]=="string"&&(o+="--".concat(p,": ").concat(i[p],";"))}o!==""&&(o=l+" {"+o+"}");for(var f=0,m=Object.keys(i);m.length>f;f++){var h=m[f];if(fr(i[h])==="object"){var g="".concat(l," .").concat(h);o+=`
`+t(i[h],"",g)}}return o},xu=function(t){return!!(t!=null&&t.colors)&&!!(t!=null&&t.name)},r5=function(t,i){if(!xu(t))return null;for(var o="",l=0,c=Object.keys(t.colors);c.length>l;l++){var d=c[l];o+=n5(t.colors[d],"",".".concat(t5[d]," .").concat(i,".").concat(t.name))+`
`}return o},o5=function(){for(var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:6,i="",o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",l=0;t>l;l++)i+=o.charAt(Math.floor(52*Math.random()));return i},xh="-app-theme",i5=function(t){return t.endsWith(xh)},kh=function(t){return"".concat(t).concat(xh)},a5=function(){for(var t=document.body.classList,i=0,o=Array.from(t);o.length>i;i++){var l=o[i];if(i5(l))return l}return null},l5=function(){return!!a5()},s5=function(t){document.body.classList.add(kh(t))},c5=function(t){document.body.classList.remove(kh(t))},u5=jv(function(t){var i=t.themeConfig,o=t.children,l=t.themeClassSpecifier,c=t.systemTheme,d=t.className,p=k.useState(!1),f=Tt(p,2),m=f[0],h=f[1],g=k.useMemo(function(){return l||o5()},[l]);return tl(function(){if(c&&!l5())return s5(c),function(){c5(c)}},[c]),k.useEffect(function(){if(xu(i)){if(!document.getElementById(i.name)){var y=document.createElement("style");y.type="text/css",y.id=i.name;var b=r5(i,g);try{y.appendChild(document.createTextNode(b)),document.head.appendChild(y),h(!0)}catch(w){console.error("vibe ThemeProvider: error inserting theme-generated css - ",w)}return function(){document.head.removeChild(y)}}h(!0)}},[g,i]),!m&&xu(i)?null:D.createElement("div",{className:ue(i==null?void 0:i.name,g,d)},o)},{systemThemes:to,colors:bu});const d5=t=>{const i="https://viskode.com/monday-apps/local-and-web-links#troubleshooting";return he.jsxs("div",{children:[t.statusNumber===3&&he.jsxs(Da,{backgroundColor:"negative",onClose:()=>t.setStatusNumber(0),children:[he.jsx(si,{style:{fontSize:"10px"},text:"Please update the passcode with the code shown in the desktop app"}),he.jsx(li,{href:i,text:"learn more"})]}),t.statusNumber===5&&he.jsxs(Da,{backgroundColor:"negative",onClose:()=>t.setStatusNumber(0),children:[he.jsx(si,{text:"Passcode has to be set to open local links!"}),he.jsx(li,{href:i,text:"learn more"})]}),t.statusNumber===6&&he.jsxs(Da,{backgroundColor:"negative",onClose:()=>t.setStatusNumber(0),children:[he.jsx(si,{text:"File or folder not found"}),he.jsx(li,{href:i,text:"learn more"})]}),t.statusNumber===dn.DesktopAppNotRunning&&he.jsxs(Da,{backgroundColor:"negative",onClose:()=>t.setStatusNumber(0),children:[he.jsx(si,{text:"The Desktop app is not running!"}),he.jsx(li,{href:i,text:"learn more"})]})]})},f5=t=>{const[i,o]=k.useState(null),[l,c]=k.useState(!1),[d,p]=k.useState(!1);k.useEffect(()=>{const g=localStorage.getItem("token");g&&o(g)},[]),k.useEffect(()=>{(t.openUrlResponse===dn.AccessDeniedForIncorrectCode||t.openUrlResponse===dn.CodeNotFoundInLocalStorage)&&p(!0)},[t.openUrlResponse]);const f=g=>{o(g),c(!1),p(!1),localStorage.setItem("token",g==null?void 0:g.trim())},m=g=>{g||f(i)},h=()=>{c(!0)};return he.jsx(he.Fragment,{children:i==null||l?he.jsx(yu,{placeholder:"Passcode .....",onChange:f,value:i,autoSelectTextOnEditMode:!0,onEditModeChange:g=>m(g)}):he.jsx("div",{style:{color:d?"red":"green",padding:"10px 20px",cursor:"pointer"},onClick:h,children:he.jsx(Qt,{iconType:"src",icon:"/svgs/key.svg"})})})},p5=({url:t,description:i,index:o,monday:l,context:c,linkListWithVersion:d,setLinkListWithVersion:p,setNotConnectedBannerState:f,setOpenUrlResponse:m,setTableLoadingState:h})=>{const g=!t||t.trim()==="",y=ev(t).isValid,b=g||y,w=g,N=()=>g?"Enter a URL first":y?"Only available for local paths":"Open parent folder/directory of this URL",L=()=>g?"Enter a URL first":"Opens a web link in your browser, or opens a local file with its default app or folder in File Explorer.";return he.jsxs(bh,{className:"cursor-pointer",children:[he.jsx(Fa,{children:he.jsx(yu,{onChange:O=>{_y(l,c.itemId,o,d,O,p)},type:"text2",value:t,placeholder:"Web or Local URL",autoSelectTextOnEditMode:!0,readOnly:c.user.isViewOnly})}),he.jsx(Fa,{children:he.jsx(yu,{onChange:O=>{yy(l,c.itemId,o,d,O,p)},type:"text2",value:i,placeholder:"ex: Google sheet, Images folder",autoSelectTextOnEditMode:!0,readOnly:c.user.isViewOnly})}),he.jsxs(Fa,{children:[he.jsx(at,{content:N(),showDelay:500,children:he.jsx(sr,{rightIcon:"Delete",onClick:()=>Yp(t,f,m,!0),size:"small",color:"primary",style:{height:"30px"},disabled:b,children:"Open Parent"})}),he.jsx(at,{content:L(),showDelay:500,children:he.jsx(sr,{rightIcon:"Delete",onClick:()=>Yp(t,f,m,!1),size:"small",color:"positive",style:{height:"30px",marginLeft:"5px"},disabled:w,children:"Open URL"})}),he.jsx(at,{content:"Delete this link",position:"left",showDelay:500,children:he.jsx(sr,{onClick:()=>xy(l,c.itemId,o,d,p,h),size:"small",color:"negative",style:{height:"30px",marginLeft:"30px",width:"30px"},disabled:c.user.isViewOnly,children:he.jsx(Qt,{iconType:"src",icon:"/svgs/trash.svg"})})})]})]},o)},ii=z0();let Km;const m5=()=>{var N,L;const[t,i]=k.useState(null),[o,l]=k.useState(null),[c,d]=k.useState({list:[],version:0}),[p,f]=k.useState(!1),[m,h]=k.useState(!1),[g,y]=k.useState(!0),[b,w]=k.useState(0);return k.useEffect(()=>{ii.execute("valueCreatedForUser");const O=async R=>{if(i(R),R!=null&&R.itemId&&(R!=null&&R.boardId)){console.info(R);try{const M=await gi(ii,R.itemId);l(M);const z=JSON.parse(M.value);d({list:z,version:M.version})}catch(M){console.error("Error fetching column text:",M)}}y(!1)};ii.listen("context",R=>{const M=R.data;O(M)})},[]),Km=t==null?void 0:t.itemId,t==null||t.boardId,`${t?t.user.id:"still loading"}${Km}`,he.jsx("div",{className:"App",children:he.jsxs(u5,{themeConfig:t==null?void 0:t.themeConfig,systemTheme:t==null?void 0:t.theme,children:[he.jsxs(D2,{padding:"medium",children:[he.jsxs(Y2,{style:{width:"auto",position:"relative"},size:"medium",columns:[{id:"url",title:"url"},{id:"description",title:"description"},{id:"open-btn",title:"",width:290}],dataState:{isLoading:g},children:[he.jsxs(q2,{className:"table-header-fix",children:[he.jsx(Ec,{title:"URL"}),he.jsx(Ec,{title:"Description"}),he.jsx(Ec,{title:""})]}),he.jsx(e5,{children:(N=c.list)==null?void 0:N.map(([O,R],M)=>he.jsx(p5,{url:R,description:O,index:M,monday:ii,context:t,linkListWithVersion:c,setLinkListWithVersion:d,setNotConnectedBannerState:f,setOpenUrlResponse:w,setTableLoadingState:y},M))})]}),he.jsxs("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center"},children:[he.jsx(Mu,{loading:m,kind:"secondary",ariaLabel:"Add a new link",onClick:()=>{by(ii,t.itemId,c,d,m,h)},disabled:(L=t==null?void 0:t.user)==null?void 0:L.isViewOnly}),he.jsx(at,{content:`Use the passcode displayed in your desktop app. \r
            Each user must set it individually in their browser to open local URLs.\r
             It’s unique to your device and not shared with others.\r
             This is only required if you need to open local files or folders.\r
             `,position:"left",zIndex:2,showDelay:800,children:he.jsx(f5,{openUrlResponse:b,setOpenUrlResponse:w})})]})]}),he.jsx(d5,{statusNumber:b,setStatusNumber:w})]})})};window.location.hostname==="localhost"||window.location.hostname==="[::1]"||window.location.hostname.match(/^127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}$/);function v5(){"serviceWorker"in navigator&&navigator.serviceWorker.ready.then(t=>{t.unregister()}).catch(t=>{console.error(t.message)})}const h5=C0.createRoot(document.getElementById("root"));h5.render(he.jsx(m5,{}));v5();
